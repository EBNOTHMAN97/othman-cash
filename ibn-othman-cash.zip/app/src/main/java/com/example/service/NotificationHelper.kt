package com.example.service

import android.app.NotificationChannel
import android.app.NotificationManager
import android.app.PendingIntent
import android.content.Context
import android.content.Intent
import android.os.Build
import androidx.core.app.NotificationCompat
import androidx.core.app.NotificationManagerCompat
import com.example.MainActivity
import com.example.R
import com.example.receiver.TransactionActionReceiver
import java.text.DecimalFormat

object NotificationHelper {

    const val CHANNEL_ID = "ibn_othman_transactions_channel"
    const val CHANNEL_NAME = "معاملات ابن عثمان كاش"

    const val ACTION_CONFIRM_TRANSACTION = "com.aistudio.ibnothmancash.ACTION_CONFIRM_TRANSACTION"
    const val ACTION_DISMISS_NOTIFICATION = "com.aistudio.ibnothmancash.ACTION_DISMISS_NOTIFICATION"

    const val EXTRA_TX_TYPE = "extra_tx_type"
    const val EXTRA_TX_AMOUNT = "extra_tx_amount"
    const val EXTRA_TX_TARGET = "extra_tx_target"
    const val EXTRA_TX_REF = "extra_tx_ref"
    const val EXTRA_NOTIFICATION_ID = "extra_notification_id"
    const val EXTRA_WALLET_ID = "extra_wallet_id"
    const val EXTRA_SHOW_CONFIRM_DIALOG = "extra_show_confirm_dialog"

    private val numberFormat = DecimalFormat("#,##0.00")

    fun createNotificationChannel(context: Context) {
        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.O) {
            val importance = NotificationManager.IMPORTANCE_HIGH
            val channel = NotificationChannel(CHANNEL_ID, CHANNEL_NAME, importance).apply {
                description = "إشعارات تأكيد المعاملات اللحظية من المحافظ وتطبيقات الدفع"
                enableLights(true)
                lightColor = 0xFF10B981.toInt()
                enableVibration(true)
                vibrationPattern = longArrayOf(0, 200, 100, 200)
            }
            val notificationManager = context.getSystemService(Context.NOTIFICATION_SERVICE) as NotificationManager
            notificationManager.createNotificationChannel(channel)
        }
    }

    fun showActionableNotification(
        context: Context,
        notificationId: Int,
        typeStr: String,
        amount: Double,
        targetNumber: String,
        referenceNumber: String = "",
        walletId: Int = 1
    ) {
        createNotificationChannel(context)

        val formattedAmount = numberFormat.format(amount)
        val title = "عملية جديدة: $typeStr"
        val body = "المبلغ: $formattedAmount ج.م | الرقم: $targetNumber"

        // 1. PendingIntent for tapping notification body (Opens MainActivity with Confirmation Dialog)
        val activityIntent = Intent(context, MainActivity::class.java).apply {
            flags = Intent.FLAG_ACTIVITY_NEW_TASK or Intent.FLAG_ACTIVITY_CLEAR_TOP or Intent.FLAG_ACTIVITY_SINGLE_TOP
            putExtra(EXTRA_SHOW_CONFIRM_DIALOG, true)
            putExtra(EXTRA_TX_TYPE, typeStr)
            putExtra(EXTRA_TX_AMOUNT, amount)
            putExtra(EXTRA_TX_TARGET, targetNumber)
            putExtra(EXTRA_TX_REF, referenceNumber)
            putExtra(EXTRA_NOTIFICATION_ID, notificationId)
            putExtra(EXTRA_WALLET_ID, walletId)
        }
        val contentPendingIntent = PendingIntent.getActivity(
            context,
            notificationId,
            activityIntent,
            PendingIntent.FLAG_UPDATE_CURRENT or PendingIntent.FLAG_IMMUTABLE
        )

        // 2. PendingIntent for Direct Action Button "تأكيد وحفظ" (Handled in background by TransactionActionReceiver)
        val confirmIntent = Intent(context, TransactionActionReceiver::class.java).apply {
            action = ACTION_CONFIRM_TRANSACTION
            putExtra(EXTRA_TX_TYPE, typeStr)
            putExtra(EXTRA_TX_AMOUNT, amount)
            putExtra(EXTRA_TX_TARGET, targetNumber)
            putExtra(EXTRA_TX_REF, referenceNumber)
            putExtra(EXTRA_NOTIFICATION_ID, notificationId)
            putExtra(EXTRA_WALLET_ID, walletId)
        }
        val confirmPendingIntent = PendingIntent.getBroadcast(
            context,
            notificationId,
            confirmIntent,
            PendingIntent.FLAG_UPDATE_CURRENT or PendingIntent.FLAG_IMMUTABLE
        )

        // 3. PendingIntent for Dismiss Action Button "تجاهل"
        val dismissIntent = Intent(context, TransactionActionReceiver::class.java).apply {
            action = ACTION_DISMISS_NOTIFICATION
            putExtra(EXTRA_NOTIFICATION_ID, notificationId)
        }
        val dismissPendingIntent = PendingIntent.getBroadcast(
            context,
            notificationId + 100000,
            dismissIntent,
            PendingIntent.FLAG_UPDATE_CURRENT or PendingIntent.FLAG_IMMUTABLE
        )

        val notification = NotificationCompat.Builder(context, CHANNEL_ID)
            .setSmallIcon(R.drawable.ic_launcher_foreground)
            .setContentTitle(title)
            .setContentText(body)
            .setStyle(
                NotificationCompat.BigTextStyle()
                    .bigText("$body\n\nاضغط 'تأكيد وحفظ' لتسجيل المعاملة فوراً وتحديث رصيد المحفظة تلقائياً.")
            )
            .setPriority(NotificationCompat.PRIORITY_HIGH)
            .setCategory(NotificationCompat.CATEGORY_EVENT)
            .setAutoCancel(true)
            .setContentIntent(contentPendingIntent)
            .addAction(
                android.R.drawable.checkbox_on_background,
                "تأكيد وحفظ",
                confirmPendingIntent
            )
            .addAction(
                android.R.drawable.ic_menu_close_clear_cancel,
                "تجاهل",
                dismissPendingIntent
            )
            .setColor(0xFF10B981.toInt())
            .build()

        try {
            NotificationManagerCompat.from(context).notify(notificationId, notification)
        } catch (_: SecurityException) {
            // Notifications permission not granted
        }
    }

    fun updateNotificationToSuccess(
        context: Context,
        notificationId: Int,
        typeStr: String,
        amount: Double,
        walletName: String
    ) {
        val formattedAmount = numberFormat.format(amount)
        val successTitle = "تم حفظ العملية بنجاح ✓"
        val successBody = "تم تسجيل $typeStr بمبلغ $formattedAmount ج.م في محفظة: $walletName"

        // Single tap opens app
        val activityIntent = Intent(context, MainActivity::class.java).apply {
            flags = Intent.FLAG_ACTIVITY_NEW_TASK or Intent.FLAG_ACTIVITY_CLEAR_TOP
        }
        val contentPendingIntent = PendingIntent.getActivity(
            context,
            notificationId,
            activityIntent,
            PendingIntent.FLAG_UPDATE_CURRENT or PendingIntent.FLAG_IMMUTABLE
        )

        val notification = NotificationCompat.Builder(context, CHANNEL_ID)
            .setSmallIcon(R.drawable.ic_launcher_foreground)
            .setContentTitle(successTitle)
            .setContentText(successBody)
            .setStyle(NotificationCompat.BigTextStyle().bigText(successBody))
            .setPriority(NotificationCompat.PRIORITY_DEFAULT)
            .setAutoCancel(true)
            .setContentIntent(contentPendingIntent)
            .setColor(0xFF10B981.toInt())
            .build()

        try {
            NotificationManagerCompat.from(context).notify(notificationId, notification)
        } catch (_: SecurityException) {
            // Ignored
        }
    }

    fun dismissNotification(context: Context, notificationId: Int) {
        try {
            NotificationManagerCompat.from(context).cancel(notificationId)
        } catch (_: Exception) {
        }
    }
}
