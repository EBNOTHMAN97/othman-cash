package com.example.service

import android.app.Notification
import android.service.notification.NotificationListenerService
import android.service.notification.StatusBarNotification
import android.util.Log
import com.example.data.AppDatabase
import com.example.data.model.InterceptedNotification
import kotlinx.coroutines.CoroutineScope
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.launch

class WalletNotificationListenerService : NotificationListenerService() {

    companion object {
        private const val TAG = "WalletNotifListener"
    }

    private val serviceScope = CoroutineScope(Dispatchers.IO)

    override fun onNotificationPosted(sbn: StatusBarNotification?) {
        super.onNotificationPosted(sbn)
        if (sbn == null) return

        val pkgName = sbn.packageName ?: return

        // Ignore notifications posted by our own app to prevent loops
        if (pkgName == packageName) return

        val extras = sbn.notification.extras ?: return
        val title = extras.getCharSequence(Notification.EXTRA_TITLE)?.toString() ?: ""
        val text = extras.getCharSequence(Notification.EXTRA_TEXT)?.toString()
            ?: extras.getCharSequence(Notification.EXTRA_BIG_TEXT)?.toString()
            ?: ""

        if (title.isBlank() && text.isBlank()) return

        Log.d(TAG, "Notification intercepted from $pkgName: Title='$title', Text='$text'")

        val parsed = NotificationParser.parse(title, text, pkgName)
        if (parsed != null) {
            Log.d(TAG, "Parsed Transaction: Type=${parsed.type}, Amount=${parsed.amount}, Target=${parsed.targetNumberOrName}")

            serviceScope.launch {
                try {
                    val database = AppDatabase.getInstance(applicationContext)
                    val walletDao = database.walletDao()
                    val notifDao = database.interceptedNotificationDao()

                    // Log intercepted notification in DB
                    notifDao.insertNotification(
                        InterceptedNotification(
                            packageName = pkgName,
                            title = title,
                            text = text,
                            parsedType = parsed.type.titleAr,
                            parsedAmount = parsed.amount,
                            parsedTarget = parsed.targetNumberOrName,
                            status = "PENDING"
                        )
                    )

                    // Find most appropriate wallet
                    val allWallets = walletDao.getAllWalletsSync()
                    val matchingWallet = allWallets.firstOrNull { wallet ->
                        val lowerPkg = pkgName.lowercase()
                        val lowerName = wallet.name.lowercase()
                        val lowerProv = wallet.provider.lowercase()

                        (lowerPkg.contains("vodafone") || lowerPkg.contains("mysrv")) && (lowerName.contains("فودافون") || lowerProv.contains("vodafone")) ||
                                lowerPkg.contains("instapay") && (lowerName.contains("انستا") || lowerProv.contains("instapay")) ||
                                lowerPkg.contains("orange") && (lowerName.contains("أورنج") || lowerProv.contains("orange")) ||
                                lowerPkg.contains("etisalat") && (lowerName.contains("اتصالات") || lowerProv.contains("etisalat"))
                    } ?: allWallets.firstOrNull()

                    val targetWalletId = matchingWallet?.id ?: 1
                    val notificationId = (System.currentTimeMillis() % 1000000).toInt() + 1000

                    // Fire the High Priority Actionable Notification
                    NotificationHelper.showActionableNotification(
                        context = applicationContext,
                        notificationId = notificationId,
                        typeStr = parsed.type.titleAr,
                        amount = parsed.amount,
                        targetNumber = parsed.targetNumberOrName,
                        referenceNumber = parsed.referenceNumber,
                        walletId = targetWalletId
                    )
                } catch (e: Exception) {
                    Log.e(TAG, "Failed to process intercepted notification", e)
                }
            }
        }
    }

    override fun onNotificationRemoved(sbn: StatusBarNotification?) {
        super.onNotificationRemoved(sbn)
    }
}
