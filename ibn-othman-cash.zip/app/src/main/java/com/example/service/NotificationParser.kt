package com.example.service

import com.example.data.model.TransactionType
import java.util.regex.Pattern

data class ParsedNotificationResult(
    val type: TransactionType,
    val amount: Double,
    val targetNumberOrName: String,
    val referenceNumber: String,
    val originalTitle: String,
    val originalText: String,
    val packageName: String
)

object NotificationParser {

    // Regex for amount with Egyptian Pound / Numbers
    // Matches e.g. "1,500.00", "500", "1500", "250.50", accompanied or preceded/followed by EGP / ج.م / جنيه
    private val amountPatterns = listOf(
        Pattern.compile("""(?:مبلغ|بقيمة|بمبلغ|قيمة|شحن|استلمت|تحويل|إيداع|سحب)\s*[:=]?\s*([0-9]{1,3}(?:,[0-9]{3})+(?:\.[0-9]+)?|[0-9]+(?:\.[0-9]+)?)\s*(?:جنيه|ج\.م|EGP|LE|L\.E|جم)?""", Pattern.CASE_INSENSITIVE),
        Pattern.compile("""([0-9]{1,3}(?:,[0-9]{3})+(?:\.[0-9]+)?|[0-9]+(?:\.[0-9]+)?)\s*(?:جنيه|ج\.م|EGP|LE|L\.E|جم)""", Pattern.CASE_INSENSITIVE),
        Pattern.compile("""(?:EGP|LE|ج\.م|جنيه)\s*([0-9]{1,3}(?:,[0-9]{3})+(?:\.[0-9]+)?|[0-9]+(?:\.[0-9]+)?)""", Pattern.CASE_INSENSITIVE)
    )

    // Regex for Egyptian Phone Numbers (010, 011, 012, 015 + 8 digits) or IPA addresses (username@bank)
    private val phonePattern = Pattern.compile("""(?:إلى|من|للرقم|رقم|حساب)?\s*(01[0125][0-9]{8})""")
    private val ipaPattern = Pattern.compile("""([a-zA-Z0-9._-]+@[a-zA-Z0-9]+)""")

    // Regex for Reference Number / Transaction ID
    private val referencePattern = Pattern.compile("""(?:رقم العملية|المرجع|Ref|ID|كود)?\s*[:#]?\s*([A-Za-z0-9]{6,16})""")

    fun parse(title: String, text: String, packageName: String): ParsedNotificationResult? {
        val combined = "$title $text".trim()
        if (combined.isBlank()) return null

        // 1. Detect Transaction Type
        val lower = combined.lowercase()
        val type = when {
            lower.contains("استلمت") || lower.contains("إيداع") || lower.contains("تم استقبال") ||
                    lower.contains("تم استلام") || lower.contains("شحن رصيد") || lower.contains("deposit") ||
                    lower.contains("received") || lower.contains("credited") -> TransactionType.DEPOSIT

            lower.contains("سحب") || lower.contains("سحب نقدي") || lower.contains("كاش أوت") ||
                    lower.contains("cash out") || lower.contains("withdraw") || lower.contains("atm") -> TransactionType.WITHDRAW

            lower.contains("تحويل") || lower.contains("تم تحويل") || lower.contains("إرسال") ||
                    lower.contains("تم خصم") || lower.contains("transfer") || lower.contains("sent") ||
                    lower.contains("debited") -> TransactionType.TRANSFER

            else -> {
                // If contains money keywords but unclear, check if incoming or outgoing
                if (lower.contains("من") && !lower.contains("إلى")) TransactionType.DEPOSIT
                else if (lower.contains("إلى")) TransactionType.TRANSFER
                else null
            }
        } ?: return null

        // 2. Extract Amount
        var amount: Double? = null
        for (pattern in amountPatterns) {
            val matcher = pattern.matcher(combined)
            if (matcher.find()) {
                val rawNumber = matcher.group(1)?.replace(",", "")
                val parsed = rawNumber?.toDoubleOrNull()
                if (parsed != null && parsed > 0.0) {
                    amount = parsed
                    break
                }
            }
        }

        if (amount == null) return null

        // 3. Extract Target Number / IPA / Name
        var target: String? = null
        val phoneMatcher = phonePattern.matcher(combined)
        if (phoneMatcher.find()) {
            target = phoneMatcher.group(1)
        } else {
            val ipaMatcher = ipaPattern.matcher(combined)
            if (ipaMatcher.find()) {
                target = ipaMatcher.group(1)
            }
        }

        if (target == null) {
            // Fallback: look for names following "من" or "إلى"
            val toFromPattern = Pattern.compile("""(?:إلى|من)\s+([\u0621-\u064A\w\s]{3,25})""")
            val nameMatcher = toFromPattern.matcher(combined)
            if (nameMatcher.find()) {
                target = nameMatcher.group(1)?.trim()
            }
        }

        val finalTarget = target ?: if (type == TransactionType.DEPOSIT) "مرسل غير محدد" else "مستلم غير محدد"

        // 4. Extract Reference Number
        var reference = ""
        val refMatcher = referencePattern.matcher(combined)
        if (refMatcher.find()) {
            reference = refMatcher.group(1) ?: ""
        }

        return ParsedNotificationResult(
            type = type,
            amount = amount,
            targetNumberOrName = finalTarget,
            referenceNumber = reference,
            originalTitle = title,
            originalText = text,
            packageName = packageName
        )
    }
}
