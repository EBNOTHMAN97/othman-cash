package com.example.ui.components

import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.lazy.LazyRow
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.foundation.text.KeyboardOptions
import androidx.compose.foundation.verticalScroll
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.Delete
import androidx.compose.material3.AlertDialog
import androidx.compose.material3.Button
import androidx.compose.material3.ButtonDefaults
import androidx.compose.material3.FilterChip
import androidx.compose.material3.Icon
import androidx.compose.material3.IconButton
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.OutlinedButton
import androidx.compose.material3.OutlinedTextField
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.platform.testTag
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.input.KeyboardType
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.example.data.model.Wallet

@Composable
fun AddEditWalletDialog(
    wallet: Wallet? = null,
    onSave: (name: String, provider: String, accountNum: String, startBal: Double, dailyLim: Double, monthlyLim: Double, colorHex: String) -> Unit,
    onDelete: ((Wallet) -> Unit)? = null,
    onDismiss: () -> Unit
) {
    val isEditing = wallet != null

    var name by remember { mutableStateOf(wallet?.name ?: "") }
    var provider by remember { mutableStateOf(wallet?.provider ?: "Vodafone Cash") }
    var accountNumber by remember { mutableStateOf(wallet?.accountNumber ?: "") }
    var startingBalanceText by remember { mutableStateOf(wallet?.startingBalance?.toInt()?.toString() ?: "10000") }
    var dailyLimitText by remember { mutableStateOf(wallet?.dailyLimit?.toInt()?.toString() ?: "120000") }
    var monthlyLimitText by remember { mutableStateOf(wallet?.monthlyLimit?.toInt()?.toString() ?: "400000") }
    var selectedColor by remember { mutableStateOf(wallet?.colorHex ?: "#10B981") }
    var errorMessage by remember { mutableStateOf<String?>(null) }

    val providers = listOf("Vodafone Cash", "InstaPay", "Orange Cash", "Etisalat Cash", "WE Pay", "Smart Wallet")
    val colorPresets = listOf("#EF4444", "#6366F1", "#F97316", "#10B981", "#F59E0B", "#06B6D4", "#EC4899")

    AlertDialog(
        onDismissRequest = onDismiss,
        modifier = Modifier.testTag("add_edit_wallet_dialog"),
        title = {
            Row(
                modifier = Modifier.fillMaxWidth(),
                horizontalArrangement = Arrangement.SpaceBetween,
                verticalAlignment = Alignment.CenterVertically
            ) {
                Text(
                    text = if (isEditing) "تعديل المحفظة" else "إضافة محفظة جديدة",
                    fontWeight = FontWeight.Bold,
                    fontSize = 18.sp
                )
                if (isEditing && onDelete != null) {
                    IconButton(onClick = { onDelete(wallet) }) {
                        Icon(
                            imageVector = Icons.Default.Delete,
                            contentDescription = "Delete Wallet",
                            tint = MaterialTheme.colorScheme.error
                        )
                    }
                }
            }
        },
        text = {
            Column(
                modifier = Modifier
                    .fillMaxWidth()
                    .verticalScroll(rememberScrollState()),
                verticalArrangement = Arrangement.spacedBy(10.dp)
            ) {
                // Provider Selector
                Text(text = "نوع المحفظة / المشغل:", fontSize = 12.sp, fontWeight = FontWeight.SemiBold)
                LazyRow(horizontalArrangement = Arrangement.spacedBy(6.dp)) {
                    items(providers) { prov ->
                        val isSelected = provider == prov
                        FilterChip(
                            selected = isSelected,
                            onClick = {
                                provider = prov
                                if (name.isBlank() || providers.any { name.startsWith(it) }) {
                                    name = "$prov - "
                                }
                            },
                            label = { Text(prov, fontSize = 11.sp) }
                        )
                    }
                }

                // Name
                OutlinedTextField(
                    value = name,
                    onValueChange = {
                        name = it
                        errorMessage = null
                    },
                    label = { Text("اسم المحفظة") },
                    placeholder = { Text("مثال: فودافون كاش - العمل") },
                    singleLine = true,
                    modifier = Modifier.fillMaxWidth().testTag("wallet_name_input"),
                    shape = RoundedCornerShape(12.dp)
                )

                // Account Number / Phone
                OutlinedTextField(
                    value = accountNumber,
                    onValueChange = { accountNumber = it },
                    label = { Text("رقم الحساب / الهاتف") },
                    placeholder = { Text("010xxxxxxxx أو user@instapay") },
                    singleLine = true,
                    modifier = Modifier.fillMaxWidth(),
                    shape = RoundedCornerShape(12.dp)
                )

                // Starting Balance
                OutlinedTextField(
                    value = startingBalanceText,
                    onValueChange = { startingBalanceText = it },
                    label = { Text("الرصيد الابتدائي (ج.م)") },
                    keyboardOptions = KeyboardOptions(keyboardType = KeyboardType.Number),
                    singleLine = true,
                    modifier = Modifier.fillMaxWidth(),
                    shape = RoundedCornerShape(12.dp)
                )

                // Daily & Monthly Limits
                Row(
                    modifier = Modifier.fillMaxWidth(),
                    horizontalArrangement = Arrangement.spacedBy(8.dp)
                ) {
                    OutlinedTextField(
                        value = dailyLimitText,
                        onValueChange = { dailyLimitText = it },
                        label = { Text("حد يومي") },
                        keyboardOptions = KeyboardOptions(keyboardType = KeyboardType.Number),
                        singleLine = true,
                        modifier = Modifier.weight(1f),
                        shape = RoundedCornerShape(12.dp)
                    )
                    OutlinedTextField(
                        value = monthlyLimitText,
                        onValueChange = { monthlyLimitText = it },
                        label = { Text("حد شهري") },
                        keyboardOptions = KeyboardOptions(keyboardType = KeyboardType.Number),
                        singleLine = true,
                        modifier = Modifier.weight(1f),
                        shape = RoundedCornerShape(12.dp)
                    )
                }

                // Color Selection
                Text(text = "لون تمييز المحفظة:", fontSize = 12.sp, fontWeight = FontWeight.SemiBold)
                Row(
                    modifier = Modifier.fillMaxWidth(),
                    horizontalArrangement = Arrangement.spacedBy(8.dp)
                ) {
                    colorPresets.forEach { hex ->
                        val color = Color(android.graphics.Color.parseColor(hex))
                        val isSelected = selectedColor.equals(hex, ignoreCase = true)
                        Box(
                            modifier = Modifier
                                .size(32.dp)
                                .clip(CircleShape)
                                .background(color)
                                .border(
                                    width = if (isSelected) 3.dp else 1.dp,
                                    color = if (isSelected) Color.White else Color.Transparent,
                                    shape = CircleShape
                                )
                                .clickable { selectedColor = hex }
                        )
                    }
                }

                if (errorMessage != null) {
                    Text(
                        text = errorMessage ?: "",
                        color = MaterialTheme.colorScheme.error,
                        fontSize = 12.sp,
                        fontWeight = FontWeight.Bold
                    )
                }
            }
        },
        confirmButton = {
            Button(
                onClick = {
                    if (name.isBlank()) {
                        errorMessage = "يرجى كتابة اسم المحفظة"
                        return@Button
                    }
                    val startBal = startingBalanceText.toDoubleOrNull() ?: 0.0
                    val dLim = dailyLimitText.toDoubleOrNull() ?: 120_000.0
                    val mLim = monthlyLimitText.toDoubleOrNull() ?: 400_000.0

                    onSave(
                        name.trim(),
                        provider,
                        accountNumber.trim(),
                        startBal,
                        dLim,
                        mLim,
                        selectedColor
                    )
                },
                colors = ButtonDefaults.buttonColors(containerColor = MaterialTheme.colorScheme.primary),
                modifier = Modifier.testTag("save_wallet_btn")
            ) {
                Text(text = if (isEditing) "حفظ التعديلات" else "إضافة المحفظة", fontWeight = FontWeight.Bold)
            }
        },
        dismissButton = {
            OutlinedButton(onClick = onDismiss) {
                Text(text = "إلغاء", color = MaterialTheme.colorScheme.onSurface)
            }
        },
        containerColor = MaterialTheme.colorScheme.surface
    )
}
