package com.example.ui.theme

import androidx.compose.ui.graphics.Color

// Ibn Othman Cash Dark Luxury Theme Palette
val DarkBackground = Color(0xFF1A1C23)
val DarkSurface = Color(0xFF222530)
val DarkSurfaceVariant = Color(0xFF2C3040)
val DarkSurfaceContainer = Color(0xFF252836)

val EmeraldPrimary = Color(0xFF10B981)
val EmeraldLight = Color(0xFF34D399)
val EmeraldDark = Color(0xFF047857)

val GoldSecondary = Color(0xFFF59E0B)
val GoldLight = Color(0xFFFBBF24)

val IndigoTertiary = Color(0xFF6366F1)
val ErrorRed = Color(0xFFEF4444)

val TextPrimary = Color(0xFFF9FAFB)
val TextSecondary = Color(0xFF9CA3AF)
val TextMuted = Color(0xFF6B7280)

val BorderStroke = Color(0xFF323648)
val CardHighlight = Color(0xFF2D3142)
