package com.example.ui.theme

import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.darkColorScheme
import androidx.compose.runtime.Composable
import androidx.compose.ui.graphics.Color

fun getDarkColorScheme(primaryColor: Color = EmeraldPrimary) = darkColorScheme(
    primary = primaryColor,
    onPrimary = Color.White,
    primaryContainer = primaryColor.copy(alpha = 0.2f),
    onPrimaryContainer = Color.White,
    secondary = GoldSecondary,
    onSecondary = Color.Black,
    secondaryContainer = GoldSecondary.copy(alpha = 0.2f),
    onSecondaryContainer = GoldLight,
    tertiary = IndigoTertiary,
    onTertiary = Color.White,
    background = DarkBackground,
    onBackground = TextPrimary,
    surface = DarkSurface,
    onSurface = TextPrimary,
    surfaceVariant = DarkSurfaceVariant,
    onSurfaceVariant = TextSecondary,
    surfaceContainer = DarkSurfaceContainer,
    outline = BorderStroke,
    outlineVariant = BorderStroke.copy(alpha = 0.6f),
    error = ErrorRed,
    onError = Color.White
)

@Composable
fun IbnOthmanCashTheme(
    accentColor: Color = EmeraldPrimary,
    content: @Composable () -> Unit
) {
    MaterialTheme(
        colorScheme = getDarkColorScheme(accentColor),
        typography = Typography,
        content = content
    )
}
