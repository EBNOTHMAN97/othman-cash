package com.example.ui

import android.app.Application
import androidx.lifecycle.AndroidViewModel
import androidx.lifecycle.viewModelScope
import com.example.data.AppDatabase
import com.example.data.model.InterceptedNotification
import com.example.data.model.Transaction
import com.example.data.model.TransactionSource
import com.example.data.model.TransactionType
import com.example.data.model.Wallet
import com.example.data.preferences.UserPreferences
import com.example.data.preferences.UserPreferencesRepository
import com.example.data.repository.WalletRepository
import com.example.service.NotificationHelper
import kotlinx.coroutines.flow.MutableStateFlow
import kotlinx.coroutines.flow.SharingStarted
import kotlinx.coroutines.flow.StateFlow
import kotlinx.coroutines.flow.asStateFlow
import kotlinx.coroutines.flow.combine
import kotlinx.coroutines.flow.stateIn
import kotlinx.coroutines.launch
import org.json.JSONArray
import org.json.JSONObject
import java.util.Calendar

data class IncomingTransactionPrompt(
    val type: String,
    val amount: Double,
    val targetNumber: String,
    val reference: String,
    val notificationId: Int,
    val initialWalletId: Int
)

data class DashboardMetrics(
    val totalBalance: Double = 0.0,
    val todayConsumption: Double = 0.0,
    val todayDeposits: Double = 0.0,
    val dailyLimit: Double = 120_000.0,
    val dailyProgress: Float = 0f,
    val monthlyConsumption: Double = 0.0,
    val monthlyDeposits: Double = 0.0,
    val monthlyLimit: Double = 400_000.0,
    val monthlyProgress: Float = 0f
)

class MainViewModel(application: Application) : AndroidViewModel(application) {

    private val database = AppDatabase.getInstance(application)
    private val repository = WalletRepository(database)
    private val preferencesRepository = UserPreferencesRepository(application)

    val wallets: StateFlow<List<Wallet>> = repository.allWallets
        .stateIn(viewModelScope, SharingStarted.WhileSubscribed(5000), emptyList())

    val transactions: StateFlow<List<Transaction>> = repository.allTransactions
        .stateIn(viewModelScope, SharingStarted.WhileSubscribed(5000), emptyList())

    val recentTransactions: StateFlow<List<Transaction>> = repository.recentTransactions
        .stateIn(viewModelScope, SharingStarted.WhileSubscribed(5000), emptyList())

    val interceptedNotifications: StateFlow<List<InterceptedNotification>> = repository.interceptedNotifications
        .stateIn(viewModelScope, SharingStarted.WhileSubscribed(5000), emptyList())

    val userPreferences: StateFlow<UserPreferences> = preferencesRepository.userPreferencesFlow
        .stateIn(viewModelScope, SharingStarted.WhileSubscribed(5000), UserPreferences())

    // Dashboard metrics derived from wallets, transactions, and user preferences
    val dashboardMetrics: StateFlow<DashboardMetrics> = combine(
        wallets,
        transactions,
        userPreferences
    ) { currentWallets, currentTransactions, prefs ->
        val totalBal = currentWallets.sumOf { it.currentBalance }

        val startOfDay = getStartOfDayTimestamp()
        val startOfMonth = getStartOfMonthTimestamp()

        var todayCons = 0.0
        var todayDep = 0.0
        var monthCons = 0.0
        var monthDep = 0.0

        for (tx in currentTransactions) {
            if (tx.timestamp >= startOfDay) {
                if (tx.type.isDeduction) todayCons += tx.amount
                else todayDep += tx.amount
            }
            if (tx.timestamp >= startOfMonth) {
                if (tx.type.isDeduction) monthCons += tx.amount
                else monthDep += tx.amount
            }
        }

        val dLimit = prefs.dailyLimitCap.coerceAtLeast(1.0)
        val mLimit = prefs.monthlyLimitCap.coerceAtLeast(1.0)

        DashboardMetrics(
            totalBalance = totalBal,
            todayConsumption = todayCons,
            todayDeposits = todayDep,
            dailyLimit = dLimit,
            dailyProgress = (todayCons / dLimit).toFloat().coerceIn(0f, 1f),
            monthlyConsumption = monthCons,
            monthlyDeposits = monthDep,
            monthlyLimit = mLimit,
            monthlyProgress = (monthCons / mLimit).toFloat().coerceIn(0f, 1f)
        )
    }.stateIn(viewModelScope, SharingStarted.WhileSubscribed(5000), DashboardMetrics())

    // Incoming Notification Review Dialog state
    private val _incomingTxPrompt = MutableStateFlow<IncomingTransactionPrompt?>(null)
    val incomingTxPrompt: StateFlow<IncomingTransactionPrompt?> = _incomingTxPrompt.asStateFlow()

    // "Bubble Modal" UX Enhancement State: shown after manually saving a transaction
    private val _showBubbleModal = MutableStateFlow(false)
    val showBubbleModal: StateFlow<Boolean> = _showBubbleModal.asStateFlow()

    // Flag indicating if bottom sheet should be reset for a new transaction
    private val _resetFormTrigger = MutableStateFlow(0)
    val resetFormTrigger: StateFlow<Int> = _resetFormTrigger.asStateFlow()

    // Flag indicating if the bottom sheet should close
    private val _dismissBottomSheetTrigger = MutableStateFlow(0)
    val dismissBottomSheetTrigger: StateFlow<Int> = _dismissBottomSheetTrigger.asStateFlow()

    fun setIncomingTxPrompt(prompt: IncomingTransactionPrompt?) {
        _incomingTxPrompt.value = prompt
    }

    fun dismissIncomingTxPrompt() {
        val current = _incomingTxPrompt.value
        if (current != null) {
            NotificationHelper.dismissNotification(getApplication(), current.notificationId)
        }
        _incomingTxPrompt.value = null
    }

    fun confirmIncomingTransaction(walletId: Int) {
        val prompt = _incomingTxPrompt.value ?: return
        viewModelScope.launch {
            val type = TransactionType.fromString(prompt.type)
            val tx = Transaction(
                walletId = walletId,
                type = type,
                amount = prompt.amount,
                targetNumberOrName = prompt.targetNumber,
                note = "تأكيد عبر واجهة التطبيق",
                referenceNumber = prompt.reference,
                isConfirmed = true,
                source = TransactionSource.NOTIFICATION_INTERCEPTED,
                timestamp = System.currentTimeMillis()
            )
            repository.insertTransaction(tx)

            val wallet = wallets.value.find { it.id == walletId }
            NotificationHelper.updateNotificationToSuccess(
                context = getApplication(),
                notificationId = prompt.notificationId,
                typeStr = type.titleAr,
                amount = prompt.amount,
                walletName = wallet?.name ?: "المحفظة"
            )
            _incomingTxPrompt.value = null
        }
    }

    // Manual Transaction Creation
    fun addManualTransaction(
        walletId: Int,
        type: TransactionType,
        amount: Double,
        targetNumberOrName: String,
        note: String,
        reference: String
    ) {
        viewModelScope.launch {
            val tx = Transaction(
                walletId = walletId,
                type = type,
                amount = amount,
                targetNumberOrName = targetNumberOrName,
                note = note,
                referenceNumber = reference,
                isConfirmed = true,
                source = TransactionSource.MANUAL,
                timestamp = System.currentTimeMillis()
            )
            repository.insertTransaction(tx)
            // Trigger the Bubble Modal
            _showBubbleModal.value = true
        }
    }

    fun onBubbleModalNewTransaction() {
        _showBubbleModal.value = false
        _resetFormTrigger.value += 1
    }

    fun onBubbleModalFinish() {
        _showBubbleModal.value = false
        _dismissBottomSheetTrigger.value += 1
    }

    fun dismissBubbleModal() {
        _showBubbleModal.value = false
    }

    // Wallets CRUD
    fun addWallet(
        name: String,
        provider: String,
        accountNumber: String,
        startingBalance: Double,
        dailyLimit: Double,
        monthlyLimit: Double,
        colorHex: String
    ) {
        viewModelScope.launch {
            val wallet = Wallet(
                name = name,
                provider = provider,
                accountNumber = accountNumber,
                startingBalance = startingBalance,
                currentBalance = startingBalance,
                dailyLimit = dailyLimit,
                monthlyLimit = monthlyLimit,
                colorHex = colorHex
            )
            repository.insertWallet(wallet)
        }
    }

    fun updateWallet(wallet: Wallet) {
        viewModelScope.launch {
            repository.updateWallet(wallet)
        }
    }

    fun deleteWallet(wallet: Wallet) {
        viewModelScope.launch {
            repository.deleteWallet(wallet)
        }
    }

    // Transaction CRUD
    fun updateTransaction(oldTx: Transaction, newTx: Transaction) {
        viewModelScope.launch {
            repository.updateTransaction(oldTx, newTx)
        }
    }

    fun deleteTransaction(transaction: Transaction) {
        viewModelScope.launch {
            repository.deleteTransaction(transaction)
        }
    }

    // Settings actions
    fun updateThemeAccent(hex: String) {
        viewModelScope.launch { preferencesRepository.updateThemeAccent(hex) }
    }

    fun updateCurrency(currency: String) {
        viewModelScope.launch { preferencesRepository.updateCurrency(currency) }
    }

    fun updateOwnerDetails(name: String, phone: String, business: String) {
        viewModelScope.launch { preferencesRepository.updateOwnerDetails(name, phone, business) }
    }

    fun updateLimits(daily: Double, monthly: Double) {
        viewModelScope.launch { preferencesRepository.updateLimits(daily, monthly) }
    }

    fun clearNotifications() {
        viewModelScope.launch { repository.clearNotifications() }
    }

    fun clearAllTransactions() {
        viewModelScope.launch { repository.deleteAllTransactions() }
    }

    // Notification Simulator (For testing background interception and direct actions!)
    fun simulateIncomingNotification(
        provider: String,
        type: TransactionType,
        amount: Double,
        targetNumber: String
    ) {
        viewModelScope.launch {
            val notifId = (System.currentTimeMillis() % 1000000).toInt() + 2000
            val matchingWallet = wallets.value.firstOrNull {
                it.provider.contains(provider, ignoreCase = true) || it.name.contains(provider, ignoreCase = true)
            } ?: wallets.value.firstOrNull()

            val walletId = matchingWallet?.id ?: 1

            // Log to database
            repository.logInterceptedNotification(
                InterceptedNotification(
                    packageName = when (provider) {
                        "InstaPay" -> "com.egyptianbanks.instapay"
                        "Vodafone Cash" -> "com.emeint.android.mysrv"
                        "Orange Cash" -> "com.orange.orangecash"
                        else -> "com.android.mms"
                    },
                    title = "إشعار تجريبي: $provider",
                    text = "تم تنفيذ عملية ${type.titleAr} بمبلغ $amount ج.م إلى/من $targetNumber",
                    parsedType = type.titleAr,
                    parsedAmount = amount,
                    parsedTarget = targetNumber,
                    status = "PENDING"
                )
            )

            // Fire real actionable notification
            NotificationHelper.showActionableNotification(
                context = getApplication(),
                notificationId = notifId,
                typeStr = type.titleAr,
                amount = amount,
                targetNumber = targetNumber,
                referenceNumber = "SIM-${(100000..999999).random()}",
                walletId = walletId
            )
        }
    }

    // Backup & Restore JSON
    fun exportBackupJson(): String {
        val root = JSONObject()
        val currentWallets = wallets.value
        val currentTx = transactions.value

        val walletsArray = JSONArray()
        for (w in currentWallets) {
            val obj = JSONObject().apply {
                put("id", w.id)
                put("name", w.name)
                put("provider", w.provider)
                put("accountNumber", w.accountNumber)
                put("startingBalance", w.startingBalance)
                put("currentBalance", w.currentBalance)
                put("dailyLimit", w.dailyLimit)
                put("monthlyLimit", w.monthlyLimit)
                put("colorHex", w.colorHex)
            }
            walletsArray.put(obj)
        }
        root.put("wallets", walletsArray)

        val txArray = JSONArray()
        for (t in currentTx) {
            val obj = JSONObject().apply {
                put("id", t.id)
                put("walletId", t.walletId)
                put("type", t.type.name)
                put("amount", t.amount)
                put("targetNumberOrName", t.targetNumberOrName)
                put("note", t.note)
                put("referenceNumber", t.referenceNumber)
                put("timestamp", t.timestamp)
            }
            txArray.put(obj)
        }
        root.put("transactions", txArray)
        root.put("exportDate", System.currentTimeMillis())

        return root.toString(2)
    }

    fun restoreBackupJson(jsonString: String): Boolean {
        return try {
            val root = JSONObject(jsonString)
            val walletsArray = root.optJSONArray("wallets")
            val txArray = root.optJSONArray("transactions")

            viewModelScope.launch {
                if (walletsArray != null) {
                    for (i in 0 until walletsArray.length()) {
                        val obj = walletsArray.getJSONObject(i)
                        repository.insertWallet(
                            Wallet(
                                name = obj.getString("name"),
                                provider = obj.optString("provider", "General"),
                                accountNumber = obj.optString("accountNumber", ""),
                                startingBalance = obj.optDouble("startingBalance", 0.0),
                                currentBalance = obj.optDouble("currentBalance", 0.0),
                                dailyLimit = obj.optDouble("dailyLimit", 120_000.0),
                                monthlyLimit = obj.optDouble("monthlyLimit", 400_000.0),
                                colorHex = obj.optString("colorHex", "#10B981")
                            )
                        )
                    }
                }
                if (txArray != null) {
                    for (i in 0 until txArray.length()) {
                        val obj = txArray.getJSONObject(i)
                        repository.insertTransaction(
                            Transaction(
                                walletId = obj.getInt("walletId"),
                                type = TransactionType.fromString(obj.getString("type")),
                                amount = obj.getDouble("amount"),
                                targetNumberOrName = obj.optString("targetNumberOrName", ""),
                                note = obj.optString("note", ""),
                                referenceNumber = obj.optString("referenceNumber", ""),
                                isConfirmed = true,
                                source = TransactionSource.MANUAL,
                                timestamp = obj.optLong("timestamp", System.currentTimeMillis())
                            )
                        )
                    }
                }
            }
            true
        } catch (e: Exception) {
            false
        }
    }

    private fun getStartOfDayTimestamp(): Long {
        val calendar = Calendar.getInstance().apply {
            set(Calendar.HOUR_OF_DAY, 0)
            set(Calendar.MINUTE, 0)
            set(Calendar.SECOND, 0)
            set(Calendar.MILLISECOND, 0)
        }
        return calendar.timeInMillis
    }

    private fun getStartOfMonthTimestamp(): Long {
        val calendar = Calendar.getInstance().apply {
            set(Calendar.DAY_OF_MONTH, 1)
            set(Calendar.HOUR_OF_DAY, 0)
            set(Calendar.MINUTE, 0)
            set(Calendar.SECOND, 0)
            set(Calendar.MILLISECOND, 0)
        }
        return calendar.timeInMillis
    }
}
