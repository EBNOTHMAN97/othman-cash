package com.example.data.dao

import androidx.room.Dao
import androidx.room.Insert
import androidx.room.OnConflictStrategy
import androidx.room.Query
import com.example.data.model.InterceptedNotification
import kotlinx.coroutines.flow.Flow

@Dao
interface InterceptedNotificationDao {
    @Query("SELECT * FROM intercepted_notifications ORDER BY timestamp DESC")
    fun getAllNotifications(): Flow<List<InterceptedNotification>>

    @Insert(onConflict = OnConflictStrategy.REPLACE)
    suspend fun insertNotification(notification: InterceptedNotification): Long

    @Query("UPDATE intercepted_notifications SET status = :status WHERE id = :id")
    suspend fun updateNotificationStatus(id: Long, status: String)

    @Query("DELETE FROM intercepted_notifications")
    suspend fun clearNotifications()
}
