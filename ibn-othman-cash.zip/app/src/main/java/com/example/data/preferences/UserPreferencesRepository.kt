package com.example.data.preferences

import android.content.Context
import androidx.datastore.core.DataStore
import androidx.datastore.preferences.core.Preferences
import androidx.datastore.preferences.core.booleanPreferencesKey
import androidx.datastore.preferences.core.doublePreferencesKey
import androidx.datastore.preferences.core.edit
import androidx.datastore.preferences.core.stringPreferencesKey
import androidx.datastore.preferences.preferencesDataStore
import kotlinx.coroutines.flow.Flow
import kotlinx.coroutines.flow.map

private val Context.dataStore: DataStore<Preferences> by preferencesDataStore(name = "ibn_othman_prefs")

data class UserPreferences(
    val themeAccent: String = "#10B981",
    val currencySymbol: String = "ج.م",
    val ownerName: String = "إبن عثمان",
    val ownerPhone: String = "01098765432",
    val businessName: String = "إبن عثمان كاش",
    val dailyLimitCap: Double = 120_000.0,
    val monthlyLimitCap: Double = 400_000.0,
    val soundVibration: Boolean = true
)

class UserPreferencesRepository(private val context: Context) {
    companion object {
        val KEY_THEME_ACCENT = stringPreferencesKey("theme_accent")
        val KEY_CURRENCY = stringPreferencesKey("currency_symbol")
        val KEY_OWNER_NAME = stringPreferencesKey("owner_name")
        val KEY_OWNER_PHONE = stringPreferencesKey("owner_phone")
        val KEY_BUSINESS_NAME = stringPreferencesKey("business_name")
        val KEY_DAILY_LIMIT = doublePreferencesKey("daily_limit_cap")
        val KEY_MONTHLY_LIMIT = doublePreferencesKey("monthly_limit_cap")
        val KEY_SOUND_VIBRATION = booleanPreferencesKey("sound_vibration")
    }

    val userPreferencesFlow: Flow<UserPreferences> = context.dataStore.data.map { prefs ->
        UserPreferences(
            themeAccent = prefs[KEY_THEME_ACCENT] ?: "#10B981",
            currencySymbol = prefs[KEY_CURRENCY] ?: "ج.م",
            ownerName = prefs[KEY_OWNER_NAME] ?: "إبن عثمان",
            ownerPhone = prefs[KEY_OWNER_PHONE] ?: "01098765432",
            businessName = prefs[KEY_BUSINESS_NAME] ?: "إبن عثمان كاش",
            dailyLimitCap = prefs[KEY_DAILY_LIMIT] ?: 120_000.0,
            monthlyLimitCap = prefs[KEY_MONTHLY_LIMIT] ?: 400_000.0,
            soundVibration = prefs[KEY_SOUND_VIBRATION] ?: true
        )
    }

    suspend fun updateThemeAccent(accentHex: String) {
        context.dataStore.edit { it[KEY_THEME_ACCENT] = accentHex }
    }

    suspend fun updateCurrency(currency: String) {
        context.dataStore.edit { it[KEY_CURRENCY] = currency }
    }

    suspend fun updateOwnerDetails(name: String, phone: String, business: String) {
        context.dataStore.edit {
            it[KEY_OWNER_NAME] = name
            it[KEY_OWNER_PHONE] = phone
            it[KEY_BUSINESS_NAME] = business
        }
    }

    suspend fun updateLimits(daily: Double, monthly: Double) {
        context.dataStore.edit {
            it[KEY_DAILY_LIMIT] = daily
            it[KEY_MONTHLY_LIMIT] = monthly
        }
    }

    suspend fun toggleSoundVibration(enabled: Boolean) {
        context.dataStore.edit { it[KEY_SOUND_VIBRATION] = enabled }
    }
}
