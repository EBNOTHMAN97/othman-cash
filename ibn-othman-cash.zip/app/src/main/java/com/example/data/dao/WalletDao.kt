package com.example.data.dao

import androidx.room.Dao
import androidx.room.Delete
import androidx.room.Insert
import androidx.room.OnConflictStrategy
import androidx.room.Query
import androidx.room.Update
import com.example.data.model.Wallet
import kotlinx.coroutines.flow.Flow

@Dao
interface WalletDao {
    @Query("SELECT * FROM wallets ORDER BY id ASC")
    fun getAllWallets(): Flow<List<Wallet>>

    @Query("SELECT * FROM wallets ORDER BY id ASC")
    suspend fun getAllWalletsSync(): List<Wallet>

    @Query("SELECT * FROM wallets WHERE id = :id LIMIT 1")
    fun getWalletById(id: Int): Flow<Wallet?>

    @Query("SELECT * FROM wallets WHERE id = :id LIMIT 1")
    suspend fun getWalletByIdSync(id: Int): Wallet?

    @Query("SELECT * FROM wallets LIMIT 1")
    suspend fun getFirstWalletSync(): Wallet?

    @Insert(onConflict = OnConflictStrategy.REPLACE)
    suspend fun insertWallet(wallet: Wallet): Long

    @Update
    suspend fun updateWallet(wallet: Wallet)

    @Delete
    suspend fun deleteWallet(wallet: Wallet)

    @Query("UPDATE wallets SET currentBalance = :newBalance WHERE id = :walletId")
    suspend fun updateBalance(walletId: Int, newBalance: Double)
}
