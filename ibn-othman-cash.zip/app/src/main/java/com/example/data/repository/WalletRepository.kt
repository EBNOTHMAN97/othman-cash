package com.example.data.repository

import com.example.data.AppDatabase
import com.example.data.model.InterceptedNotification
import com.example.data.model.Transaction
import com.example.data.model.TransactionType
import com.example.data.model.Wallet
import kotlinx.coroutines.flow.Flow
import java.util.Calendar

class WalletRepository(private val database: AppDatabase) {
    private val walletDao = database.walletDao()
    private val transactionDao = database.transactionDao()
    private val interceptedNotificationDao = database.interceptedNotificationDao()

    val allWallets: Flow<List<Wallet>> = walletDao.getAllWallets()
    val allTransactions: Flow<List<Transaction>> = transactionDao.getAllTransactions()
    val recentTransactions: Flow<List<Transaction>> = transactionDao.getRecentTransactions(30)
    val interceptedNotifications: Flow<List<InterceptedNotification>> = interceptedNotificationDao.getAllNotifications()

    fun getTransactionsByWallet(walletId: Int): Flow<List<Transaction>> =
        transactionDao.getTransactionsByWallet(walletId)

    suspend fun insertWallet(wallet: Wallet): Long = walletDao.insertWallet(wallet)

    suspend fun updateWallet(wallet: Wallet) = walletDao.updateWallet(wallet)

    suspend fun deleteWallet(wallet: Wallet) = walletDao.deleteWallet(wallet)

    suspend fun insertTransaction(transaction: Transaction): Long {
        val insertedId = transactionDao.insertTransaction(transaction)

        // Update corresponding wallet's balance
        val wallet = walletDao.getWalletByIdSync(transaction.walletId)
        if (wallet != null) {
            val balanceDiff = if (transaction.type == TransactionType.DEPOSIT) {
                transaction.amount
            } else {
                -transaction.amount
            }
            walletDao.updateBalance(wallet.id, wallet.currentBalance + balanceDiff)
        }

        return insertedId
    }

    suspend fun updateTransaction(oldTransaction: Transaction, newTransaction: Transaction) {
        transactionDao.updateTransaction(newTransaction)

        // Adjust wallet balances if wallet or amount/type changed
        if (oldTransaction.walletId == newTransaction.walletId) {
            val wallet = walletDao.getWalletByIdSync(newTransaction.walletId)
            if (wallet != null) {
                val oldDiff = if (oldTransaction.type == TransactionType.DEPOSIT) oldTransaction.amount else -oldTransaction.amount
                val newDiff = if (newTransaction.type == TransactionType.DEPOSIT) newTransaction.amount else -newTransaction.amount
                val netAdjustment = newDiff - oldDiff
                walletDao.updateBalance(wallet.id, wallet.currentBalance + netAdjustment)
            }
        } else {
            // Revert old wallet
            val oldWallet = walletDao.getWalletByIdSync(oldTransaction.walletId)
            if (oldWallet != null) {
                val oldDiff = if (oldTransaction.type == TransactionType.DEPOSIT) oldTransaction.amount else -oldTransaction.amount
                walletDao.updateBalance(oldWallet.id, oldWallet.currentBalance - oldDiff)
            }
            // Apply new wallet
            val newWallet = walletDao.getWalletByIdSync(newTransaction.walletId)
            if (newWallet != null) {
                val newDiff = if (newTransaction.type == TransactionType.DEPOSIT) newTransaction.amount else -newTransaction.amount
                walletDao.updateBalance(newWallet.id, newWallet.currentBalance + newDiff)
            }
        }
    }

    suspend fun deleteTransaction(transaction: Transaction) {
        transactionDao.deleteTransaction(transaction)
        val wallet = walletDao.getWalletByIdSync(transaction.walletId)
        if (wallet != null) {
            val revertDiff = if (transaction.type == TransactionType.DEPOSIT) -transaction.amount else transaction.amount
            walletDao.updateBalance(wallet.id, wallet.currentBalance + revertDiff)
        }
    }

    suspend fun logInterceptedNotification(notification: InterceptedNotification): Long =
        interceptedNotificationDao.insertNotification(notification)

    suspend fun updateNotificationStatus(id: Long, status: String) =
        interceptedNotificationDao.updateNotificationStatus(id, status)

    suspend fun clearNotifications() = interceptedNotificationDao.clearNotifications()

    suspend fun deleteAllTransactions() {
        transactionDao.deleteAllTransactions()
        // Reset wallet balances to starting balances
        val wallets = walletDao.getAllWalletsSync()
        for (w in wallets) {
            walletDao.updateBalance(w.id, w.startingBalance)
        }
    }

    suspend fun getTodayStartTimestamp(): Long {
        val calendar = Calendar.getInstance().apply {
            set(Calendar.HOUR_OF_DAY, 0)
            set(Calendar.MINUTE, 0)
            set(Calendar.SECOND, 0)
            set(Calendar.MILLISECOND, 0)
        }
        return calendar.timeInMillis
    }

    suspend fun getMonthStartTimestamp(): Long {
        val calendar = Calendar.getInstance().apply {
            set(Calendar.DAY_OF_MONTH, 1)
            set(Calendar.HOUR_OF_DAY, 0)
            set(Calendar.MINUTE, 0)
            set(Calendar.SECOND, 0)
            set(Calendar.MILLISECOND, 0)
        }
        return calendar.timeInMillis
    }
}
