package com.example.data

import android.content.Context
import androidx.room.Database
import androidx.room.Room
import androidx.room.RoomDatabase
import androidx.sqlite.db.SupportSQLiteDatabase
import com.example.data.dao.InterceptedNotificationDao
import com.example.data.dao.TransactionDao
import com.example.data.dao.WalletDao
import com.example.data.model.InterceptedNotification
import com.example.data.model.Transaction
import com.example.data.model.TransactionSource
import com.example.data.model.TransactionType
import com.example.data.model.Wallet
import kotlinx.coroutines.CoroutineScope
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.launch

@Database(
    entities = [
        Wallet::class,
        Transaction::class,
        InterceptedNotification::class
    ],
    version = 1,
    exportSchema = false
)
abstract class AppDatabase : RoomDatabase() {
    abstract fun walletDao(): WalletDao
    abstract fun transactionDao(): TransactionDao
    abstract fun interceptedNotificationDao(): InterceptedNotificationDao

    companion object {
        @Volatile
        private var INSTANCE: AppDatabase? = null

        fun getInstance(context: Context): AppDatabase {
            return INSTANCE ?: synchronized(this) {
                val instance = Room.databaseBuilder(
                    context.applicationContext,
                    AppDatabase::class.java,
                    "ibn_othman_cash_db"
                )
                    .fallbackToDestructiveMigration()
                    .addCallback(DatabaseCallback())
                    .build()
                INSTANCE = instance
                instance
            }
        }

        private class DatabaseCallback : RoomDatabase.Callback() {
            override fun onCreate(db: SupportSQLiteDatabase) {
                super.onCreate(db)
                INSTANCE?.let { database ->
                    CoroutineScope(Dispatchers.IO).launch {
                        populateInitialData(database)
                    }
                }
            }

            private suspend fun populateInitialData(database: AppDatabase) {
                val walletDao = database.walletDao()
                val transactionDao = database.transactionDao()

                // Default initial Wallets
                val w1Id = walletDao.insertWallet(
                    Wallet(
                        name = "فودافون كاش - الحساب الرئيسي",
                        provider = "Vodafone Cash",
                        accountNumber = "01098765432",
                        startingBalance = 25000.0,
                        currentBalance = 32500.0,
                        dailyLimit = 120000.0,
                        monthlyLimit = 400000.0,
                        colorHex = "#EF4444" // Red
                    )
                ).toInt()

                val w2Id = walletDao.insertWallet(
                    Wallet(
                        name = "انستاباي - البنك الأهلي",
                        provider = "InstaPay",
                        accountNumber = "ibn.othman@instapay",
                        startingBalance = 50000.0,
                        currentBalance = 68400.0,
                        dailyLimit = 120000.0,
                        monthlyLimit = 400000.0,
                        colorHex = "#6366F1" // Indigo
                    )
                ).toInt()

                val w3Id = walletDao.insertWallet(
                    Wallet(
                        name = "أورنج كاش - مبيعات",
                        provider = "Orange Cash",
                        accountNumber = "01234567890",
                        startingBalance = 12000.0,
                        currentBalance = 15200.0,
                        dailyLimit = 120000.0,
                        monthlyLimit = 400000.0,
                        colorHex = "#F97316" // Orange
                    )
                ).toInt()

                val now = System.currentTimeMillis()
                val oneHourAgo = now - 3600_000
                val twoHoursAgo = now - 7200_000
                val yesterday = now - 86400_000

                // Sample transactions demonstrating daily and monthly consumption
                transactionDao.insertTransaction(
                    Transaction(
                        walletId = w1Id,
                        type = TransactionType.TRANSFER,
                        amount = 4500.0,
                        targetNumberOrName = "01023456789 - أحمد محمود",
                        note = "دفعة مستحقات توريد",
                        referenceNumber = "VF984120",
                        isConfirmed = true,
                        source = TransactionSource.MANUAL,
                        timestamp = oneHourAgo
                    )
                )

                transactionDao.insertTransaction(
                    Transaction(
                        walletId = w2Id,
                        type = TransactionType.DEPOSIT,
                        amount = 18400.0,
                        targetNumberOrName = "مؤسسة الأمل للتجارة",
                        note = "تحويل انستاباي فوري",
                        referenceNumber = "IP7723901",
                        isConfirmed = true,
                        source = TransactionSource.NOTIFICATION_INTERCEPTED,
                        timestamp = twoHoursAgo
                    )
                )

                transactionDao.insertTransaction(
                    Transaction(
                        walletId = w1Id,
                        type = TransactionType.WITHDRAW,
                        amount = 2000.0,
                        targetNumberOrName = "فرع فودافون - كاش أوت",
                        note = "سحب نقدي لمصاريف النقل",
                        referenceNumber = "VF983011",
                        isConfirmed = true,
                        source = TransactionSource.MANUAL,
                        timestamp = yesterday
                    )
                )

                transactionDao.insertTransaction(
                    Transaction(
                        walletId = w3Id,
                        type = TransactionType.TRANSFER,
                        amount = 3200.0,
                        targetNumberOrName = "01288765432 - مروان علي",
                        note = "شحن بضاعة",
                        referenceNumber = "OR553120",
                        isConfirmed = true,
                        source = TransactionSource.MANUAL,
                        timestamp = now - 1800_000
                    )
                )
            }
        }
    }
}
