package com.example.data.model

import androidx.room.Entity
import androidx.room.PrimaryKey

@Entity(tableName = "intercepted_notifications")
data class InterceptedNotification(
    @PrimaryKey(autoGenerate = true)
    val id: Long = 0,
    val packageName: String,
    val title: String,
    val text: String,
    val parsedType: String?,
    val parsedAmount: Double?,
    val parsedTarget: String?,
    val status: String, // "PENDING", "CONFIRMED", "IGNORED", "MANUALLY_SAVED"
    val timestamp: Long = System.currentTimeMillis()
)
