package com.example.data.model

import androidx.room.Entity
import androidx.room.PrimaryKey

@Entity(tableName = "wallets")
data class Wallet(
    @PrimaryKey(autoGenerate = true)
    val id: Int = 0,
    val name: String,
    val provider: String,          // e.g. "Vodafone Cash", "InstaPay", "Orange Cash", "Etisalat Cash", "WE Pay", "Bank"
    val accountNumber: String,     // e.g. "01012345678" or IPA handle
    val startingBalance: Double,
    val currentBalance: Double,
    val dailyLimit: Double = 120_000.0,
    val monthlyLimit: Double = 400_000.0,
    val colorHex: String = "#10B981",
    val createdAt: Long = System.currentTimeMillis()
)
