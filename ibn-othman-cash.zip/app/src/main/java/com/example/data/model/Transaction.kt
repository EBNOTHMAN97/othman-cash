package com.example.data.model

import androidx.room.Entity
import androidx.room.ForeignKey
import androidx.room.Index
import androidx.room.PrimaryKey

enum class TransactionType(val titleAr: String, val isDeduction: Boolean) {
    DEPOSIT("إيداع", false),
    TRANSFER("تحويل", true),
    WITHDRAW("سحب", true);

    companion object {
        fun fromString(value: String): TransactionType {
            return when (value.trim()) {
                "إيداع", "DEPOSIT", "Deposit" -> DEPOSIT
                "تحويل", "TRANSFER", "Transfer" -> TRANSFER
                "سحب", "WITHDRAW", "Withdraw" -> WITHDRAW
                else -> TRANSFER
            }
        }
    }
}

enum class TransactionSource {
    MANUAL,
    NOTIFICATION_INTERCEPTED
}

@Entity(
    tableName = "transactions",
    foreignKeys = [
        ForeignKey(
            entity = Wallet::class,
            parentColumns = ["id"],
            childColumns = ["walletId"],
            onDelete = ForeignKey.CASCADE
        )
    ],
    indices = [Index(value = ["walletId"])]
)
data class Transaction(
    @PrimaryKey(autoGenerate = true)
    val id: Long = 0,
    val walletId: Int,
    val type: TransactionType,
    val amount: Double,
    val targetNumberOrName: String,
    val note: String = "",
    val referenceNumber: String = "",
    val isConfirmed: Boolean = true,
    val source: TransactionSource = TransactionSource.MANUAL,
    val timestamp: Long = System.currentTimeMillis()
)
