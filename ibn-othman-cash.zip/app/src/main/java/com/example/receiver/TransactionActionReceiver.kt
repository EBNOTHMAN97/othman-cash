package com.example.receiver

import android.content.BroadcastReceiver
import android.content.Context
import android.content.Intent
import android.util.Log
import com.example.data.AppDatabase
import com.example.data.model.Transaction
import com.example.data.model.TransactionSource
import com.example.data.model.TransactionType
import com.example.service.NotificationHelper
import kotlinx.coroutines.CoroutineScope
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.launch

class TransactionActionReceiver : BroadcastReceiver() {

    companion object {
        private const val TAG = "TxActionReceiver"
    }

    override fun onReceive(context: Context, intent: Intent) {
        val action = intent.action ?: return
        Log.d(TAG, "Received broadcast action: $action")

        val notificationId = intent.getIntExtra(NotificationHelper.EXTRA_NOTIFICATION_ID, 0)

        if (action == NotificationHelper.ACTION_DISMISS_NOTIFICATION) {
            NotificationHelper.dismissNotification(context, notificationId)
            return
        }

        if (action == NotificationHelper.ACTION_CONFIRM_TRANSACTION) {
            val pendingResult = goAsync()

            val typeStr = intent.getStringExtra(NotificationHelper.EXTRA_TX_TYPE) ?: "TRANSFER"
            val amount = intent.getDoubleExtra(NotificationHelper.EXTRA_TX_AMOUNT, 0.0)
            val target = intent.getStringExtra(NotificationHelper.EXTRA_TX_TARGET) ?: "غير محدد"
            val refNumber = intent.getStringExtra(NotificationHelper.EXTRA_TX_REF) ?: ""
            val walletIdExtra = intent.getIntExtra(NotificationHelper.EXTRA_WALLET_ID, -1)

            CoroutineScope(Dispatchers.IO).launch {
                try {
                    val database = AppDatabase.getInstance(context)
                    val walletDao = database.walletDao()
                    val transactionDao = database.transactionDao()

                    // Find target wallet: requested walletId, or first available wallet
                    val targetWallet = if (walletIdExtra > 0) {
                        walletDao.getWalletByIdSync(walletIdExtra) ?: walletDao.getFirstWalletSync()
                    } else {
                        walletDao.getFirstWalletSync()
                    }

                    if (targetWallet != null && amount > 0.0) {
                        val type = TransactionType.fromString(typeStr)

                        // 1. Insert transaction
                        val transaction = Transaction(
                            walletId = targetWallet.id,
                            type = type,
                            amount = amount,
                            targetNumberOrName = target,
                            note = "تأكيد سريع عبر إشعار المعاملة",
                            referenceNumber = refNumber,
                            isConfirmed = true,
                            source = TransactionSource.NOTIFICATION_INTERCEPTED,
                            timestamp = System.currentTimeMillis()
                        )
                        transactionDao.insertTransaction(transaction)

                        // 2. Atomically update wallet balance
                        val balanceAdjustment = if (type == TransactionType.DEPOSIT) amount else -amount
                        walletDao.updateBalance(targetWallet.id, targetWallet.currentBalance + balanceAdjustment)

                        Log.d(TAG, "Transaction saved successfully in background into wallet: ${targetWallet.name}")

                        // 3. Update notification to visual success feedback without action buttons
                        NotificationHelper.updateNotificationToSuccess(
                            context = context,
                            notificationId = notificationId,
                            typeStr = type.titleAr,
                            amount = amount,
                            walletName = targetWallet.name
                        )
                    } else {
                        Log.e(TAG, "Failed to save: No wallet available or invalid amount: $amount")
                    }
                } catch (e: Exception) {
                    Log.e(TAG, "Error saving transaction in background", e)
                } finally {
                    pendingResult.finish()
                }
            }
        }
    }
}
