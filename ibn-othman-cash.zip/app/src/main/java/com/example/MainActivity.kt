package com.example

import android.Manifest
import android.content.Intent
import android.content.pm.PackageManager
import android.os.Build
import android.os.Bundle
import androidx.activity.ComponentActivity
import androidx.activity.compose.BackHandler
import androidx.activity.compose.rememberLauncherForActivityResult
import androidx.activity.compose.setContent
import androidx.activity.enableEdgeToEdge
import androidx.activity.result.contract.ActivityResultContracts
import androidx.activity.viewModels
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.WindowInsets
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.automirrored.filled.ReceiptLong
import androidx.compose.material.icons.filled.AccountBalanceWallet
import androidx.compose.material.icons.filled.Add
import androidx.compose.material.icons.filled.Home
import androidx.compose.material.icons.filled.MailOutline
import androidx.compose.material.icons.filled.Settings
import androidx.compose.material3.ExperimentalMaterial3Api
import androidx.compose.material3.FloatingActionButton
import androidx.compose.material3.Icon
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.NavigationBar
import androidx.compose.material3.NavigationBarItem
import androidx.compose.material3.NavigationBarItemDefaults
import androidx.compose.material3.Scaffold
import androidx.compose.material3.Text
import androidx.compose.material3.rememberModalBottomSheetState
import androidx.compose.runtime.Composable
import androidx.compose.runtime.CompositionLocalProvider
import androidx.compose.runtime.LaunchedEffect
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.rememberCoroutineScope
import androidx.compose.runtime.setValue
import androidx.compose.ui.Modifier
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.platform.LocalLayoutDirection
import androidx.compose.ui.platform.testTag
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.LayoutDirection
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import androidx.core.content.ContextCompat
import androidx.lifecycle.compose.collectAsStateWithLifecycle
import com.example.service.NotificationHelper
import com.example.ui.IncomingTransactionPrompt
import com.example.ui.MainViewModel
import com.example.ui.components.AddTransactionBottomSheet
import com.example.ui.components.BubbleModalDialog
import com.example.ui.components.IncomingTxConfirmationDialog
import com.example.ui.screens.HomeScreen
import com.example.ui.screens.MessagesScreen
import com.example.ui.screens.SettingsScreen
import com.example.ui.screens.TransactionsScreen
import com.example.ui.screens.WalletsScreen
import com.example.ui.theme.DarkBackground
import com.example.ui.theme.DarkSurface
import com.example.ui.theme.EmeraldPrimary
import com.example.ui.theme.IbnOthmanCashTheme
import kotlinx.coroutines.launch

enum class ScreenTab(val titleAr: String) {
    HOME("الرئيسية"),
    WALLETS("المحافظ"),
    TRANSACTIONS("المعاملات"),
    MESSAGES("الإشعارات"),
    SETTINGS("الإعدادات")
}

class MainActivity : ComponentActivity() {

    private val viewModel: MainViewModel by viewModels()

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        enableEdgeToEdge()

        // Create notification channel
        NotificationHelper.createNotificationChannel(this)

        // Handle incoming intent if opened from notification tap
        handleNotificationIntent(intent)

        setContent {
            val userPrefs by viewModel.userPreferences.collectAsStateWithLifecycle()
            val accentColor = remember(userPrefs.themeAccent) {
                try {
                    Color(android.graphics.Color.parseColor(userPrefs.themeAccent))
                } catch (_: Exception) {
                    EmeraldPrimary
                }
            }

            IbnOthmanCashTheme(accentColor = accentColor) {
                // Request Notification Permission on Android 13+
                RequestNotificationPermission()

                // Support Right-to-Left (Arabic) layout direction natively
                CompositionLocalProvider(LocalLayoutDirection provides LayoutDirection.Rtl) {
                    MainAppContent(viewModel = viewModel)
                }
            }
        }
    }

    override fun onNewIntent(intent: Intent) {
        super.onNewIntent(intent)
        setIntent(intent)
        handleNotificationIntent(intent)
    }

    private fun handleNotificationIntent(intent: Intent?) {
        if (intent == null) return
        val showConfirm = intent.getBooleanExtra(NotificationHelper.EXTRA_SHOW_CONFIRM_DIALOG, false)
        if (showConfirm) {
            val typeStr = intent.getStringExtra(NotificationHelper.EXTRA_TX_TYPE) ?: "TRANSFER"
            val amount = intent.getDoubleExtra(NotificationHelper.EXTRA_TX_AMOUNT, 0.0)
            val target = intent.getStringExtra(NotificationHelper.EXTRA_TX_TARGET) ?: "غير محدد"
            val ref = intent.getStringExtra(NotificationHelper.EXTRA_TX_REF) ?: ""
            val notifId = intent.getIntExtra(NotificationHelper.EXTRA_NOTIFICATION_ID, 0)
            val walletId = intent.getIntExtra(NotificationHelper.EXTRA_WALLET_ID, 1)

            viewModel.setIncomingTxPrompt(
                IncomingTransactionPrompt(
                    type = typeStr,
                    amount = amount,
                    targetNumber = target,
                    reference = ref,
                    notificationId = notifId,
                    initialWalletId = walletId
                )
            )
        }
    }

    @Composable
    private fun RequestNotificationPermission() {
        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.TIRAMISU) {
            val permissionGranted = ContextCompat.checkSelfPermission(
                this,
                Manifest.permission.POST_NOTIFICATIONS
            ) == PackageManager.PERMISSION_GRANTED

            val permissionLauncher = rememberLauncherForActivityResult(
                contract = ActivityResultContracts.RequestPermission()
            ) { /* Permission result handled */ }

            LaunchedEffect(Unit) {
                if (!permissionGranted) {
                    permissionLauncher.launch(Manifest.permission.POST_NOTIFICATIONS)
                }
            }
        }
    }
}

@OptIn(ExperimentalMaterial3Api::class)
@Composable
fun MainAppContent(viewModel: MainViewModel) {
    var currentTab by remember { mutableStateOf(ScreenTab.HOME) }
    var showAddTxBottomSheet by remember { mutableStateOf(false) }
    val sheetState = rememberModalBottomSheetState(skipPartiallyExpanded = true)
    val coroutineScope = rememberCoroutineScope()

    val wallets by viewModel.wallets.collectAsStateWithLifecycle()
    val showBubbleModal by viewModel.showBubbleModal.collectAsStateWithLifecycle()
    val incomingPrompt by viewModel.incomingTxPrompt.collectAsStateWithLifecycle()
    val resetTrigger by viewModel.resetFormTrigger.collectAsStateWithLifecycle()
    val dismissTrigger by viewModel.dismissBottomSheetTrigger.collectAsStateWithLifecycle()

    // Handle back button: if not on Home screen, go back to Home
    BackHandler(enabled = currentTab != ScreenTab.HOME) {
        currentTab = ScreenTab.HOME
    }

    // Dismiss bottom sheet when requested by ViewModel (e.g. from Bubble Modal "إنهاء")
    LaunchedEffect(dismissTrigger) {
        if (dismissTrigger > 0) {
            coroutineScope.launch {
                sheetState.hide()
                showAddTxBottomSheet = false
            }
        }
    }

    Scaffold(
        modifier = Modifier.fillMaxSize(),
        containerColor = DarkBackground,
        contentWindowInsets = WindowInsets(0, 0, 0, 0),
        bottomBar = {
            NavigationBar(
                containerColor = DarkSurface,
                tonalElevation = 8.dp,
                modifier = Modifier.testTag("bottom_nav_bar")
            ) {
                val navItems = listOf(
                    ScreenTab.HOME to Icons.Default.Home,
                    ScreenTab.WALLETS to Icons.Default.AccountBalanceWallet,
                    ScreenTab.TRANSACTIONS to Icons.AutoMirrored.Filled.ReceiptLong,
                    ScreenTab.MESSAGES to Icons.Default.MailOutline,
                    ScreenTab.SETTINGS to Icons.Default.Settings
                )

                navItems.forEach { (tab, icon) ->
                    val isSelected = currentTab == tab
                    NavigationBarItem(
                        selected = isSelected,
                        onClick = { currentTab = tab },
                        icon = {
                            Icon(
                                imageVector = icon,
                                contentDescription = tab.titleAr,
                                modifier = Modifier.size(24.dp)
                            )
                        },
                        label = {
                            Text(
                                text = tab.titleAr,
                                fontSize = 11.sp,
                                fontWeight = if (isSelected) FontWeight.Bold else FontWeight.Normal
                            )
                        },
                        colors = NavigationBarItemDefaults.colors(
                            selectedIconColor = MaterialTheme.colorScheme.primary,
                            selectedTextColor = MaterialTheme.colorScheme.primary,
                            indicatorColor = MaterialTheme.colorScheme.primaryContainer,
                            unselectedIconColor = MaterialTheme.colorScheme.onSurfaceVariant,
                            unselectedTextColor = MaterialTheme.colorScheme.onSurfaceVariant
                        ),
                        modifier = Modifier.testTag("nav_tab_${tab.name.lowercase()}")
                    )
                }
            }
        },
        floatingActionButton = {
            FloatingActionButton(
                onClick = { showAddTxBottomSheet = true },
                shape = CircleShape,
                containerColor = MaterialTheme.colorScheme.primary,
                contentColor = Color.White,
                modifier = Modifier
                    .size(56.dp)
                    .testTag("fab_add_transaction")
            ) {
                Icon(
                    imageVector = Icons.Default.Add,
                    contentDescription = "تسجيل معاملة جديدة",
                    modifier = Modifier.size(28.dp)
                )
            }
        }
    ) { innerPadding ->
        Box(
            modifier = Modifier
                .fillMaxSize()
                .padding(innerPadding)
        ) {
            when (currentTab) {
                ScreenTab.HOME -> HomeScreen(
                    viewModel = viewModel,
                    onNavigateToTransactions = { currentTab = ScreenTab.TRANSACTIONS }
                )
                ScreenTab.WALLETS -> WalletsScreen(viewModel = viewModel)
                ScreenTab.TRANSACTIONS -> TransactionsScreen(viewModel = viewModel)
                ScreenTab.MESSAGES -> MessagesScreen(viewModel = viewModel)
                ScreenTab.SETTINGS -> SettingsScreen(viewModel = viewModel)
            }
        }
    }

    // Modal Bottom Sheet to Manually Add a Transaction
    if (showAddTxBottomSheet) {
        AddTransactionBottomSheet(
            wallets = wallets,
            sheetState = sheetState,
            resetTrigger = resetTrigger,
            onDismissRequest = {
                showAddTxBottomSheet = false
            },
            onSaveTransaction = { walletId, type, amount, target, note, ref ->
                viewModel.addManualTransaction(
                    walletId = walletId,
                    type = type,
                    amount = amount,
                    targetNumberOrName = target,
                    note = note,
                    reference = ref
                )
            }
        )
    }

    // The "Bubble Modal" (UX Enhancement after saving manual transaction)
    if (showBubbleModal) {
        BubbleModalDialog(
            onNewTransaction = {
                viewModel.onBubbleModalNewTransaction()
            },
            onFinish = {
                viewModel.onBubbleModalFinish()
            },
            onDismiss = {
                viewModel.dismissBubbleModal()
            }
        )
    }

    // Incoming Transaction Confirmation Dialog (when tapped from notification body)
    if (incomingPrompt != null) {
        IncomingTxConfirmationDialog(
            prompt = incomingPrompt!!,
            wallets = wallets,
            onConfirm = { walletId ->
                viewModel.confirmIncomingTransaction(walletId)
            },
            onDismiss = {
                viewModel.dismissIncomingTxPrompt()
            }
        )
    }
}
