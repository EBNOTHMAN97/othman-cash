package com.example

import com.example.data.model.TransactionType
import com.example.service.NotificationParser
import org.junit.Assert.assertEquals
import org.junit.Assert.assertNotNull
import org.junit.Test

class ExampleUnitTest {

    @Test
    fun addition_isCorrect() {
        assertEquals(4, 2 + 2)
    }

    @Test
    fun testNotificationParserForVodafoneCashTransfer() {
        val title = "فودافون كاش"
        val text = "تم تحويل مبلغ 1500 جنيه بنجاح إلى 01012345678 رقم العملية VF98412"
        val parsed = NotificationParser.parse(title, text, "com.emeint.android.mysrv")

        assertNotNull(parsed)
        assertEquals(TransactionType.TRANSFER, parsed?.type)
        assertEquals(1500.0, parsed?.amount ?: 0.0, 0.01)
        assertEquals("01012345678", parsed?.targetNumberOrName)
    }

    @Test
    fun testNotificationParserForInstapayDeposit() {
        val title = "InstaPay"
        val text = "تم استقبال مبلغ 3500.50 EGP من ahmed@instapay كود 98214"
        val parsed = NotificationParser.parse(title, text, "com.egyptianbanks.instapay")

        assertNotNull(parsed)
        assertEquals(TransactionType.DEPOSIT, parsed?.type)
        assertEquals(3500.50, parsed?.amount ?: 0.0, 0.01)
        assertEquals("ahmed@instapay", parsed?.targetNumberOrName)
    }

    @Test
    fun testNotificationParserForWithdrawal() {
        val title = "أورنج كاش"
        val text = "تم تنفيذ سحب نقدي بمبلغ 2000 ج.م من ماكينة ATM بنك مصر"
        val parsed = NotificationParser.parse(title, text, "com.orange.orangecash")

        assertNotNull(parsed)
        assertEquals(TransactionType.WITHDRAW, parsed?.type)
        assertEquals(2000.0, parsed?.amount ?: 0.0, 0.01)
    }
}
