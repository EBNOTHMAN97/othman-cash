import type { IncomingMessage, ServerResponse } from 'http';
import { isNeonConfigured, getSqlClient, ensureSchemaInitialized } from './db.js';
import { parseJsonBody } from './utils.js';

interface RequestWithBody extends IncomingMessage {
  query?: Record<string, string>;
  body?: any;
}

export default async function handler(req: RequestWithBody, res: ServerResponse) {
  res.setHeader('Content-Type', 'application/json');
  res.setHeader('Access-Control-Allow-Origin', '*');
  res.setHeader('Access-Control-Allow-Methods', 'GET, POST, PUT, DELETE, OPTIONS');
  res.setHeader('Access-Control-Allow-Headers', 'Content-Type');

  if (req.method === 'OPTIONS') {
    res.statusCode = 204;
    res.end();
    return;
  }

  if (!isNeonConfigured()) {
    res.statusCode = 200;
    res.end(JSON.stringify({ success: false, message: 'Neon database not configured', transactions: [] }));
    return;
  }

  try {
    await ensureSchemaInitialized();
    const sql = getSqlClient();

    if (req.method === 'GET') {
      const url = new URL(req.url || '', 'http://localhost');
      const limitParam = parseInt(url.searchParams.get('limit') || '500', 10);
      const walletId = url.searchParams.get('walletId');

      let rows;
      if (walletId) {
        rows = await sql`
          SELECT 
            id,
            wallet_id as "walletId",
            type,
            amount::float as amount,
            balance_after::float as "balanceAfter",
            timestamp,
            recipient_phone as "recipientPhone",
            recipient_name as "recipientName",
            related_wallet_id as "relatedWalletId",
            reference_number as "referenceNumber",
            category,
            notes,
            fee::float as fee
          FROM transactions
          WHERE wallet_id = ${walletId}
          ORDER BY timestamp DESC
          LIMIT ${limitParam};
        `;
      } else {
        rows = await sql`
          SELECT 
            id,
            wallet_id as "walletId",
            type,
            amount::float as amount,
            balance_after::float as "balanceAfter",
            timestamp,
            recipient_phone as "recipientPhone",
            recipient_name as "recipientName",
            related_wallet_id as "relatedWalletId",
            reference_number as "referenceNumber",
            category,
            notes,
            fee::float as fee
          FROM transactions
          ORDER BY timestamp DESC
          LIMIT ${limitParam};
        `;
      }

      res.statusCode = 200;
      res.end(JSON.stringify({ success: true, transactions: rows }));
      return;
    }

    if (req.method === 'POST' || req.method === 'PUT') {
      const body = await parseJsonBody(req);
      const {
        id,
        walletId,
        type,
        amount,
        balanceAfter = null,
        timestamp = body.timestamp || body.date || new Date().toISOString(),
        recipientPhone = null,
        recipientName = null,
        relatedWalletId = null,
        referenceNumber = null,
        category = null,
        notes = null,
        fee = 0,
      } = body;

      if (!id || !walletId || !type || amount === undefined) {
        res.statusCode = 400;
        res.end(JSON.stringify({ error: 'Missing required transaction fields' }));
        return;
      }

      await sql`
        INSERT INTO transactions (
          id, wallet_id, type, amount, balance_after, timestamp,
          recipient_phone, recipient_name, related_wallet_id,
          reference_number, category, notes, fee
        ) VALUES (
          ${id}, ${walletId}, ${type}, ${amount}, ${balanceAfter}, ${timestamp},
          ${recipientPhone}, ${recipientName}, ${relatedWalletId},
          ${referenceNumber}, ${category}, ${notes}, ${fee}
        )
        ON CONFLICT (id) DO UPDATE SET
          wallet_id = EXCLUDED.wallet_id,
          type = EXCLUDED.type,
          amount = EXCLUDED.amount,
          balance_after = EXCLUDED.balance_after,
          timestamp = EXCLUDED.timestamp,
          recipient_phone = EXCLUDED.recipient_phone,
          recipient_name = EXCLUDED.recipient_name,
          related_wallet_id = EXCLUDED.related_wallet_id,
          reference_number = EXCLUDED.reference_number,
          category = EXCLUDED.category,
          notes = EXCLUDED.notes,
          fee = EXCLUDED.fee;
      `;

      res.statusCode = 200;
      res.end(JSON.stringify({ success: true, message: 'Transaction saved to Neon successfully' }));
      return;
    }

    if (req.method === 'DELETE') {
      const body = await parseJsonBody(req);
      const url = new URL(req.url || '', 'http://localhost');
      const id = body.id || url.searchParams.get('id');

      if (!id) {
        res.statusCode = 400;
        res.end(JSON.stringify({ error: 'Missing transaction ID' }));
        return;
      }

      await sql`DELETE FROM transactions WHERE id = ${id};`;
      res.statusCode = 200;
      res.end(JSON.stringify({ success: true, message: 'Transaction deleted successfully' }));
      return;
    }

    res.statusCode = 405;
    res.end(JSON.stringify({ error: 'Method not allowed' }));
  } catch (err: any) {
    res.statusCode = 500;
    res.end(JSON.stringify({ error: err.message || 'Database error' }));
  }
}
