import { neon } from '@neondatabase/serverless';

// Retrieve database URL from environment variable
export function getDatabaseUrl(): string | null {
  return process.env.DATABASE_URL || process.env.POSTGRES_URL || null;
}

// Check if Neon database is configured
export function isNeonConfigured(): boolean {
  const url = getDatabaseUrl();
  return Boolean(url && url.trim().length > 0 && !url.includes('PLACEHOLDER'));
}

// Get Neon SQL client
export function getSqlClient() {
  const url = getDatabaseUrl();
  if (!url) {
    throw new Error('DATABASE_URL is not configured. Please set DATABASE_URL in Vercel or your .env file.');
  }
  return neon(url);
}

// Auto-initialize schema on first call if tables do not exist
let schemaInitialized = false;

export async function ensureSchemaInitialized() {
  if (schemaInitialized) return;
  if (!isNeonConfigured()) return;

  try {
    const sql = getSqlClient();

    // 1. Wallets table
    await sql`
      CREATE TABLE IF NOT EXISTS wallets (
        id VARCHAR(64) PRIMARY KEY,
        name VARCHAR(128) NOT NULL,
        provider VARCHAR(32) NOT NULL,
        account_number VARCHAR(64) NOT NULL,
        balance NUMERIC(15, 2) NOT NULL DEFAULT 0,
        daily_limit NUMERIC(15, 2) NOT NULL DEFAULT 0,
        daily_spent NUMERIC(15, 2) NOT NULL DEFAULT 0,
        monthly_limit NUMERIC(15, 2) NOT NULL DEFAULT 0,
        monthly_spent NUMERIC(15, 2) NOT NULL DEFAULT 0,
        is_active BOOLEAN NOT NULL DEFAULT true,
        color VARCHAR(32) DEFAULT '#10b981',
        note TEXT,
        last_updated TIMESTAMPTZ DEFAULT NOW(),
        created_at TIMESTAMPTZ DEFAULT NOW()
      );
    `;

    // 2. Transactions table
    await sql`
      CREATE TABLE IF NOT EXISTS transactions (
        id VARCHAR(64) PRIMARY KEY,
        wallet_id VARCHAR(64) NOT NULL,
        type VARCHAR(32) NOT NULL,
        amount NUMERIC(15, 2) NOT NULL,
        balance_after NUMERIC(15, 2) NOT NULL,
        timestamp TIMESTAMPTZ DEFAULT NOW(),
        recipient_phone VARCHAR(64),
        recipient_name VARCHAR(128),
        related_wallet_id VARCHAR(64),
        reference_number VARCHAR(64),
        category VARCHAR(128),
        notes TEXT,
        fee NUMERIC(15, 2) DEFAULT 0,
        created_at TIMESTAMPTZ DEFAULT NOW()
      );
    `;

    // Index on wallet_id and timestamp for rapid transaction listing
    await sql`
      CREATE INDEX IF NOT EXISTS idx_transactions_wallet ON transactions(wallet_id);
    `;
    await sql`
      CREATE INDEX IF NOT EXISTS idx_transactions_timestamp ON transactions(timestamp DESC);
    `;

    // 3. Expense Categories table
    await sql`
      CREATE TABLE IF NOT EXISTS expense_categories (
        id VARCHAR(64) PRIMARY KEY,
        name VARCHAR(128) NOT NULL,
        color VARCHAR(32) NOT NULL,
        icon VARCHAR(64),
        is_default BOOLEAN DEFAULT false,
        created_at TIMESTAMPTZ DEFAULT NOW()
      );
    `;

    // 4. App Settings / metadata table
    await sql`
      CREATE TABLE IF NOT EXISTS app_settings (
        key VARCHAR(64) PRIMARY KEY,
        value JSONB NOT NULL,
        updated_at TIMESTAMPTZ DEFAULT NOW()
      );
    `;

    schemaInitialized = true;
  } catch (error) {
    console.error('Failed to auto-initialize Neon schema:', error);
    // Don't throw so app continues with error reporting
  }
}
