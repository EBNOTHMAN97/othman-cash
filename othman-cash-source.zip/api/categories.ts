import type { IncomingMessage, ServerResponse } from 'http';
import { isNeonConfigured, getSqlClient, ensureSchemaInitialized } from './db.js';
import { parseJsonBody } from './utils.js';

interface RequestWithBody extends IncomingMessage {
  query?: Record<string, string>;
  body?: any;
}

export default async function handler(req: RequestWithBody, res: ServerResponse) {
  res.setHeader('Content-Type', 'application/json');
  res.setHeader('Access-Control-Allow-Origin', '*');
  res.setHeader('Access-Control-Allow-Methods', 'GET, POST, DELETE, OPTIONS');
  res.setHeader('Access-Control-Allow-Headers', 'Content-Type');

  if (req.method === 'OPTIONS') {
    res.statusCode = 204;
    res.end();
    return;
  }

  if (!isNeonConfigured()) {
    res.statusCode = 200;
    res.end(JSON.stringify({ success: false, categories: [] }));
    return;
  }

  try {
    await ensureSchemaInitialized();
    const sql = getSqlClient();

    if (req.method === 'GET') {
      const rows = await sql`
        SELECT 
          id, 
          name, 
          color, 
          icon, 
          is_default as "isDefault" 
        FROM expense_categories
        ORDER BY created_at ASC;
      `;
      res.statusCode = 200;
      res.end(JSON.stringify({ success: true, categories: rows }));
      return;
    }

    if (req.method === 'POST') {
      const body = await parseJsonBody(req);
      const { id, name, color, icon = null, isDefault = false } = body;

      if (!id || !name || !color) {
        res.statusCode = 400;
        res.end(JSON.stringify({ error: 'Missing id, name, or color' }));
        return;
      }

      await sql`
        INSERT INTO expense_categories (id, name, color, icon, is_default)
        VALUES (${id}, ${name}, ${color}, ${icon}, ${isDefault})
        ON CONFLICT (id) DO UPDATE SET
          name = EXCLUDED.name,
          color = EXCLUDED.color,
          icon = EXCLUDED.icon;
      `;

      res.statusCode = 200;
      res.end(JSON.stringify({ success: true }));
      return;
    }

    if (req.method === 'DELETE') {
      const body = await parseJsonBody(req);
      const url = new URL(req.url || '', 'http://localhost');
      const id = body.id || url.searchParams.get('id');

      if (!id) {
        res.statusCode = 400;
        res.end(JSON.stringify({ error: 'Missing category id' }));
        return;
      }

      await sql`DELETE FROM expense_categories WHERE id = ${id};`;
      res.statusCode = 200;
      res.end(JSON.stringify({ success: true }));
      return;
    }

    res.statusCode = 405;
    res.end(JSON.stringify({ error: 'Method not allowed' }));
  } catch (err: any) {
    res.statusCode = 500;
    res.end(JSON.stringify({ error: err.message || 'Database error' }));
  }
}
