import type { IncomingMessage, ServerResponse } from 'http';
import { isNeonConfigured, getSqlClient, ensureSchemaInitialized } from './db.js';
import { parseJsonBody } from './utils.js';

interface RequestWithBody extends IncomingMessage {
  query?: Record<string, string>;
  body?: any;
}

export default async function handler(req: RequestWithBody, res: ServerResponse) {
  res.setHeader('Content-Type', 'application/json');
  res.setHeader('Access-Control-Allow-Origin', '*');
  res.setHeader('Access-Control-Allow-Methods', 'GET, POST, OPTIONS');
  res.setHeader('Access-Control-Allow-Headers', 'Content-Type');

  if (req.method === 'OPTIONS') {
    res.statusCode = 204;
    res.end();
    return;
  }

  if (!isNeonConfigured()) {
    res.statusCode = 200;
    res.end(
      JSON.stringify({
        success: false,
        neonConfigured: false,
        message: 'Neon database not configured',
      })
    );
    return;
  }

  try {
    await ensureSchemaInitialized();
    const sql = getSqlClient();

    if (req.method === 'GET') {
      const wallets = await sql`
        SELECT 
          id,
          name,
          provider,
          account_number as "accountNumber",
          balance::float as balance,
          daily_limit::float as "dailyLimit",
          daily_spent::float as "dailySpent",
          monthly_limit::float as "monthlyLimit",
          monthly_spent::float as "monthlySpent",
          is_active as "isActive",
          color,
          note,
          last_updated as "lastUpdated"
        FROM wallets
        ORDER BY created_at ASC;
      `;

      const transactions = await sql`
        SELECT 
          id,
          wallet_id as "walletId",
          type,
          amount::float as amount,
          balance_after::float as "balanceAfter",
          timestamp,
          recipient_phone as "recipientPhone",
          recipient_name as "recipientName",
          related_wallet_id as "relatedWalletId",
          reference_number as "referenceNumber",
          category,
          notes,
          fee::float as fee
        FROM transactions
        ORDER BY timestamp DESC
        LIMIT 1000;
      `;

      const categories = await sql`
        SELECT 
          id, 
          name, 
          color, 
          icon, 
          is_default as "isDefault" 
        FROM expense_categories
        ORDER BY created_at ASC;
      `;

      const [defaultWalletSetting] = await sql`
        SELECT value FROM app_settings WHERE key = 'default_transfer_wallet_id';
      `;

      res.statusCode = 200;
      res.end(
        JSON.stringify({
          success: true,
          neonConfigured: true,
          wallets,
          transactions,
          categories,
          defaultTransferWalletId: (defaultWalletSetting as any)?.value || null,
        })
      );
      return;
    }

    if (req.method === 'POST') {
      const body = await parseJsonBody(req);
      const { wallets = [], transactions = [], categories = [], defaultTransferWalletId } = body;

      // 1. Bulk Upsert Wallets
      for (const w of wallets) {
        await sql`
          INSERT INTO wallets (
            id, name, provider, account_number, balance, daily_limit, daily_spent, monthly_limit, monthly_spent, is_active, color, note, last_updated
          ) VALUES (
            ${w.id}, ${w.name}, ${w.provider}, ${w.accountNumber || ''}, ${w.balance || 0}, 
            ${w.dailyLimit || 0}, ${w.dailySpent || 0}, ${w.monthlyLimit || 0}, ${w.monthlySpent || 0}, 
            ${w.isActive !== false}, ${w.color || '#10b981'}, ${w.note || ''}, NOW()
          )
          ON CONFLICT (id) DO UPDATE SET
            name = EXCLUDED.name,
            provider = EXCLUDED.provider,
            account_number = EXCLUDED.account_number,
            balance = EXCLUDED.balance,
            daily_limit = EXCLUDED.daily_limit,
            daily_spent = EXCLUDED.daily_spent,
            monthly_limit = EXCLUDED.monthly_limit,
            monthly_spent = EXCLUDED.monthly_spent,
            is_active = EXCLUDED.is_active,
            color = EXCLUDED.color,
            note = EXCLUDED.note,
            last_updated = NOW();
        `;
      }

      // 2. Bulk Upsert Transactions
      for (const t of transactions) {
        await sql`
          INSERT INTO transactions (
            id, wallet_id, type, amount, balance_after, timestamp,
            recipient_phone, recipient_name, related_wallet_id,
            reference_number, category, notes, fee
          ) VALUES (
            ${t.id}, ${t.walletId}, ${t.type}, ${t.amount || 0}, ${t.balanceAfter || 0}, ${t.timestamp || new Date().toISOString()},
            ${t.recipientPhone || null}, ${t.recipientName || null}, ${t.relatedWalletId || null},
            ${t.referenceNumber || null}, ${t.category || null}, ${t.notes || null}, ${t.fee || 0}
          )
          ON CONFLICT (id) DO UPDATE SET
            amount = EXCLUDED.amount,
            balance_after = EXCLUDED.balance_after,
            recipient_phone = EXCLUDED.recipient_phone,
            recipient_name = EXCLUDED.recipient_name,
            category = EXCLUDED.category,
            notes = EXCLUDED.notes,
            fee = EXCLUDED.fee;
        `;
      }

      // 3. Bulk Upsert Categories
      for (const c of categories) {
        await sql`
          INSERT INTO expense_categories (id, name, color, icon, is_default)
          VALUES (${c.id}, ${c.name}, ${c.color}, ${c.icon || null}, ${c.isDefault || false})
          ON CONFLICT (id) DO UPDATE SET
            name = EXCLUDED.name,
            color = EXCLUDED.color,
            icon = EXCLUDED.icon;
        `;
      }

      // 4. Update default wallet setting if provided
      if (defaultTransferWalletId) {
        await sql`
          INSERT INTO app_settings (key, value, updated_at)
          VALUES ('default_transfer_wallet_id', ${JSON.stringify(defaultTransferWalletId)}, NOW())
          ON CONFLICT (key) DO UPDATE SET
            value = EXCLUDED.value,
            updated_at = NOW();
        `;
      }

      res.statusCode = 200;
      res.end(
        JSON.stringify({
          success: true,
          message: 'Bulk data synchronized to Neon PostgreSQL successfully!',
          counts: {
            wallets: wallets.length,
            transactions: transactions.length,
            categories: categories.length,
          },
        })
      );
      return;
    }

    res.statusCode = 405;
    res.end(JSON.stringify({ error: 'Method not allowed' }));
  } catch (err: any) {
    res.statusCode = 500;
    res.end(JSON.stringify({ error: err.message || 'Sync error' }));
  }
}
