import type { IncomingMessage, ServerResponse } from 'http';
import { isNeonConfigured, getSqlClient, ensureSchemaInitialized } from './db.js';

interface RequestWithBody extends IncomingMessage {
  query?: Record<string, string>;
  body?: any;
}

export default async function handler(req: RequestWithBody, res: ServerResponse) {
  res.setHeader('Content-Type', 'application/json');
  res.setHeader('Access-Control-Allow-Origin', '*');
  res.setHeader('Access-Control-Allow-Methods', 'GET, OPTIONS');
  res.setHeader('Access-Control-Allow-Headers', 'Content-Type');

  if (req.method === 'OPTIONS') {
    res.statusCode = 204;
    res.end();
    return;
  }

  const configured = isNeonConfigured();

  if (!configured) {
    res.statusCode = 200;
    res.end(
      JSON.stringify({
        status: 'ok',
        platform: 'vercel',
        neonConfigured: false,
        message: 'Neon DATABASE_URL is not set yet. App is operating in local/offline mode.',
      })
    );
    return;
  }

  try {
    await ensureSchemaInitialized();
    const sql = getSqlClient();
    const [result] = await sql`SELECT NOW() as current_time, current_database() as db_name;`;

    // Count wallets and transactions
    const [walletCount] = await sql`SELECT count(*)::int as count FROM wallets;`;
    const [txCount] = await sql`SELECT count(*)::int as count FROM transactions;`;

    res.statusCode = 200;
    res.end(
      JSON.stringify({
        status: 'connected',
        platform: 'vercel',
        neonConfigured: true,
        database: (result as any)?.db_name || 'neondb',
        serverTime: (result as any)?.current_time,
        counts: {
          wallets: (walletCount as any)?.count || 0,
          transactions: (txCount as any)?.count || 0,
        },
        message: 'Connected to Neon PostgreSQL successfully!',
      })
    );
  } catch (err: any) {
    res.statusCode = 500;
    res.end(
      JSON.stringify({
        status: 'error',
        neonConfigured: true,
        error: err.message || 'Failed to connect to Neon database',
      })
    );
  }
}
