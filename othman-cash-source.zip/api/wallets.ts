import type { IncomingMessage, ServerResponse } from 'http';
import { isNeonConfigured, getSqlClient, ensureSchemaInitialized } from './db.js';
import { parseJsonBody } from './utils.js';

interface RequestWithBody extends IncomingMessage {
  query?: Record<string, string>;
  body?: any;
}

export default async function handler(req: RequestWithBody, res: ServerResponse) {
  res.setHeader('Content-Type', 'application/json');
  res.setHeader('Access-Control-Allow-Origin', '*');
  res.setHeader('Access-Control-Allow-Methods', 'GET, POST, PUT, DELETE, OPTIONS');
  res.setHeader('Access-Control-Allow-Headers', 'Content-Type');

  if (req.method === 'OPTIONS') {
    res.statusCode = 204;
    res.end();
    return;
  }

  if (!isNeonConfigured()) {
    res.statusCode = 200;
    res.end(JSON.stringify({ success: false, message: 'Neon database not configured', wallets: [] }));
    return;
  }

  try {
    await ensureSchemaInitialized();
    const sql = getSqlClient();

    if (req.method === 'GET') {
      const rows = await sql`
        SELECT 
          id,
          name,
          provider,
          account_number as "accountNumber",
          balance::float as balance,
          daily_limit::float as "dailyLimit",
          daily_spent::float as "dailySpent",
          monthly_limit::float as "monthlyLimit",
          monthly_spent::float as "monthlySpent",
          is_active as "isActive",
          color,
          note,
          last_updated as "lastUpdated"
        FROM wallets
        ORDER BY created_at ASC;
      `;
      res.statusCode = 200;
      res.end(JSON.stringify({ success: true, wallets: rows }));
      return;
    }

    if (req.method === 'POST' || req.method === 'PUT') {
      const body = await parseJsonBody(req);
      const {
        id,
        name,
        provider,
        accountNumber,
        balance = 0,
        dailyLimit = 0,
        dailySpent = 0,
        monthlyLimit = 0,
        monthlySpent = 0,
        isActive = true,
        color = '#10b981',
        note = '',
      } = body;

      if (!id || !name || !provider) {
        res.statusCode = 400;
        res.end(JSON.stringify({ error: 'Missing required wallet fields (id, name, provider)' }));
        return;
      }

      await sql`
        INSERT INTO wallets (
          id, name, provider, account_number, balance, daily_limit, daily_spent, monthly_limit, monthly_spent, is_active, color, note, last_updated
        ) VALUES (
          ${id}, ${name}, ${provider}, ${accountNumber || ''}, ${balance}, ${dailyLimit}, ${dailySpent}, ${monthlyLimit}, ${monthlySpent}, ${isActive}, ${color}, ${note}, NOW()
        )
        ON CONFLICT (id) DO UPDATE SET
          name = EXCLUDED.name,
          provider = EXCLUDED.provider,
          account_number = EXCLUDED.account_number,
          balance = EXCLUDED.balance,
          daily_limit = EXCLUDED.daily_limit,
          daily_spent = EXCLUDED.daily_spent,
          monthly_limit = EXCLUDED.monthly_limit,
          monthly_spent = EXCLUDED.monthly_spent,
          is_active = EXCLUDED.is_active,
          color = EXCLUDED.color,
          note = EXCLUDED.note,
          last_updated = NOW();
      `;

      res.statusCode = 200;
      res.end(JSON.stringify({ success: true, message: 'Wallet saved successfully' }));
      return;
    }

    if (req.method === 'DELETE') {
      const body = await parseJsonBody(req);
      const url = new URL(req.url || '', 'http://localhost');
      const id = body.id || url.searchParams.get('id');

      if (!id) {
        res.statusCode = 400;
        res.end(JSON.stringify({ error: 'Missing wallet ID to delete' }));
        return;
      }

      await sql`DELETE FROM wallets WHERE id = ${id};`;
      res.statusCode = 200;
      res.end(JSON.stringify({ success: true, message: 'Wallet deleted successfully' }));
      return;
    }

    res.statusCode = 405;
    res.end(JSON.stringify({ error: 'Method not allowed' }));
  } catch (err: any) {
    res.statusCode = 500;
    res.end(JSON.stringify({ error: err.message || 'Database error' }));
  }
}
