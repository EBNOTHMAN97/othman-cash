-- ==============================================================
-- OTHMAN WALLET (عثمان كاش) - NEON POSTGRESQL DATABASE SCHEMA
-- Compatible with Neon Serverless Postgres (neon.tech) & Vercel
-- ==============================================================

-- 1. Create Wallets Table (جدول المحافظ المالية)
CREATE TABLE IF NOT EXISTS wallets (
  id VARCHAR(64) PRIMARY KEY,
  name VARCHAR(128) NOT NULL,
  provider VARCHAR(32) NOT NULL,
  account_number VARCHAR(64) NOT NULL,
  balance NUMERIC(15, 2) NOT NULL DEFAULT 0,
  daily_limit NUMERIC(15, 2) NOT NULL DEFAULT 0,
  daily_spent NUMERIC(15, 2) NOT NULL DEFAULT 0,
  monthly_limit NUMERIC(15, 2) NOT NULL DEFAULT 0,
  monthly_spent NUMERIC(15, 2) NOT NULL DEFAULT 0,
  is_active BOOLEAN NOT NULL DEFAULT true,
  color VARCHAR(32) DEFAULT '#10b981',
  note TEXT,
  last_updated TIMESTAMPTZ DEFAULT NOW(),
  created_at TIMESTAMPTZ DEFAULT NOW()
);

-- 2. Create Transactions Table (جدول المعاملات المالية)
CREATE TABLE IF NOT EXISTS transactions (
  id VARCHAR(64) PRIMARY KEY,
  wallet_id VARCHAR(64) NOT NULL REFERENCES wallets(id) ON DELETE CASCADE,
  type VARCHAR(32) NOT NULL, -- 'deposit' | 'withdraw' | 'transfer_in' | 'transfer_out'
  amount NUMERIC(15, 2) NOT NULL,
  balance_after NUMERIC(15, 2) NOT NULL,
  timestamp TIMESTAMPTZ DEFAULT NOW(),
  recipient_phone VARCHAR(64),
  recipient_name VARCHAR(128),
  related_wallet_id VARCHAR(64),
  reference_number VARCHAR(64),
  category VARCHAR(128),
  notes TEXT,
  fee NUMERIC(15, 2) DEFAULT 0,
  created_at TIMESTAMPTZ DEFAULT NOW()
);

-- Indexes for performance
CREATE INDEX IF NOT EXISTS idx_transactions_wallet ON transactions(wallet_id);
CREATE INDEX IF NOT EXISTS idx_transactions_timestamp ON transactions(timestamp DESC);

-- 3. Create Expense Categories Table (جدول تصنيفات المصروفات)
CREATE TABLE IF NOT EXISTS expense_categories (
  id VARCHAR(64) PRIMARY KEY,
  name VARCHAR(128) NOT NULL,
  color VARCHAR(32) NOT NULL,
  icon VARCHAR(64),
  is_default BOOLEAN DEFAULT false,
  created_at TIMESTAMPTZ DEFAULT NOW()
);

-- 4. Create App Settings Table (جدول إعدادات التطبيق والمحفظة الافتراضية)
CREATE TABLE IF NOT EXISTS app_settings (
  key VARCHAR(64) PRIMARY KEY,
  value JSONB NOT NULL,
  updated_at TIMESTAMPTZ DEFAULT NOW()
);

-- 5. Seed Initial Default Categories (تصنيفات المصروفات الافتراضية)
INSERT INTO expense_categories (id, name, color, is_default)
VALUES 
  ('cat-cash-wth', 'سحب كاش للعميل', '#10b981', true),
  ('cat-bills', 'سداد فواتير وخدمات', '#3b82f6', true),
  ('cat-operating', 'مصاريف تشغيل وإيجار', '#f59e0b', true),
  ('cat-goods', 'مشتريات وبضاعة', '#8b5cf6', true),
  ('cat-salaries', 'مرتبات وعمالة', '#06b6d4', true),
  ('cat-fees', 'عمولات ورسوم بنكية', '#ec4899', true),
  ('cat-petty', 'مصاريف نثرية وشخصية', '#f43f5e', true),
  ('cat-maintenance', 'صيانة وتجهيزات', '#d97706', true),
  ('cat-transfers', 'تحويلات منصرفة', '#6366f1', true)
ON CONFLICT (id) DO NOTHING;
