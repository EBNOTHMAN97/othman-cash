import { registerSW } from 'virtual:pwa-register';

export function setupPWARegistration() {
  if (typeof window !== 'undefined' && 'serviceWorker' in navigator) {
    const updateSW = registerSW({
      immediate: true,
      onNeedRefresh() {
        console.log('عثمان كاش: تم تحميل تحديث جديد للتطبيق. جاري تطبيق التحديث.');
        updateSW(true);
      },
      onOfflineReady() {
        console.log('عثمان كاش: التطبيق جاهز للاستخدام بدون اتصال (Offline Ready).');
      },
      onRegisterError(error) {
        console.error('خطأ في تسجيل Service Worker:', error);
      },
    });
  }
}
