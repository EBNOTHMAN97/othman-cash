export type WalletProvider = 
  | 'vodafone' 
  | 'orange' 
  | 'etisalat' 
  | 'instapay' 
  | 'accesspay'
  | 'bank_misr' 
  | 'nbe' 
  | 'cash_vault';

export interface Wallet {
  id: string;
  name: string;
  provider: WalletProvider;
  accountNumber: string;
  balance: number;
  dailyLimit: number;
  dailySpent: number;
  monthlyLimit: number;
  monthlySpent: number;
  isActive: boolean;
  color: string;
  note?: string;
  lastUpdated: string;
}

export type TransactionType = 'deposit' | 'withdraw' | 'transfer';

export interface ExpenseCategory {
  id: string;
  name: string;
  color: string;
  icon?: string;
  isDefault?: boolean;
  createdAt?: string;
}

export interface Transaction {
  id: string;
  type: TransactionType;
  transferKind?: 'internal' | 'general';
  walletId: string;
  walletName: string;
  targetWalletId?: string;
  targetWalletName?: string;
  amount: number;
  fee: number;
  referenceNumber: string;
  recipientPhone?: string;
  recipientName?: string;
  date: string;
  category: string;
  status: 'completed' | 'pending' | 'failed';
  notes?: string;
}

export interface SystemNotification {
  id: string;
  title: string;
  message: string;
  type: 'warning' | 'success' | 'alert' | 'info';
  timestamp: string;
  read: boolean;
  walletId?: string;
  billId?: string;
}

export interface RecurringBill {
  id: string;
  title: string;
  amount: number;
  category: string;
  dueDay: number; // Day of the month: 1 - 31
  reminderDaysBefore: number; // 0 = same day, 1 = 1 day before, 2 = 2 days before, etc.
  reminderTime?: string; // e.g. "09:00"
  walletId?: string;
  walletName?: string;
  notes?: string;
  isActive: boolean;
  lastPaidMonth?: string; // e.g. "2026-10"
  autoNotification: boolean;
  createdAt: string;
}
