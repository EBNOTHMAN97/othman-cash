import React, { createContext, useContext, useState, useEffect, ReactNode } from 'react';
import { Wallet, Transaction, SystemNotification, RecurringBill, ExpenseCategory } from '../types';
import {
  DatabaseStatus,
  checkNeonStatus,
  fetchNeonData,
  pushLocalDataToNeon,
  saveWalletToNeon,
  deleteWalletFromNeon,
  logTransactionToNeon,
  deleteTransactionFromNeon,
} from '../services/neonApi';

interface FinancialContextType {
  wallets: Wallet[];
  transactions: Transaction[];
  notifications: SystemNotification[];
  bills: RecurringBill[];
  expenseCategories: ExpenseCategory[];
  unreadNotificationsCount: number;
  totalBalance: number;
  totalDailySpent: number;
  totalMonthlySpent: number;
  isLocked: boolean;
  pinCode: string;
  deposit: (walletId: string, amount: number, notes?: string, fee?: number, date?: string, category?: string) => { success: boolean; message: string; transaction?: Transaction };
  withdraw: (walletId: string, amount: number, recipientPhone?: string, recipientName?: string, notes?: string, fee?: number, date?: string, category?: string) => { success: boolean; message: string; transaction?: Transaction };
  transfer: (fromWalletId: string, toWalletId: string, amount: number, notes?: string, fee?: number, date?: string, category?: string) => { success: boolean; message: string; transaction?: Transaction };
  transferGeneral: (fromWalletId: string, amount: number, recipientPhone?: string, recipientName?: string, category?: string, notes?: string, fee?: number, date?: string) => { success: boolean; message: string; transaction?: Transaction };
  getWalletDailySpent: (walletId: string, dateStr?: string) => number;
  getWalletMonthlySpent: (walletId: string, dateStr?: string) => number;
  getWalletRemainingDailyLimit: (walletId: string, dateStr?: string) => number;
  getWalletDailyLimitStats: (walletId: string, dateStr?: string) => {
    limit: number;
    spent: number;
    remaining: number;
    percent: number;
    dateKey: string;
  };
  addExpenseCategory: (name: string, color?: string, icon?: string) => { success: boolean; message: string; category?: ExpenseCategory };
  updateExpenseCategory: (id: string, name: string, color?: string) => { success: boolean; message: string };
  deleteExpenseCategory: (id: string) => { success: boolean; message: string };
  addWallet: (wallet: Omit<Wallet, 'id' | 'lastUpdated'>) => void;
  updateWallet: (wallet: Wallet) => void;
  deleteWallet: (walletId: string) => void;
  updateTransaction: (updatedTx: Transaction) => void;
  deleteTransaction: (transactionId: string) => void;
  addBill: (bill: Omit<RecurringBill, 'id' | 'createdAt'>) => void;
  updateBill: (bill: RecurringBill) => void;
  deleteBill: (billId: string) => void;
  markBillAsPaid: (billId: string, monthKey?: string) => void;
  markBillAsUnpaid: (billId: string) => void;
  triggerTestBillReminder: (billId: string) => void;
  checkDueBillsAndNotify: () => void;
  defaultTransferWalletId: string;
  defaultTransferWallet?: Wallet;
  setDefaultTransferWallet: (walletId: string) => { success: boolean; message: string };
  wipeAllData: () => void;
  markNotificationAsRead: (id: string) => void;
  markAllNotificationsAsRead: () => void;
  clearNotifications: () => void;
  resetDailyLimits: () => void;
  unlockApp: (pin: string) => boolean;
  lockApp: () => void;
  setAppPin: (newPin: string) => void;
  neonStatus: DatabaseStatus | null;
  isSyncingWithNeon: boolean;
  syncWithNeon: () => Promise<{ success: boolean; message: string }>;
  checkNeonConnection: () => Promise<void>;
}

const STORAGE_KEY_WALLETS = 'othmancash_wallets_v2';
const STORAGE_KEY_TRANSACTIONS = 'othmancash_transactions_v2';
const STORAGE_KEY_NOTIFS = 'othmancash_notifs_v2';
const STORAGE_KEY_PIN = 'othmancash_pin_v2';
const STORAGE_KEY_BILLS = 'othmancash_bills_v2';
const STORAGE_KEY_CATEGORIES = 'othmancash_categories_v2';
const STORAGE_KEY_DEFAULT_TRANSFER_WALLET = 'othmancash_default_transfer_wallet_v2';

// Helper: Get local date key YYYY-MM-DD from any date string or Date object
export function getLocalDateKey(dateStr?: string | Date): string {
  if (!dateStr) {
    const now = new Date();
    const y = now.getFullYear();
    const m = String(now.getMonth() + 1).padStart(2, '0');
    const d = String(now.getDate()).padStart(2, '0');
    return `${y}-${m}-${d}`;
  }
  const d = typeof dateStr === 'string' ? new Date(dateStr) : dateStr;
  if (isNaN(d.getTime())) {
    const now = new Date();
    const y = now.getFullYear();
    const m = String(now.getMonth() + 1).padStart(2, '0');
    const day = String(now.getDate()).padStart(2, '0');
    return `${y}-${m}-${day}`;
  }
  const y = d.getFullYear();
  const m = String(d.getMonth() + 1).padStart(2, '0');
  const day = String(d.getDate()).padStart(2, '0');
  return `${y}-${m}-${day}`;
}

// Helper: Get local month key YYYY-MM
export function getLocalMonthKey(dateStr?: string | Date): string {
  if (!dateStr) {
    const now = new Date();
    const y = now.getFullYear();
    const m = String(now.getMonth() + 1).padStart(2, '0');
    return `${y}-${m}`;
  }
  const d = typeof dateStr === 'string' ? new Date(dateStr) : dateStr;
  if (isNaN(d.getTime())) {
    const now = new Date();
    const y = now.getFullYear();
    const m = String(now.getMonth() + 1).padStart(2, '0');
    return `${y}-${m}`;
  }
  const y = d.getFullYear();
  const m = String(d.getMonth() + 1).padStart(2, '0');
  return `${y}-${m}`;
}

// Helper: Calculate daily spent for a wallet on a specific calendar day (YYYY-MM-DD)
export function calculateWalletDailySpent(walletId: string, dateKey: string, txList: Transaction[]): number {
  return txList
    .filter((tx) => {
      if (tx.status === 'failed') return false;
      if (tx.walletId !== walletId) return false;
      // Withdrawals and outbound transfers consume daily limit
      if (tx.type !== 'withdraw' && tx.type !== 'transfer') return false;
      return getLocalDateKey(tx.date) === dateKey;
    })
    .reduce((sum, tx) => sum + (Number(tx.amount) || 0), 0);
}

// Helper: Calculate monthly spent for a wallet in a specific month (YYYY-MM)
export function calculateWalletMonthlySpent(walletId: string, monthKey: string, txList: Transaction[]): number {
  return txList
    .filter((tx) => {
      if (tx.status === 'failed') return false;
      if (tx.walletId !== walletId) return false;
      if (tx.type !== 'withdraw' && tx.type !== 'transfer') return false;
      return getLocalMonthKey(tx.date) === monthKey;
    })
    .reduce((sum, tx) => sum + (Number(tx.amount) || 0), 0);
}

export const DEFAULT_EXPENSE_CATEGORIES: ExpenseCategory[] = [
  { id: 'cat-cash-wth', name: 'سحب كاش للعميل', color: '#10b981', isDefault: true },
  { id: 'cat-bills', name: 'سداد فواتير وخدمات', color: '#3b82f6', isDefault: true },
  { id: 'cat-operating', name: 'مصاريف تشغيل وإيجار', color: '#f59e0b', isDefault: true },
  { id: 'cat-goods', name: 'مشتريات وبضاعة', color: '#8b5cf6', isDefault: true },
  { id: 'cat-salaries', name: 'مرتبات وعمالة', color: '#06b6d4', isDefault: true },
  { id: 'cat-fees', name: 'عمولات ورسوم بنكية', color: '#ec4899', isDefault: true },
  { id: 'cat-petty', name: 'مصاريف نثرية وشخصية', color: '#f43f5e', isDefault: true },
  { id: 'cat-maintenance', name: 'صيانة وتجهيزات', color: '#d97706', isDefault: true },
  { id: 'cat-transfers', name: 'تحويلات منصرفة', color: '#6366f1', isDefault: true },
];

const DEFAULT_WALLETS: Wallet[] = [
  {
    id: 'w-1',
    name: 'فودافون كاش - الحساب الرئيسي',
    provider: 'vodafone',
    accountNumber: '01012345678',
    balance: 48500,
    dailyLimit: 60000,
    dailySpent: 42000, // 70% used - approaching limit
    monthlyLimit: 200000,
    monthlySpent: 135000,
    isActive: true,
    color: '#e60000',
    note: 'المحفظة الأساسية للتحويلات اليومية للعملاء',
    lastUpdated: new Date().toISOString(),
  },
  {
    id: 'w-2',
    name: 'إنستاباي - بنك مصر',
    provider: 'instapay',
    accountNumber: 'othman.cash@instapay',
    balance: 112400,
    dailyLimit: 120000,
    dailySpent: 105000, // 87.5% used - warning alert!
    monthlyLimit: 400000,
    monthlySpent: 290000,
    isActive: true,
    color: '#7c3aed',
    note: 'تحويلات لحظية عالية القيمة بدون عمولة',
    lastUpdated: new Date().toISOString(),
  },
  {
    id: 'w-3',
    name: 'أورنج كاش - فرع المحل',
    provider: 'orange',
    accountNumber: '01223456789',
    balance: 26800,
    dailyLimit: 60000,
    dailySpent: 12000,
    monthlyLimit: 200000,
    monthlySpent: 54000,
    isActive: true,
    color: '#ff7900',
    note: 'عمليات الاستلام ودفع الفواتير',
    lastUpdated: new Date().toISOString(),
  },
  {
    id: 'w-4',
    name: 'اتصالات كاش - الطوارئ',
    provider: 'etisalat',
    accountNumber: '01134567890',
    balance: 18250,
    dailyLimit: 60000,
    dailySpent: 5000,
    monthlyLimit: 200000,
    monthlySpent: 38000,
    isActive: true,
    color: '#009639',
    note: 'محفظة احتياطية للسيولة السريعة',
    lastUpdated: new Date().toISOString(),
  },
  {
    id: 'w-5',
    name: 'الخزينة النقدية (كاش يدوي)',
    provider: 'cash_vault',
    accountNumber: 'VAULT-01',
    balance: 85000,
    dailyLimit: 250000,
    dailySpent: 45000,
    monthlyLimit: 1000000,
    monthlySpent: 480000,
    isActive: true,
    color: '#10b981',
    note: 'السيولة النقدية الحاضرة بالدرج والخزينة الحديدية',
    lastUpdated: new Date().toISOString(),
  },
  {
    id: 'w-6',
    name: 'البنك الأهلي المصري NBE',
    provider: 'nbe',
    accountNumber: '19001239847192',
    balance: 145000,
    dailyLimit: 500000,
    dailySpent: 65000,
    monthlyLimit: 2000000,
    monthlySpent: 620000,
    isActive: true,
    color: '#0284c7',
    note: 'حساب الإيداعات والسيولة الاستراتيجية',
    lastUpdated: new Date().toISOString(),
  },
  {
    id: 'w-7',
    name: 'أكسس باي - Access Pay',
    provider: 'accesspay',
    accountNumber: 'ACC-8829104',
    balance: 34200,
    dailyLimit: 80000,
    dailySpent: 16000,
    monthlyLimit: 300000,
    monthlySpent: 85000,
    isActive: true,
    color: '#0ea5e9',
    note: 'محفظة أكسس باي للمدفوعات الرقمية والتحصيل',
    lastUpdated: new Date().toISOString(),
  },
];

const DEFAULT_TRANSACTIONS: Transaction[] = [
  {
    id: 'tx-today-1',
    type: 'withdraw',
    walletId: 'w-1',
    walletName: 'فودافون كاش - الحساب الرئيسي',
    amount: 42000,
    fee: 100,
    referenceNumber: 'VF202610140811',
    recipientPhone: '01019283746',
    recipientName: 'كريم عبد العزيز',
    date: '2026-10-14T09:30:00',
    category: 'سحب كاش للعميل',
    status: 'completed',
    notes: 'سحب كاش للعميل بفرع المحل',
  },
  {
    id: 'tx-today-2',
    type: 'withdraw',
    walletId: 'w-2',
    walletName: 'إنستاباي - بنك مصر',
    amount: 105000,
    fee: 0,
    referenceNumber: 'IPN202610140922',
    recipientPhone: '01122334455',
    recipientName: 'شركة النيل للخدمات والتجارة',
    date: '2026-10-14T10:15:00',
    category: 'سداد فواتير وخدمات',
    status: 'completed',
    notes: 'تحويل لحساب الشركة الموردة',
  },
  {
    id: 'tx-101',
    type: 'transfer',
    walletId: 'w-2',
    walletName: 'إنستاباي - بنك مصر',
    targetWalletId: 'w-1',
    targetWalletName: 'فودافون كاش - الحساب الرئيسي',
    amount: 15000,
    fee: 0,
    referenceNumber: 'IPN202610129841',
    date: '2026-10-12T14:32:00',
    category: 'تغذية محفظة',
    status: 'completed',
    notes: 'تحويل سيولة لتغطية سحوبات اليوم',
  },
  {
    id: 'tx-102',
    type: 'deposit',
    walletId: 'w-1',
    walletName: 'فودافون كاش - الحساب الرئيسي',
    amount: 8500,
    fee: 0,
    referenceNumber: 'VF202610120192',
    recipientPhone: '01099887766',
    recipientName: 'كريم محمود',
    date: '2026-10-12T12:15:00',
    category: 'إيداع عميل',
    status: 'completed',
    notes: 'إيداع نقدي مقابل شحن رصيد',
  },
  {
    id: 'tx-103',
    type: 'withdraw',
    walletId: 'w-1',
    walletName: 'فودافون كاش - الحساب الرئيسي',
    amount: 12000,
    fee: 60,
    referenceNumber: 'VF202610120045',
    recipientPhone: '01011223344',
    recipientName: 'محمود عبد الله',
    date: '2026-10-12T11:40:00',
    category: 'سحب كاش للعميل',
    status: 'completed',
    notes: 'عمولة سحب 0.5%',
  },
  {
    id: 'tx-104',
    type: 'deposit',
    walletId: 'w-5',
    walletName: 'الخزينة النقدية (كاش يدوي)',
    amount: 25000,
    fee: 0,
    referenceNumber: 'VLT-20261012-01',
    date: '2026-10-12T10:00:00',
    category: 'توريد خزينة',
    status: 'completed',
    notes: 'توريد سيولة بداية الوردية الصباحية',
  },
  {
    id: 'tx-105',
    type: 'withdraw',
    walletId: 'w-3',
    walletName: 'أورنج كاش - فرع المحل',
    amount: 6000,
    fee: 30,
    referenceNumber: 'OR202610110821',
    recipientPhone: '01287654321',
    recipientName: 'سارة أحمد',
    date: '2026-10-11T17:20:00',
    category: 'سحب نقدي للعميل',
    status: 'completed',
    notes: 'صرف كاش فوري',
  },
  {
    id: 'tx-106',
    type: 'withdraw',
    walletId: 'w-2',
    walletName: 'إنستاباي - بنك مصر',
    amount: 8400,
    fee: 0,
    referenceNumber: 'IPN202610100412',
    recipientName: 'شركة المصرية للاتصالات WE',
    date: '2026-10-10T09:30:00',
    category: 'سداد فواتير وخدمات',
    status: 'completed',
    notes: 'سداد فواتير إنترنت وكهرباء الفرع',
  },
  {
    id: 'tx-107',
    type: 'withdraw',
    walletId: 'w-5',
    walletName: 'الخزينة النقدية (كاش يدوي)',
    amount: 14500,
    fee: 0,
    referenceNumber: 'VLT202610090881',
    recipientName: 'إيجار المحل ورواتب',
    date: '2026-10-09T16:00:00',
    category: 'مصاريف تشغيل وإيجار',
    status: 'completed',
    notes: 'مصاريف تشغيلية ونثريات المحل',
  },
  {
    id: 'tx-108',
    type: 'withdraw',
    walletId: 'w-7',
    walletName: 'أكسس باي - Access Pay',
    amount: 11200,
    fee: 25,
    referenceNumber: 'ACC202610080119',
    recipientName: 'المورد الرئيسي - إلكترونيات',
    date: '2026-10-08T13:45:00',
    category: 'مشتريات وبضاعة',
    status: 'completed',
    notes: 'شراء كروت شحن وإكسسوارات',
  },
  {
    id: 'tx-109',
    type: 'withdraw',
    walletId: 'w-1',
    walletName: 'فودافون كاش - الحساب الرئيسي',
    amount: 3200,
    fee: 45,
    referenceNumber: 'VF202610070622',
    date: '2026-10-07T11:10:00',
    category: 'عمولات ورسوم بنكية',
    status: 'completed',
    notes: 'رسوم تحويلات وصيانة المحفظة',
  },
];

const DEFAULT_NOTIFICATIONS: SystemNotification[] = [
  {
    id: 'notif-1',
    title: 'تنبيه: اقتراب انتهاء الليمت اليومي',
    message: 'محفظة إنستاباي - بنك مصر استهلكت 87.5% من الليمت اليومي (105,000 من 120,000 ج.م). يرجى الحذر.',
    type: 'warning',
    timestamp: 'منذ نصف ساعة',
    read: false,
    walletId: 'w-2',
  },
  {
    id: 'notif-2',
    title: 'تنبيه: استهلاك 70% من ليمت فودافون كاش',
    message: 'محفظة فودافون كاش الرئيسية استهلكت 42,000 ج.م من ليمت 60,000 ج.م اليومي.',
    type: 'alert',
    timestamp: 'منذ ساعتين',
    read: false,
    walletId: 'w-1',
  },
  {
    id: 'notif-3',
    title: 'نجاح عملية تحويل مالي',
    message: 'تم تحويل 15,000 ج.م بنجاح من إنستاباي إلى فودافون كاش الرئيسية.',
    type: 'success',
    timestamp: 'منذ 3 ساعات',
    read: true,
  },
  {
    id: 'notif-4',
    title: 'تطبيق عثمان كاش جاهز للتثبيت (PWA)',
    message: 'يمكنك الآن تثبيت التطبيق مباشرة على شاشتك الرئيسية للوصول فائق السرعة وبدون متصفح.',
    type: 'info',
    timestamp: 'اليوم',
    read: true,
  },
];

const DEFAULT_BILLS: RecurringBill[] = [
  {
    id: 'bill-1',
    title: 'فاتورة كهرباء المحل التجاري',
    amount: 1450,
    category: 'فواتير وخدمات',
    dueDay: 15,
    reminderDaysBefore: 3,
    reminderTime: '10:00',
    walletId: 'w-1',
    walletName: 'فودافون كاش - الحساب الرئيسي',
    notes: 'سداد فواتير شركة الكهرباء بالرقم القومي',
    isActive: true,
    autoNotification: true,
    lastPaidMonth: '',
    createdAt: new Date().toISOString(),
  },
  {
    id: 'bill-2',
    title: 'إيجار المحل الشهري',
    amount: 6000,
    category: 'إيجار',
    dueDay: 1,
    reminderDaysBefore: 3,
    reminderTime: '09:00',
    walletId: 'w-2',
    walletName: 'إنستاباي - بنك مصر',
    notes: 'تسليم الإيجار لصاحب العقار أول كل شهر',
    isActive: true,
    autoNotification: true,
    lastPaidMonth: '',
    createdAt: new Date().toISOString(),
  },
  {
    id: 'bill-3',
    title: 'اشتراك باقة الإنترنت فودافون VDSL',
    amount: 450,
    category: 'إنترنت واتصالات',
    dueDay: 20,
    reminderDaysBefore: 2,
    reminderTime: '11:00',
    walletId: 'w-1',
    walletName: 'فودافون كاش - الحساب الرئيسي',
    notes: 'تجديد باقة الإنترنت عبر فودافون كاش',
    isActive: true,
    autoNotification: true,
    lastPaidMonth: '',
    createdAt: new Date().toISOString(),
  },
  {
    id: 'bill-4',
    title: 'قسط تمويل ماكينة نقاط البيع POS',
    amount: 1800,
    category: 'أقساط والتزامات',
    dueDay: 25,
    reminderDaysBefore: 2,
    reminderTime: '09:00',
    walletId: 'w-6',
    walletName: 'البنك الأهلي المصري NBE',
    notes: 'خصم أوتوماتيكي من الحساب البنكي',
    isActive: true,
    autoNotification: true,
    lastPaidMonth: '',
    createdAt: new Date().toISOString(),
  },
];

const FinancialContext = createContext<FinancialContextType | undefined>(undefined);

export const FinancialProvider: React.FC<{ children: ReactNode }> = ({ children }) => {
  const [wallets, setWallets] = useState<Wallet[]>(() => {
    try {
      const saved = localStorage.getItem(STORAGE_KEY_WALLETS);
      return saved ? JSON.parse(saved) : DEFAULT_WALLETS;
    } catch {
      return DEFAULT_WALLETS;
    }
  });

  const [transactions, setTransactions] = useState<Transaction[]>(() => {
    try {
      const saved = localStorage.getItem(STORAGE_KEY_TRANSACTIONS);
      return saved ? JSON.parse(saved) : DEFAULT_TRANSACTIONS;
    } catch {
      return DEFAULT_TRANSACTIONS;
    }
  });

  const [notifications, setNotifications] = useState<SystemNotification[]>(() => {
    try {
      const saved = localStorage.getItem(STORAGE_KEY_NOTIFS);
      return saved ? JSON.parse(saved) : DEFAULT_NOTIFICATIONS;
    } catch {
      return DEFAULT_NOTIFICATIONS;
    }
  });

  const [bills, setBills] = useState<RecurringBill[]>(() => {
    try {
      const saved = localStorage.getItem(STORAGE_KEY_BILLS);
      return saved ? JSON.parse(saved) : DEFAULT_BILLS;
    } catch {
      return DEFAULT_BILLS;
    }
  });

  const [expenseCategories, setExpenseCategories] = useState<ExpenseCategory[]>(() => {
    try {
      const saved = localStorage.getItem(STORAGE_KEY_CATEGORIES);
      return saved ? JSON.parse(saved) : DEFAULT_EXPENSE_CATEGORIES;
    } catch {
      return DEFAULT_EXPENSE_CATEGORIES;
    }
  });

  const [defaultTransferWalletId, setDefaultTransferWalletId] = useState<string>(() => {
    try {
      const saved = localStorage.getItem(STORAGE_KEY_DEFAULT_TRANSFER_WALLET);
      if (saved) return saved;
      return DEFAULT_WALLETS[0]?.id || '';
    } catch {
      return DEFAULT_WALLETS[0]?.id || '';
    }
  });

  const [pinCode, setPinCode] = useState<string>(() => {
    try {
      return localStorage.getItem(STORAGE_KEY_PIN) || '1234';
    } catch {
      return '1234';
    }
  });

  const [isLocked, setIsLocked] = useState<boolean>(true);
  const [neonStatus, setNeonStatus] = useState<DatabaseStatus | null>(null);
  const [isSyncingWithNeon, setIsSyncingWithNeon] = useState<boolean>(false);

  // Check connection to Neon PostgreSQL
  const checkNeonConnection = async () => {
    const status = await checkNeonStatus();
    setNeonStatus(status);
  };

  // Sync all current state with Neon PostgreSQL
  const syncWithNeon = async () => {
    setIsSyncingWithNeon(true);
    try {
      const res = await pushLocalDataToNeon({
        wallets,
        transactions,
        categories: expenseCategories,
        defaultTransferWalletId,
      });
      await checkNeonConnection();
      return res;
    } finally {
      setIsSyncingWithNeon(false);
    }
  };

  // On initial mount: check Neon and hydrate if online and configured
  useEffect(() => {
    let isMounted = true;
    async function initNeon() {
      try {
        const status = await checkNeonStatus();
        if (!isMounted) return;
        setNeonStatus(status);

        if (status.connected && status.neonConfigured) {
          const remote = await fetchNeonData();
          if (!isMounted) return;
          if (remote.success && remote.data) {
            if (remote.data.wallets && remote.data.wallets.length > 0) {
              setWallets(remote.data.wallets);
              if (remote.data.transactions && remote.data.transactions.length > 0) {
                setTransactions(remote.data.transactions);
              }
              if (remote.data.categories && remote.data.categories.length > 0) {
                setExpenseCategories(remote.data.categories);
              }
              if (remote.data.defaultTransferWalletId) {
                setDefaultTransferWalletId(remote.data.defaultTransferWalletId);
              }
            } else {
              // Neon DB is empty: seed it from current default/local data
              await pushLocalDataToNeon({
                wallets,
                transactions,
                categories: expenseCategories,
                defaultTransferWalletId,
              });
              const refreshed = await checkNeonStatus();
              if (isMounted) setNeonStatus(refreshed);
            }
          }
        }
      } catch (err) {
        console.warn('Neon initial sync skipped:', err);
      }
    }

    initNeon();
    return () => {
      isMounted = false;
    };
  }, []);

  // Save changes to localStorage for offline state persistence
  useEffect(() => {
    try {
      localStorage.setItem(STORAGE_KEY_WALLETS, JSON.stringify(wallets));
    } catch (e) {
      console.warn('Could not save wallets to storage:', e);
    }
  }, [wallets]);

  useEffect(() => {
    try {
      localStorage.setItem(STORAGE_KEY_TRANSACTIONS, JSON.stringify(transactions));
    } catch (e) {
      console.warn('Could not save transactions to storage:', e);
    }
  }, [transactions]);

  useEffect(() => {
    try {
      localStorage.setItem(STORAGE_KEY_NOTIFS, JSON.stringify(notifications));
    } catch (e) {
      console.warn('Could not save notifications to storage:', e);
    }
  }, [notifications]);

  useEffect(() => {
    try {
      localStorage.setItem(STORAGE_KEY_BILLS, JSON.stringify(bills));
    } catch (e) {
      console.warn('Could not save bills to storage:', e);
    }
  }, [bills]);

  useEffect(() => {
    try {
      localStorage.setItem(STORAGE_KEY_CATEGORIES, JSON.stringify(expenseCategories));
    } catch (e) {
      console.warn('Could not save categories to storage:', e);
    }
  }, [expenseCategories]);

  useEffect(() => {
    try {
      if (defaultTransferWalletId) {
        localStorage.setItem(STORAGE_KEY_DEFAULT_TRANSFER_WALLET, defaultTransferWalletId);
      }
    } catch (e) {
      console.warn('Could not save default transfer wallet to storage:', e);
    }
  }, [defaultTransferWalletId]);

  useEffect(() => {
    try {
      localStorage.setItem(STORAGE_KEY_PIN, pinCode);
    } catch (e) {
      console.warn('Could not save pin to storage:', e);
    }
  }, [pinCode]);

  // Helper functions for date-based daily and monthly limits
  const getWalletDailySpent = (walletId: string, dateStr?: string): number => {
    const dateKey = getLocalDateKey(dateStr);
    return calculateWalletDailySpent(walletId, dateKey, transactions);
  };

  const getWalletMonthlySpent = (walletId: string, dateStr?: string): number => {
    const monthKey = getLocalMonthKey(dateStr);
    return calculateWalletMonthlySpent(walletId, monthKey, transactions);
  };

  const getWalletRemainingDailyLimit = (walletId: string, dateStr?: string): number => {
    const wallet = wallets.find((w) => w.id === walletId);
    if (!wallet) return 0;
    const spent = getWalletDailySpent(walletId, dateStr);
    return Math.max(0, wallet.dailyLimit - spent);
  };

  const getWalletDailyLimitStats = (walletId: string, dateStr?: string) => {
    const wallet = wallets.find((w) => w.id === walletId);
    const dateKey = getLocalDateKey(dateStr);
    if (!wallet) {
      return { limit: 0, spent: 0, remaining: 0, percent: 0, dateKey };
    }
    const spent = calculateWalletDailySpent(walletId, dateKey, transactions);
    const remaining = Math.max(0, wallet.dailyLimit - spent);
    const percent = wallet.dailyLimit > 0 ? Math.min(100, Math.round((spent / wallet.dailyLimit) * 100)) : 0;
    return {
      limit: wallet.dailyLimit,
      spent,
      remaining,
      percent,
      dateKey,
    };
  };

  // Keep every wallet's dailySpent and monthlySpent synchronized with actual transactions for today & this month
  useEffect(() => {
    const todayKey = getLocalDateKey();
    const thisMonthKey = getLocalMonthKey();

    setWallets((prev) => {
      let changed = false;
      const next = prev.map((w) => {
        const computedDaily = calculateWalletDailySpent(w.id, todayKey, transactions);
        const computedMonthly = calculateWalletMonthlySpent(w.id, thisMonthKey, transactions);
        if (w.dailySpent !== computedDaily || w.monthlySpent !== computedMonthly) {
          changed = true;
          return {
            ...w,
            dailySpent: computedDaily,
            monthlySpent: computedMonthly,
          };
        }
        return w;
      });
      return changed ? next : prev;
    });
  }, [transactions]);

  // Push notification sender helper (if supported and permitted)
  const triggerPushNotificationIfAllowed = (title: string, body: string) => {
    if (typeof window !== 'undefined' && 'Notification' in window && Notification.permission === 'granted') {
      try {
        if ('serviceWorker' in navigator && navigator.serviceWorker.controller) {
          navigator.serviceWorker.ready.then((reg) => {
            reg.showNotification(title, {
              body,
              icon: '/pwa-192x192.png',
              badge: '/favicon.png',
              dir: 'rtl',
              lang: 'ar',
              tag: 'othman-cash-notif',
            });
          }).catch(() => {
            new Notification(title, { body, icon: '/pwa-192x192.png', dir: 'rtl' });
          });
        } else {
          new Notification(title, { body, icon: '/pwa-192x192.png', dir: 'rtl' });
        }
      } catch (err) {
        console.warn('Notification trigger error:', err);
      }
    }
  };

  // Check limits warnings and trigger alerts
  const checkLimitWarnings = (wallet: Wallet, updatedSpent: number) => {
    const dailyRatio = updatedSpent / wallet.dailyLimit;
    if (dailyRatio >= 0.8 && dailyRatio < 1.0) {
      const notif: SystemNotification = {
        id: `warn-${Date.now()}`,
        title: '⚠️ تنبيه: اقتراب انتهاء الليمت اليومي',
        message: `المحفظة "${wallet.name}" استهلكت ${(dailyRatio * 100).toFixed(0)}% من الليمت اليومي المتاح.`,
        type: 'warning',
        timestamp: 'الآن',
        read: false,
        walletId: wallet.id,
      };
      setNotifications((prev) => [notif, ...prev]);
      triggerPushNotificationIfAllowed(notif.title, notif.message);
    } else if (dailyRatio >= 1.0) {
      const notif: SystemNotification = {
        id: `alert-${Date.now()}`,
        title: '⛔ تحذير: تم الوصول للحد الأقصى اليومي!',
        message: `المحفظة "${wallet.name}" وصلت للحد الأقصى لليمت اليومي بالكامل (${wallet.dailyLimit.toLocaleString()} ج.م).`,
        type: 'alert',
        timestamp: 'الآن',
        read: false,
        walletId: wallet.id,
      };
      setNotifications((prev) => [notif, ...prev]);
      triggerPushNotificationIfAllowed(notif.title, notif.message);
    }
  };

  // REQUIREMENT: Strict offline safety. All financial transactions require valid server connection!
  const isOnlineSafe = () => {
    return typeof navigator === 'undefined' || navigator.onLine;
  };

  // Deposit
  const deposit = (walletId: string, amount: number, notes?: string, fee: number = 0, date?: string, category?: string) => {
    if (!isOnlineSafe()) {
      return {
        success: false,
        message: 'أنت غير متصل بالإنترنت. لا يمكن إجراء أي عمليات إيداع لحماية سلامة الأرصدة والسجلات.',
      };
    }

    if (amount <= 0) {
      return { success: false, message: 'المبلغ يجب أن يكون أكبر من صفر.' };
    }

    const wallet = wallets.find((w) => w.id === walletId);
    if (!wallet) {
      return { success: false, message: 'المحفظة المحددة غير موجودة.' };
    }

    if (!wallet.isActive) {
      return { success: false, message: 'هذه المحفظة متوقفة مؤقتاً ولا تقبل إيداعات جديدة.' };
    }

    const newBalance = wallet.balance + amount - fee;
    const txDate = date || new Date().toISOString();

    const newTx: Transaction = {
      id: `tx-${Date.now()}`,
      type: 'deposit',
      walletId: wallet.id,
      walletName: wallet.name,
      amount,
      fee,
      referenceNumber: `DEP${Date.now().toString().slice(-8)}`,
      date: txDate,
      category: category || 'إيداع نقدي',
      status: 'completed',
      notes,
    };

    setWallets((prev) =>
      prev.map((w) =>
        w.id === walletId
          ? {
              ...w,
              balance: newBalance,
              lastUpdated: new Date().toISOString(),
            }
          : w
      )
    );

    setTransactions((prev) => [newTx, ...prev]);

    // Sync to Neon
    logTransactionToNeon(newTx).catch((err) => {
      console.warn('Could not sync deposit to Neon:', err);
    });
    saveWalletToNeon({ ...wallet, balance: newBalance, lastUpdated: new Date().toISOString() }).catch(() => {});

    const notif: SystemNotification = {
      id: `dep-${Date.now()}`,
      title: 'نجاح عملية إيداع',
      message: `تم إيداع ${amount.toLocaleString()} ج.م بنجاح في ${wallet.name}.`,
      type: 'success',
      timestamp: 'الآن',
      read: false,
      walletId: wallet.id,
    };
    setNotifications((prev) => [notif, ...prev]);
    triggerPushNotificationIfAllowed(notif.title, notif.message);

    return {
      success: true,
      message: `تم إيداع ${amount.toLocaleString()} ج.م بنجاح.`,
      transaction: newTx,
    };
  };

  // Withdraw
  const withdraw = (
    walletId: string,
    amount: number,
    recipientPhone?: string,
    recipientName?: string,
    notes?: string,
    fee: number = 0,
    date?: string,
    category?: string
  ) => {
    if (!isOnlineSafe()) {
      return {
        success: false,
        message: 'أنت غير متصل بالإنترنت. لا يمكن تنفيذ عمليات السحب أثناء انقطاع الاتصال.',
      };
    }

    if (amount <= 0) {
      return { success: false, message: 'المبلغ يجب أن يكون أكبر من صفر.' };
    }

    const wallet = wallets.find((w) => w.id === walletId);
    if (!wallet) {
      return { success: false, message: 'المحفظة المحددة غير موجودة.' };
    }

    if (!wallet.isActive) {
      return { success: false, message: 'هذه المحفظة متوقفة مؤقتاً.' };
    }

    const totalRequired = amount + fee;
    if (wallet.balance < totalRequired) {
      return {
        success: false,
        message: `الرصيد المتاح (${wallet.balance.toLocaleString()} ج.م) لا يكفي لإتمام السحب مع العمولة (${totalRequired.toLocaleString()} ج.م).`,
      };
    }

    const txDate = date || new Date().toISOString();
    const targetDateKey = getLocalDateKey(txDate);

    // Dynamic date-based limit verification
    const spentOnTargetDate = calculateWalletDailySpent(walletId, targetDateKey, transactions);
    const remainingDailyLimit = wallet.dailyLimit - spentOnTargetDate;
    if (amount > remainingDailyLimit) {
      return {
        success: false,
        message: `المبلغ المطلوب (${amount.toLocaleString()} ج.م) يتجاوز المتبقي من الليمت اليومي لتاريخ العملية (${targetDateKey}). المتبقي في ذلك اليوم: ${Math.max(0, remainingDailyLimit).toLocaleString()} ج.م فقط من أصل ${wallet.dailyLimit.toLocaleString()} ج.م.`,
      };
    }

    const newBalance = wallet.balance - totalRequired;

    const newTx: Transaction = {
      id: `tx-${Date.now()}`,
      type: 'withdraw',
      walletId: wallet.id,
      walletName: wallet.name,
      amount,
      fee,
      referenceNumber: `WTH${Date.now().toString().slice(-8)}`,
      recipientPhone,
      recipientName,
      date: txDate,
      category: category || 'سحب كاش للعميل',
      status: 'completed',
      notes,
    };

    setWallets((prev) =>
      prev.map((w) =>
        w.id === walletId
          ? {
              ...w,
              balance: newBalance,
              lastUpdated: new Date().toISOString(),
            }
          : w
      )
    );

    setTransactions((prev) => [newTx, ...prev]);

    // Sync to Neon
    logTransactionToNeon(newTx).catch((err) => {
      console.warn('Could not sync withdraw to Neon:', err);
    });
    saveWalletToNeon({ ...wallet, balance: newBalance, lastUpdated: new Date().toISOString() }).catch(() => {});

    const notif: SystemNotification = {
      id: `wth-${Date.now()}`,
      title: 'نجاح عملية سحب كاش',
      message: `تم سحب ${amount.toLocaleString()} ج.م من ${wallet.name} بنجاح.`,
      type: 'success',
      timestamp: 'الآن',
      read: false,
      walletId: wallet.id,
    };
    setNotifications((prev) => [notif, ...prev]);
    triggerPushNotificationIfAllowed(notif.title, notif.message);

    checkLimitWarnings(wallet, spentOnTargetDate + amount);

    return {
      success: true,
      message: `تم سحب ${amount.toLocaleString()} ج.م بنجاح.`,
      transaction: newTx,
    };
  };

  // Transfer between wallets
  const transfer = (
    fromWalletId: string,
    toWalletId: string,
    amount: number,
    notes?: string,
    fee: number = 0,
    date?: string,
    category?: string
  ) => {
    if (!isOnlineSafe()) {
      return {
        success: false,
        message: 'أنت غير متصل بالإنترنت. لا يمكن تحويل الأموال أثناء انقطاع الاتصال.',
      };
    }

    if (fromWalletId === toWalletId) {
      return { success: false, message: 'لا يمكن التحويل لنفس المحفظة.' };
    }

    if (amount <= 0) {
      return { success: false, message: 'المبلغ يجب أن يكون أكبر من صفر.' };
    }

    const sourceWallet = wallets.find((w) => w.id === fromWalletId);
    const targetWallet = wallets.find((w) => w.id === toWalletId);

    if (!sourceWallet || !targetWallet) {
      return { success: false, message: 'إحدى المحافظ المحددة غير موجودة.' };
    }

    if (!sourceWallet.isActive || !targetWallet.isActive) {
      return { success: false, message: 'إحدى المحافظ متوقفة مؤقتاً.' };
    }

    const totalRequired = amount + fee;
    if (sourceWallet.balance < totalRequired) {
      return {
        success: false,
        message: `رصيد المحفظة المصدر (${sourceWallet.balance.toLocaleString()} ج.م) لا يكفي مع العمولة.`,
      };
    }

    const txDate = date || new Date().toISOString();
    const targetDateKey = getLocalDateKey(txDate);

    // Dynamic date-based limit verification
    const spentOnTargetDate = calculateWalletDailySpent(fromWalletId, targetDateKey, transactions);
    const remainingDailyLimit = sourceWallet.dailyLimit - spentOnTargetDate;
    if (amount > remainingDailyLimit) {
      return {
        success: false,
        message: `المبلغ المطلوب (${amount.toLocaleString()} ج.م) يتجاوز الليمت اليومي للمحفظة المصدر لتاريخ العملية (${targetDateKey}). المتبقي في ذلك اليوم: ${Math.max(0, remainingDailyLimit).toLocaleString()} ج.م فقط.`,
      };
    }

    const newSourceBalance = sourceWallet.balance - totalRequired;
    const newTargetBalance = targetWallet.balance + amount;

    const newTx: Transaction = {
      id: `tx-${Date.now()}`,
      type: 'transfer',
      transferKind: 'internal',
      walletId: sourceWallet.id,
      walletName: sourceWallet.name,
      targetWalletId: targetWallet.id,
      targetWalletName: targetWallet.name,
      amount,
      fee,
      referenceNumber: `TRF${Date.now().toString().slice(-8)}`,
      date: txDate,
      category: category || 'تحويل داخلي',
      status: 'completed',
      notes,
    };

    setWallets((prev) =>
      prev.map((w) => {
        if (w.id === fromWalletId) {
          return {
            ...w,
            balance: newSourceBalance,
            lastUpdated: new Date().toISOString(),
          };
        }
        if (w.id === toWalletId) {
          return {
            ...w,
            balance: newTargetBalance,
            lastUpdated: new Date().toISOString(),
          };
        }
        return w;
      })
    );

    setTransactions((prev) => [newTx, ...prev]);

    // Sync to Neon
    logTransactionToNeon(newTx).catch((err) => {
      console.warn('Could not sync transfer to Neon:', err);
    });
    saveWalletToNeon({ ...sourceWallet, balance: newSourceBalance, lastUpdated: new Date().toISOString() }).catch(() => {});
    saveWalletToNeon({ ...targetWallet, balance: newTargetBalance, lastUpdated: new Date().toISOString() }).catch(() => {});

    const notif: SystemNotification = {
      id: `trf-${Date.now()}`,
      title: 'نجاح تحويل بين المحافظ',
      message: `تم تحويل ${amount.toLocaleString()} ج.م من ${sourceWallet.name} إلى ${targetWallet.name}.`,
      type: 'success',
      timestamp: 'الآن',
      read: false,
    };
    setNotifications((prev) => [notif, ...prev]);
    triggerPushNotificationIfAllowed(notif.title, notif.message);

    checkLimitWarnings(sourceWallet, spentOnTargetDate + amount);

    return {
      success: true,
      message: `تم التحويل بين المحافظ بنجاح بقيمة ${amount.toLocaleString()} ج.م.`,
      transaction: newTx,
    };
  };

  // General transfer (External transfer to client / recipient / other phone / account)
  const transferGeneral = (
    fromWalletId: string,
    amount: number,
    recipientPhone?: string,
    recipientName?: string,
    category: string = 'تحويل عام للخارج',
    notes?: string,
    fee: number = 0,
    date?: string
  ) => {
    if (!isOnlineSafe()) {
      return {
        success: false,
        message: 'أنت غير متصل بالإنترنت. لا يمكن تحويل الأموال أثناء انقطاع الاتصال.',
      };
    }

    if (amount <= 0) {
      return { success: false, message: 'المبلغ يجب أن يكون أكبر من صفر.' };
    }

    const wallet = wallets.find((w) => w.id === fromWalletId);
    if (!wallet) {
      return { success: false, message: 'المحفظة المحددة غير موجودة.' };
    }

    if (!wallet.isActive) {
      return { success: false, message: 'المحفظة متوقفة مؤقتاً.' };
    }

    const totalRequired = amount + fee;
    if (wallet.balance < totalRequired) {
      return {
        success: false,
        message: `رصيد المحفظة (${wallet.balance.toLocaleString()} ج.م) لا يكفي لتغطية مبلغ التحويل والعمولة (${totalRequired.toLocaleString()} ج.م).`,
      };
    }

    const txDate = date || new Date().toISOString();
    const targetDateKey = getLocalDateKey(txDate);

    // Dynamic date-based limit verification
    const spentOnTargetDate = calculateWalletDailySpent(fromWalletId, targetDateKey, transactions);
    const remainingDailyLimit = wallet.dailyLimit - spentOnTargetDate;
    if (amount > remainingDailyLimit) {
      return {
        success: false,
        message: `المبلغ المطلوب (${amount.toLocaleString()} ج.م) يتجاوز الليمت اليومي للمحفظة لتاريخ العملية (${targetDateKey}). المتبقي في ذلك اليوم: ${Math.max(0, remainingDailyLimit).toLocaleString()} ج.م فقط.`,
      };
    }

    const newBalance = wallet.balance - totalRequired;

    const newTx: Transaction = {
      id: `tx-${Date.now()}`,
      type: 'transfer',
      transferKind: 'general',
      walletId: wallet.id,
      walletName: wallet.name,
      amount,
      fee,
      referenceNumber: `GEN${Date.now().toString().slice(-8)}`,
      recipientPhone,
      recipientName,
      date: txDate,
      category: category || 'تحويل عام للخارج',
      status: 'completed',
      notes,
    };

    setWallets((prev) =>
      prev.map((w) =>
        w.id === fromWalletId
          ? {
              ...w,
              balance: newBalance,
              lastUpdated: new Date().toISOString(),
            }
          : w
      )
    );

    setTransactions((prev) => [newTx, ...prev]);

    // Sync to Neon
    logTransactionToNeon(newTx).catch((err) => {
      console.warn('Could not sync general transfer to Neon:', err);
    });
    saveWalletToNeon({ ...wallet, balance: newBalance, lastUpdated: new Date().toISOString() }).catch(() => {});

    const notif: SystemNotification = {
      id: `trf-gen-${Date.now()}`,
      title: 'نجاح عملية تحويل عام',
      message: `تم تحويل مبلغ ${amount.toLocaleString()} ج.م من ${wallet.name} بنجاح ${recipientName ? `إلى ${recipientName}` : recipientPhone ? `إلى ${recipientPhone}` : ''}.`,
      type: 'success',
      timestamp: 'الآن',
      read: false,
      walletId: wallet.id,
    };
    setNotifications((prev) => [notif, ...prev]);
    triggerPushNotificationIfAllowed(notif.title, notif.message);

    checkLimitWarnings(wallet, spentOnTargetDate + amount);

    return {
      success: true,
      message: `تم إتمام التحويل العام بقيمة ${amount.toLocaleString()} ج.م بنجاح.`,
      transaction: newTx,
    };
  };

  // Custom Expense Category Management
  const addExpenseCategory = (name: string, color?: string, icon?: string) => {
    const trimmed = name.trim();
    if (!trimmed) {
      return { success: false, message: 'يرجى إدخال اسم التصنيف أولاً.' };
    }
    const exists = expenseCategories.some(
      (c) => c.name.toLowerCase() === trimmed.toLowerCase()
    );
    if (exists) {
      return { success: false, message: 'يوجد تصنيف بنفس هذا الاسم بالفعل.' };
    }

    const newCat: ExpenseCategory = {
      id: `cat-${Date.now()}`,
      name: trimmed,
      color: color || '#10b981',
      icon: icon || 'tag',
      isDefault: false,
      createdAt: new Date().toISOString(),
    };

    setExpenseCategories((prev) => [...prev, newCat]);
    return { success: true, message: `تم إنشاء التصنيف "${trimmed}" بنجاح.`, category: newCat };
  };

  const updateExpenseCategory = (id: string, name: string, color?: string) => {
    const trimmed = name.trim();
    if (!trimmed) {
      return { success: false, message: 'اسم التصنيف لا يمكن أن يكون فارغاً.' };
    }

    const cat = expenseCategories.find((c) => c.id === id);
    if (!cat) {
      return { success: false, message: 'التصنيف المطلوب غير موجود.' };
    }

    const oldName = cat.name;

    setExpenseCategories((prev) =>
      prev.map((c) => (c.id === id ? { ...c, name: trimmed, color: color || c.color } : c))
    );

    if (oldName !== trimmed) {
      setTransactions((prev) =>
        prev.map((tx) => (tx.category === oldName ? { ...tx, category: trimmed } : tx))
      );
    }

    return { success: true, message: `تم تحديث التصنيف بنجاح.` };
  };

  const deleteExpenseCategory = (id: string) => {
    const cat = expenseCategories.find((c) => c.id === id);
    if (!cat) {
      return { success: false, message: 'التصنيف غير موجود.' };
    }

    setExpenseCategories((prev) => prev.filter((c) => c.id !== id));
    return { success: true, message: `تم حذف التصنيف "${cat.name}" بنجاح.` };
  };

  const addWallet = (newWalletData: Omit<Wallet, 'id' | 'lastUpdated'>) => {
    const newWallet: Wallet = {
      ...newWalletData,
      id: `w-${Date.now()}`,
      lastUpdated: new Date().toISOString(),
    };
    setWallets((prev) => [...prev, newWallet]);
  };

  const updateWallet = (updated: Wallet) => {
    setWallets((prev) =>
      prev.map((w) => (w.id === updated.id ? { ...updated, lastUpdated: new Date().toISOString() } : w))
    );
  };

  const setDefaultTransferWallet = (walletId: string) => {
    const targetWallet = wallets.find((w) => w.id === walletId);
    if (!targetWallet) {
      return { success: false, message: 'المحفظة المحددة غير موجودة.' };
    }

    setDefaultTransferWalletId(walletId);

    const notif: SystemNotification = {
      id: `def-wallet-${Date.now()}`,
      title: 'محفظة التحويل الافتراضية',
      message: `تم تعيين "${targetWallet.name}" كحساب افتراضي أساسي للتحويل.`,
      type: 'info',
      timestamp: 'الآن',
      read: false,
      walletId: targetWallet.id,
    };
    setNotifications((prev) => [notif, ...prev]);

    return {
      success: true,
      message: `تم تعيين "${targetWallet.name}" كمحفظة تحويل افتراضية أساسية بنجاح.`,
    };
  };

  const defaultTransferWallet = wallets.find((w) => w.id === defaultTransferWalletId) || wallets[0];

  const deleteWallet = (walletId: string) => {
    setWallets((prev) => {
      const remaining = prev.filter((w) => w.id !== walletId);
      if (defaultTransferWalletId === walletId && remaining.length > 0) {
        setDefaultTransferWalletId(remaining[0].id);
      }
      return remaining;
    });
    const notif: SystemNotification = {
      id: `del-w-${Date.now()}`,
      title: 'تم حذف المحفظة',
      message: 'تم حذف المحفظة المحددة بنجاح من النظام.',
      type: 'info',
      timestamp: 'الآن',
      read: false,
    };
    setNotifications((prev) => [notif, ...prev]);
  };

  const deleteTransaction = (transactionId: string) => {
    const tx = transactions.find((t) => t.id === transactionId);
    if (!tx) return;

    // Rollback wallet balances
    setWallets((prev) =>
      prev.map((w) => {
        if (tx.type === 'deposit' && w.id === tx.walletId) {
          return {
            ...w,
            balance: Math.max(0, w.balance - (tx.amount - tx.fee)),
            lastUpdated: new Date().toISOString(),
          };
        }
        if (tx.type === 'withdraw' && w.id === tx.walletId) {
          return {
            ...w,
            balance: w.balance + (tx.amount + tx.fee),
            lastUpdated: new Date().toISOString(),
          };
        }
        if (tx.type === 'transfer') {
          if (w.id === tx.walletId) {
            return {
              ...w,
              balance: w.balance + (tx.amount + tx.fee),
              lastUpdated: new Date().toISOString(),
            };
          }
          if (w.id === tx.targetWalletId) {
            return {
              ...w,
              balance: Math.max(0, w.balance - tx.amount),
              lastUpdated: new Date().toISOString(),
            };
          }
        }
        return w;
      })
    );

    setTransactions((prev) => prev.filter((t) => t.id !== transactionId));

    // Delete from Neon database if connected
    deleteTransactionFromNeon(transactionId).catch((err) => {
      console.warn('Could not delete transaction from Neon:', err);
    });

    const notif: SystemNotification = {
      id: `del-tx-${Date.now()}`,
      title: 'تم حذف المعاملة',
      message: `تم حذف العملية رقم ${tx.referenceNumber} بنجاح وإعادة ضبط أرصدة المحافظ واحتساب الليمت تلقائياً.`,
      type: 'info',
      timestamp: 'الآن',
      read: false,
    };
    setNotifications((prev) => [notif, ...prev]);
  };

  const updateTransaction = (updatedTx: Transaction) => {
    const oldTx = transactions.find((t) => t.id === updatedTx.id);
    if (!oldTx) return;

    let updatedWalletsList: Wallet[] = [];

    // 1. Rollback old transaction balance effects on wallets
    // 2. Apply updated transaction balance effects on wallets
    setWallets((prev) => {
      const next = prev.map((w) => {
        let currentWallet = { ...w };

        // Rollback old balance effect
        if (oldTx.type === 'deposit' && currentWallet.id === oldTx.walletId) {
          currentWallet.balance -= (oldTx.amount - oldTx.fee);
        } else if (oldTx.type === 'withdraw' && currentWallet.id === oldTx.walletId) {
          currentWallet.balance += (oldTx.amount + oldTx.fee);
        } else if (oldTx.type === 'transfer') {
          if (currentWallet.id === oldTx.walletId) {
            currentWallet.balance += (oldTx.amount + oldTx.fee);
          } else if (currentWallet.id === oldTx.targetWalletId) {
            currentWallet.balance -= oldTx.amount;
          }
        }

        // Apply new balance effect
        if (updatedTx.type === 'deposit' && currentWallet.id === updatedTx.walletId) {
          currentWallet.balance += (updatedTx.amount - updatedTx.fee);
        } else if (updatedTx.type === 'withdraw' && currentWallet.id === updatedTx.walletId) {
          currentWallet.balance -= (updatedTx.amount + updatedTx.fee);
        } else if (updatedTx.type === 'transfer') {
          if (currentWallet.id === updatedTx.walletId) {
            currentWallet.balance -= (updatedTx.amount + updatedTx.fee);
          } else if (currentWallet.id === updatedTx.targetWalletId) {
            currentWallet.balance += updatedTx.amount;
          }
        }

        currentWallet.lastUpdated = new Date().toISOString();
        return currentWallet;
      });
      updatedWalletsList = next;
      return next;
    });

    // Update transactions array (triggers the automatic date-based limit recalculation)
    setTransactions((prev) =>
      prev.map((t) => (t.id === updatedTx.id ? { ...updatedTx } : t))
    );

    // Sync updated transaction to Neon
    logTransactionToNeon(updatedTx).catch((err) => {
      console.warn('Could not sync updated transaction to Neon:', err);
    });

    // Sync affected wallets to Neon
    setTimeout(() => {
      if (updatedWalletsList.length > 0) {
        const affectedIds = new Set(
          [oldTx.walletId, oldTx.targetWalletId, updatedTx.walletId, updatedTx.targetWalletId].filter(Boolean)
        );
        updatedWalletsList
          .filter((w) => affectedIds.has(w.id))
          .forEach((w) => saveWalletToNeon(w).catch(() => {}));
      }
    }, 150);

    const oldDateKey = getLocalDateKey(oldTx.date);
    const newDateKey = getLocalDateKey(updatedTx.date);
    const dateChanged = oldDateKey !== newDateKey;

    const notif: SystemNotification = {
      id: `edit-tx-${Date.now()}`,
      title: 'تم تعديل المعاملة',
      message: dateChanged
        ? `تم تعديل تاريخ المعاملة رقم ${updatedTx.referenceNumber} من (${oldDateKey}) إلى (${newDateKey})، وتحديث الليمت اليومي الخاص بكل تاريخ تلقائياً.`
        : `تم تحديث بيانات المعاملة رقم ${updatedTx.referenceNumber} وتحديث الأرصدة والليمت المرتبط تلقائياً.`,
      type: 'success',
      timestamp: 'الآن',
      read: false,
    };
    setNotifications((prev) => [notif, ...prev]);
  };

  const addBill = (newBillData: Omit<RecurringBill, 'id' | 'createdAt'>) => {
    const newBill: RecurringBill = {
      ...newBillData,
      id: `bill-${Date.now()}`,
      createdAt: new Date().toISOString(),
    };
    setBills((prev) => [...prev, newBill]);

    const notif: SystemNotification = {
      id: `notif-bill-add-${Date.now()}`,
      title: 'تمت إضافة فاتورة دورية جديدة',
      message: `تم جدولة التنبيه الشهري لفاتورة "${newBill.title}" بمبلغ ${newBill.amount.toLocaleString()} ج.م (يوم ${newBill.dueDay} من كل شهر).`,
      type: 'success',
      timestamp: 'الآن',
      read: false,
      billId: newBill.id,
    };
    setNotifications((prev) => [notif, ...prev]);
  };

  const updateBill = (updated: RecurringBill) => {
    setBills((prev) => prev.map((b) => (b.id === updated.id ? updated : b)));
    const notif: SystemNotification = {
      id: `notif-bill-edit-${Date.now()}`,
      title: 'تم تحديث بيانات الفاتورة',
      message: `تم حفظ تعديلات فاتورة "${updated.title}" بنجاح.`,
      type: 'info',
      timestamp: 'الآن',
      read: false,
      billId: updated.id,
    };
    setNotifications((prev) => [notif, ...prev]);
  };

  const deleteBill = (billId: string) => {
    const b = bills.find((item) => item.id === billId);
    setBills((prev) => prev.filter((item) => item.id !== billId));
    const notif: SystemNotification = {
      id: `notif-bill-del-${Date.now()}`,
      title: 'تم حذف الفاتورة والتنبيه',
      message: `تم حذف فاتورة "${b ? b.title : ''}" وإلغاء تنبيهاتها الدورية.`,
      type: 'info',
      timestamp: 'الآن',
      read: false,
    };
    setNotifications((prev) => [notif, ...prev]);
  };

  const markBillAsPaid = (billId: string, monthKey?: string) => {
    const today = new Date();
    const currentMonthKey = monthKey || `${today.getFullYear()}-${String(today.getMonth() + 1).padStart(2, '0')}`;
    setBills((prev) =>
      prev.map((b) => (b.id === billId ? { ...b, lastPaidMonth: currentMonthKey } : b))
    );
    const targetBill = bills.find((b) => b.id === billId);
    if (targetBill) {
      const notif: SystemNotification = {
        id: `bill-paid-${Date.now()}`,
        title: 'تم سداد الفاتورة بنجاح',
        message: `تم تسجيل سداد فاتورة "${targetBill.title}" لشهر ${currentMonthKey}.`,
        type: 'success',
        timestamp: 'الآن',
        read: false,
        billId,
      };
      setNotifications((prev) => [notif, ...prev]);
    }
  };

  const markBillAsUnpaid = (billId: string) => {
    setBills((prev) =>
      prev.map((b) => (b.id === billId ? { ...b, lastPaidMonth: '' } : b))
    );
  };

  const triggerTestBillReminder = (billId: string) => {
    const b = bills.find((item) => item.id === billId);
    if (!b) return;

    const title = `🔔 [تجربة تنبيه] تذكير فاتورة: ${b.title}`;
    const msg = `تذكير بموعد استحقاق ${b.title} بمبلغ ${b.amount.toLocaleString()} ج.م (يوم ${b.dueDay} من كل شهر).`;

    const notif: SystemNotification = {
      id: `test-bill-${Date.now()}`,
      title,
      message: msg,
      type: 'warning',
      timestamp: 'الآن',
      read: false,
      billId: b.id,
    };

    setNotifications((prev) => [notif, ...prev]);
    triggerPushNotificationIfAllowed(title, msg);
  };

  const checkDueBillsAndNotify = () => {
    const today = new Date();
    const todayDay = today.getDate();
    const currentMonthKey = `${today.getFullYear()}-${String(today.getMonth() + 1).padStart(2, '0')}`;
    const todayDateKey = today.toISOString().split('T')[0];

    bills.forEach((bill) => {
      if (!bill.isActive || !bill.autoNotification) return;
      if (bill.lastPaidMonth === currentMonthKey) return;

      const daysRemaining = bill.dueDay - todayDay;
      const isDueSoon = daysRemaining >= 0 && daysRemaining <= bill.reminderDaysBefore;
      const isOverdue = daysRemaining < 0;

      if (isDueSoon || isOverdue) {
        const storageKey = `othmancash_bill_alert_${bill.id}_${todayDateKey}`;
        if (typeof window !== 'undefined' && localStorage.getItem(storageKey)) {
          return;
        }

        let title = '';
        let msg = '';
        let notifType: 'alert' | 'warning' | 'info' = 'warning';

        if (daysRemaining === 0) {
          title = `🚨 موعد السداد اليوم: ${bill.title}`;
          msg = `حان موعد سداد ${bill.title} بمبلغ ${bill.amount.toLocaleString()} ج.م اليوم!`;
          notifType = 'alert';
        } else if (daysRemaining < 0) {
          title = `⚠️ فاتورة متأخرة: ${bill.title}`;
          msg = `فاتورة ${bill.title} متأخرة عن موعدها منذ ${Math.abs(daysRemaining)} يوم (المبلغ: ${bill.amount.toLocaleString()} ج.م).`;
          notifType = 'alert';
        } else {
          title = `🔔 تذكير استحقاق فاتورة: ${bill.title}`;
          msg = `تذكير بموعد سداد ${bill.title} بمبلغ ${bill.amount.toLocaleString()} ج.م (تستحق يوم ${bill.dueDay} - متبقي ${daysRemaining} يوم).`;
          notifType = 'warning';
        }

        const notif: SystemNotification = {
          id: `bill-alert-${bill.id}-${Date.now()}`,
          title,
          message: msg,
          type: notifType,
          timestamp: 'الآن',
          read: false,
          billId: bill.id,
        };

        setNotifications((prev) => [notif, ...prev]);
        triggerPushNotificationIfAllowed(title, msg);

        try {
          localStorage.setItem(storageKey, 'true');
        } catch {
          // ignore
        }
      }
    });
  };

  useEffect(() => {
    checkDueBillsAndNotify();
    const interval = setInterval(checkDueBillsAndNotify, 1000 * 60 * 30);
    return () => clearInterval(interval);
  }, [bills]);

  const wipeAllData = () => {
    try {
      localStorage.removeItem(STORAGE_KEY_WALLETS);
      localStorage.removeItem(STORAGE_KEY_TRANSACTIONS);
      localStorage.removeItem(STORAGE_KEY_NOTIFS);
      localStorage.removeItem(STORAGE_KEY_PIN);
      localStorage.removeItem(STORAGE_KEY_BILLS);
      localStorage.removeItem(STORAGE_KEY_CATEGORIES);
      localStorage.removeItem(STORAGE_KEY_DEFAULT_TRANSFER_WALLET);
      if (typeof window !== 'undefined' && 'caches' in window) {
        caches.keys().then((names) => {
          names.forEach((name) => caches.delete(name));
        });
      }
    } catch (e) {
      console.warn('Error clearing storage:', e);
    }

    setWallets([]);
    setTransactions([]);
    setBills(DEFAULT_BILLS);
    setExpenseCategories(DEFAULT_EXPENSE_CATEGORIES);
    setDefaultTransferWalletId(DEFAULT_WALLETS[0]?.id || '');
    setPinCode('1234');
    setIsLocked(false);
    setNotifications([
      {
        id: `wipe-${Date.now()}`,
        title: 'تم مسح كافة بيانات الموقع بنجاح',
        message: 'تم تصفير جميع المحافظ والمعاملات والإشعارات وإعادة ضبط النظام بالكامل.',
        type: 'info',
        timestamp: 'الآن',
        read: false,
      },
    ]);
  };

  const markNotificationAsRead = (id: string) => {
    setNotifications((prev) => prev.map((n) => (n.id === id ? { ...n, read: true } : n)));
  };

  const markAllNotificationsAsRead = () => {
    setNotifications((prev) => prev.map((n) => ({ ...n, read: true })));
  };

  const clearNotifications = () => {
    setNotifications([]);
  };

  const resetDailyLimits = () => {
    setWallets((prev) =>
      prev.map((w) => ({
        ...w,
        dailySpent: 0,
        lastUpdated: new Date().toISOString(),
      }))
    );
    const notif: SystemNotification = {
      id: `reset-${Date.now()}`,
      title: 'بدء دورة يومية جديدة',
      message: 'تم تصفير استهلاك الليمت اليومي لجميع المحافظ لبدء يوم عمل جديد.',
      type: 'info',
      timestamp: 'الآن',
      read: false,
    };
    setNotifications((prev) => [notif, ...prev]);
  };

  const unlockApp = (pin: string) => {
    if (pin === pinCode) {
      setIsLocked(false);
      return true;
    }
    return false;
  };

  const lockApp = () => {
    setIsLocked(true);
  };

  const setAppPin = (newPin: string) => {
    setPinCode(newPin);
  };

  const totalBalance = wallets.reduce((acc, w) => acc + w.balance, 0);
  const totalDailySpent = wallets.reduce((acc, w) => acc + w.dailySpent, 0);
  const totalMonthlySpent = wallets.reduce((acc, w) => acc + w.monthlySpent, 0);
  const unreadNotificationsCount = notifications.filter((n) => !n.read).length;

  return (
    <FinancialContext.Provider
      value={{
        wallets,
        transactions,
        notifications,
        bills,
        expenseCategories,
        defaultTransferWalletId,
        defaultTransferWallet,
        setDefaultTransferWallet,
        unreadNotificationsCount,
        totalBalance,
        totalDailySpent,
        totalMonthlySpent,
        isLocked,
        pinCode,
        deposit,
        withdraw,
        transfer,
        transferGeneral,
        getWalletDailySpent,
        getWalletMonthlySpent,
        getWalletRemainingDailyLimit,
        getWalletDailyLimitStats,
        addExpenseCategory,
        updateExpenseCategory,
        deleteExpenseCategory,
        addWallet,
        updateWallet,
        deleteWallet,
        updateTransaction,
        deleteTransaction,
        addBill,
        updateBill,
        deleteBill,
        markBillAsPaid,
        markBillAsUnpaid,
        triggerTestBillReminder,
        checkDueBillsAndNotify,
        wipeAllData,
        markNotificationAsRead,
        markAllNotificationsAsRead,
        clearNotifications,
        resetDailyLimits,
        unlockApp,
        lockApp,
        setAppPin,
        neonStatus,
        isSyncingWithNeon,
        syncWithNeon,
        checkNeonConnection,
      }}
    >
      {children}
    </FinancialContext.Provider>
  );
};

export const useFinancial = () => {
  const context = useContext(FinancialContext);
  if (!context) {
    throw new Error('useFinancial must be used within a FinancialProvider');
  }
  return context;
};
