import React from 'react';
import { X, Share, PlusSquare, Smartphone, CheckCircle2, Download } from 'lucide-react';

interface InstallModalProps {
  isOpen: boolean;
  onClose: () => void;
  isIOS: boolean;
  isInstallable: boolean;
  isStandalone: boolean;
  onNativeInstall: () => Promise<void>;
}

export const InstallModal: React.FC<InstallModalProps> = ({
  isOpen,
  onClose,
  isIOS,
  isInstallable,
  isStandalone,
  onNativeInstall,
}) => {
  if (!isOpen) return null;

  return (
    <div className="fixed inset-0 z-50 flex items-center justify-center p-4 bg-black/80 backdrop-blur-sm animate-fade-in">
      <div className="relative w-full max-w-md rounded-2xl bg-[#1e293b] border border-slate-700/80 p-6 shadow-2xl text-white">
        {/* Close Button */}
        <button
          onClick={onClose}
          className="absolute left-4 top-4 p-2 text-slate-400 hover:text-white rounded-full bg-slate-800/60 hover:bg-slate-700 transition"
          aria-label="إغلاق"
        >
          <X className="w-5 h-5" />
        </button>

        {/* Header with App Icon */}
        <div className="flex items-center gap-3 mb-5 border-b border-slate-800 pb-4">
          <img
            src="/pwa-192x192.png"
            alt="عثمان كاش"
            className="w-14 h-14 rounded-xl shadow-md border border-emerald-500/30"
          />
          <div>
            <h2 className="text-xl font-bold text-white flex items-center gap-2">
              تثبيت عثمان كاش
              <span className="text-xs px-2 py-0.5 rounded-full bg-emerald-500/20 text-emerald-400 border border-emerald-500/30 font-medium">
                PWA
              </span>
            </h2>
            <p className="text-xs text-slate-400 mt-0.5">تجربة تطبيق أصلي على جوالك بدون متاجر تطبيقات</p>
          </div>
        </div>

        {/* Standalone status */}
        {isStandalone ? (
          <div className="rounded-xl bg-emerald-950/40 border border-emerald-500/40 p-4 text-center my-4">
            <CheckCircle2 className="w-12 h-12 text-emerald-400 mx-auto mb-2" />
            <h3 className="text-base font-bold text-emerald-300">التطبيق مثبت بالفعل على جهازك!</h3>
            <p className="text-xs text-slate-300 mt-1">
              أنت تستخدم عثمان كاش حالياً في وضع التطبيق المستقل (Standalone).
            </p>
          </div>
        ) : isIOS ? (
          /* Exact iPhone Safari instructions as specified in Requirement 7 */
          <div className="space-y-4">
            <div className="bg-slate-900/80 rounded-xl p-4 border border-slate-800">
              <h3 className="text-sm font-bold text-emerald-400 mb-3 flex items-center gap-2">
                <Smartphone className="w-4 h-4" />
                لتثبيت عثمان كاش على الآيفون:
              </h3>
              <ol className="text-xs text-slate-200 space-y-2.5 leading-relaxed pr-2 list-decimal list-inside">
                <li>
                  افتح الموقع من متصفح <strong className="text-white">Safari</strong>.
                </li>
                <li className="flex items-center gap-1.5 flex-wrap">
                  اضغط على زر المشاركة{' '}
                  <span className="inline-flex items-center gap-1 bg-slate-800 px-2 py-0.5 rounded border border-slate-700 text-sky-400">
                    <Share className="w-3.5 h-3.5 inline" /> المشاركة
                  </span>
                  {' '}في أسفل المتصفح.
                </li>
                <li className="flex items-center gap-1.5 flex-wrap">
                  اختر{' '}
                  <span className="inline-flex items-center gap-1 bg-slate-800 px-2 py-0.5 rounded border border-slate-700 text-emerald-400 font-semibold">
                    <PlusSquare className="w-3.5 h-3.5 inline" /> إضافة إلى الشاشة الرئيسية
                  </span>
                  .
                </li>
                <li>
                  اضغط على <strong className="text-white">إضافة</strong> (Add).
                </li>
              </ol>
            </div>
            <p className="text-xs text-slate-300 leading-relaxed bg-emerald-900/20 border border-emerald-800/40 p-3 rounded-xl">
              هتلاقي أيقونة عثمان كاش على الشاشة الرئيسية، وتقدر تفتح الموقع منها مباشرة.
            </p>
          </div>
        ) : (
          /* Android Chrome / Chromium instructions */
          <div className="space-y-4">
            {isInstallable ? (
              <div className="text-center py-2">
                <p className="text-xs text-slate-300 mb-4 leading-relaxed">
                  متصفحك يدعم التثبيت الفوري بنقرة واحدة. اضغط على الزر أدناه لتثبيت عثمان كاش على هاتفك.
                </p>
                <button
                  onClick={async () => {
                    await onNativeInstall();
                    onClose();
                  }}
                  className="w-full flex items-center justify-center gap-2 py-3 px-4 rounded-xl bg-gradient-to-r from-emerald-600 to-teal-500 hover:from-emerald-500 hover:to-teal-400 text-white font-bold text-sm shadow-lg shadow-emerald-900/40 transition active:scale-[0.98]"
                >
                  <Download className="w-5 h-5" />
                  تثبيت التطبيق على الموبايل الآن
                </button>
              </div>
            ) : (
              <div className="bg-slate-900/80 rounded-xl p-4 border border-slate-800">
                <h3 className="text-sm font-bold text-emerald-400 mb-3 flex items-center gap-2">
                  <Smartphone className="w-4 h-4" />
                  خطوات التثبيت على أندرويد (Chrome):
                </h3>
                <ol className="text-xs text-slate-200 space-y-2.5 leading-relaxed pr-2 list-decimal list-inside">
                  <li>افتح متصفح <strong className="text-white">Google Chrome</strong>.</li>
                  <li>اضغط على قائمة المتصفح الثلاث نقاط (<strong className="text-white">⋮</strong>) بأعلى الشاشة.</li>
                  <li>اختر <strong className="text-emerald-400">"تثبيت التطبيق"</strong> أو <strong className="text-emerald-400">"إضافة إلى الشاشة الرئيسية"</strong>.</li>
                  <li>أكد بالضغط على "تثبيت".</li>
                </ol>
              </div>
            )}
          </div>
        )}

        {/* Benefits bullets */}
        <div className="mt-4 pt-3 border-t border-slate-800 grid grid-cols-2 gap-2 text-[11px] text-slate-400">
          <div className="flex items-center gap-1.5">
            <span className="w-1.5 h-1.5 rounded-full bg-emerald-400"></span>
            <span>شاشة كاملة بدون شريط المتصفح</span>
          </div>
          <div className="flex items-center gap-1.5">
            <span className="w-1.5 h-1.5 rounded-full bg-emerald-400"></span>
            <span>فتح فوري بسرعة فائقة</span>
          </div>
          <div className="flex items-center gap-1.5">
            <span className="w-1.5 h-1.5 rounded-full bg-emerald-400"></span>
            <span>تنبيهات فورية لليمات اليومية</span>
          </div>
          <div className="flex items-center gap-1.5">
            <span className="w-1.5 h-1.5 rounded-full bg-emerald-400"></span>
            <span>أمان وحماية للأرصدة</span>
          </div>
        </div>

        <button
          onClick={onClose}
          className="mt-5 w-full py-2.5 rounded-xl bg-slate-800 hover:bg-slate-700 text-slate-200 text-xs font-semibold transition"
        >
          حسناً، فهمت
        </button>
      </div>
    </div>
  );
};
