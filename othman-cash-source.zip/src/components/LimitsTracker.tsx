import React from 'react';
import { AlertTriangle, RotateCcw, ShieldCheck, TrendingUp, Info } from 'lucide-react';
import { useFinancial } from '../context/FinancialContext';

export const LimitsTracker: React.FC = () => {
  const { wallets, resetDailyLimits } = useFinancial();

  // Find wallets with high usage
  const warningWallets = wallets.filter(
    (w) => w.dailySpent / w.dailyLimit >= 0.75 || w.monthlySpent / w.monthlyLimit >= 0.8
  );

  return (
    <div className="rounded-2xl bg-[#1e293b]/90 border border-slate-700/80 p-4 sm:p-5 shadow-lg">
      <div className="flex flex-col sm:flex-row sm:items-center justify-between gap-3 mb-4 pb-3 border-b border-slate-800">
        <div>
          <h2 className="text-base sm:text-lg font-bold text-white flex items-center gap-2">
            <span>متابعة الليمت اليومي والشهري</span>
            {warningWallets.length > 0 && (
              <span className="text-[11px] px-2 py-0.5 rounded-full bg-amber-500/20 text-amber-300 border border-amber-500/40 flex items-center gap-1 font-semibold">
                <AlertTriangle className="w-3 h-3" />
                {warningWallets.length} محفظة قريبة من الحد الأقصى
              </span>
            )}
          </h2>
          <p className="text-xs text-slate-400 mt-0.5">
            مراقبة استهلاك الحدود القصوى للمحافظ لتجنب توقف المعاملات اليومية والشهرية
          </p>
        </div>

        <button
          onClick={() => {
            if (window.confirm('هل تريد تصفير استهلاك الليمت اليومي لجميع المحافظ لبدء يوم جديد؟')) {
              resetDailyLimits();
            }
          }}
          className="self-start sm:self-auto flex items-center gap-1.5 px-3 py-1.5 rounded-xl bg-slate-800 hover:bg-slate-700 text-slate-200 text-xs font-semibold border border-slate-700 transition"
        >
          <RotateCcw className="w-3.5 h-3.5 text-emerald-400" />
          <span>تصفير الليمت اليومي</span>
        </button>
      </div>

      {/* Grid of wallets and their limit status */}
      <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-3">
        {wallets.map((wallet) => {
          const dailyPercent = Math.min(100, Math.round((wallet.dailySpent / wallet.dailyLimit) * 100));
          const monthlyPercent = Math.min(100, Math.round((wallet.monthlySpent / wallet.monthlyLimit) * 100));
          const dailyRemaining = Math.max(0, wallet.dailyLimit - wallet.dailySpent);

          return (
            <div
              key={wallet.id}
              className={`rounded-xl p-3.5 border transition ${
                dailyPercent >= 85
                  ? 'bg-rose-950/20 border-rose-500/40'
                  : dailyPercent >= 70
                  ? 'bg-amber-950/20 border-amber-500/40'
                  : 'bg-slate-900/50 border-slate-800'
              }`}
            >
              <div className="flex items-center justify-between mb-2">
                <span className="font-bold text-sm text-white line-clamp-1">{wallet.name}</span>
                <span
                  className={`text-[11px] font-mono font-bold px-1.5 py-0.5 rounded ${
                    dailyPercent >= 85
                      ? 'bg-rose-500/20 text-rose-300'
                      : dailyPercent >= 70
                      ? 'bg-amber-500/20 text-amber-300'
                      : 'bg-emerald-500/20 text-emerald-300'
                  }`}
                >
                  {dailyPercent}% مستهلك
                </span>
              </div>

              {/* Progress Bar */}
              <div className="w-full bg-slate-800 h-2 rounded-full overflow-hidden mb-2">
                <div
                  className={`h-full rounded-full transition-all duration-300 ${
                    dailyPercent >= 90
                      ? 'bg-rose-500'
                      : dailyPercent >= 70
                      ? 'bg-amber-400'
                      : 'bg-emerald-500'
                  }`}
                  style={{ width: `${dailyPercent}%` }}
                />
              </div>

              <div className="flex justify-between items-center text-[11px] text-slate-400">
                <span>
                  متبقي اليوم:{' '}
                  <strong className="text-white font-mono">{dailyRemaining.toLocaleString()} ج.م</strong>
                </span>
                <span>
                  الشهري:{' '}
                  <strong className="text-slate-300 font-mono">{monthlyPercent}%</strong>
                </span>
              </div>
            </div>
          );
        })}
      </div>
    </div>
  );
};
