import React, { useState } from 'react';
import { Shield, Key, PlusCircle, HardDrive, Trash2, Edit3, Eye, EyeOff, Tag, CheckCircle, Bell, AlertTriangle } from 'lucide-react';
import { useFinancial } from '../context/FinancialContext';
import { Wallet, WalletProvider } from '../types';

interface SettingsViewProps {
  onRequestPushPermission?: () => Promise<void>;
  pushPermissionStatus?: NotificationPermission;
  onEditWallet?: (wallet: Wallet) => void;
  onOpenManageCategories?: () => void;
}

export const SettingsView: React.FC<SettingsViewProps> = ({
  onRequestPushPermission,
  pushPermissionStatus,
  onEditWallet,
  onOpenManageCategories,
}) => {
  const { pinCode, setAppPin, addWallet, wallets, expenseCategories, wipeAllData, deleteWallet } = useFinancial();
  const [currentPinInput, setCurrentPinInput] = useState(pinCode);
  const [showPin, setShowPin] = useState(false);
  const [pinSavedFeedback, setPinSavedFeedback] = useState(false);
  const [showWipeConfirm, setShowWipeConfirm] = useState(false);

  // New Wallet Form State
  const [showAddWallet, setShowAddWallet] = useState(false);
  const [newWalletName, setNewWalletName] = useState('');
  const [newWalletProvider, setNewWalletProvider] = useState<WalletProvider>('accesspay');
  const [newWalletNumber, setNewWalletNumber] = useState('');
  const [newWalletBalance, setNewWalletBalance] = useState('');
  const [newWalletDailyLimit, setNewWalletDailyLimit] = useState('60000');
  const [newWalletMonthlyLimit, setNewWalletMonthlyLimit] = useState('200000');

  const handleSavePin = (e: React.FormEvent) => {
    e.preventDefault();
    if (currentPinInput.trim().length > 0) {
      setAppPin(currentPinInput.trim());
      setPinSavedFeedback(true);
      setTimeout(() => setPinSavedFeedback(false), 2500);
    }
  };

  const handleAddWallet = (e: React.FormEvent) => {
    e.preventDefault();
    if (!newWalletName.trim() || !newWalletNumber.trim()) return;

    addWallet({
      name: newWalletName,
      provider: newWalletProvider,
      accountNumber: newWalletNumber,
      balance: parseFloat(newWalletBalance) || 0,
      dailyLimit: parseFloat(newWalletDailyLimit) || 60000,
      dailySpent: 0,
      monthlyLimit: parseFloat(newWalletMonthlyLimit) || 200000,
      monthlySpent: 0,
      isActive: true,
      color:
        newWalletProvider === 'accesspay'
          ? '#0ea5e9'
          : newWalletProvider === 'vodafone'
          ? '#e60000'
          : newWalletProvider === 'orange'
          ? '#ff7900'
          : newWalletProvider === 'etisalat'
          ? '#009639'
          : newWalletProvider === 'instapay'
          ? '#7c3aed'
          : '#10b981',
    });

    setNewWalletName('');
    setNewWalletNumber('');
    setNewWalletBalance('');
    setShowAddWallet(false);
  };

  const handleClearCacheAndReload = async () => {
    if (window.confirm('هل تريد مسح الكاش المؤقت وتحديث التطبيق؟')) {
      if ('caches' in window) {
        const cacheNames = await caches.keys();
        await Promise.all(cacheNames.map((name) => caches.delete(name)));
      }
      window.location.reload();
    }
  };

  const handleWipeAllData = () => {
    wipeAllData();
    setShowWipeConfirm(false);
  };

  return (
    <div className="space-y-6 max-w-4xl mx-auto">


      {/* Wallet Management Section with Edit & Delete */}
      <div className="rounded-2xl bg-[#1e293b]/95 border border-slate-700/80 p-4 sm:p-5 shadow">
        <div className="flex flex-col sm:flex-row sm:items-center justify-between gap-3 mb-4 pb-3 border-b border-slate-800">
          <div>
            <h3 className="text-base font-bold text-white flex items-center gap-2">
              <HardDrive className="w-4 h-4 text-emerald-400" />
              <span>إدارة وتعديل المحافظ والحسابات ({wallets.length})</span>
            </h3>
            <p className="text-xs text-slate-400">تعديل بيانات المحافظ بعد حفظها أو مسحها نهائياً</p>
          </div>

          <button
            onClick={() => setShowAddWallet(!showAddWallet)}
            className="flex items-center gap-1.5 px-3.5 py-2 rounded-xl bg-emerald-600 hover:bg-emerald-500 text-white text-xs sm:text-sm font-bold transition shadow"
          >
            <PlusCircle className="w-4 h-4" />
            <span>إضافة محفظة جديدة</span>
          </button>
        </div>

        {/* Add Wallet Form */}
        {showAddWallet && (
          <form onSubmit={handleAddWallet} className="bg-slate-900 p-4 rounded-xl border border-slate-800 space-y-3 mb-5 text-xs sm:text-sm">
            <h4 className="font-bold text-emerald-400 text-sm">بيانات المحفظة الجديدة</h4>
            <div className="grid grid-cols-1 sm:grid-cols-2 gap-3">
              <div>
                <label className="block text-slate-300 font-medium mb-1">اسم المحفظة *</label>
                <input
                  type="text"
                  required
                  placeholder="مثال: أكسس باي - فرع رئيسي"
                  value={newWalletName}
                  onChange={(e) => setNewWalletName(e.target.value)}
                  className="w-full bg-slate-800 border border-slate-700 rounded-lg p-2.5 text-white text-sm"
                />
              </div>

              <div>
                <label className="block text-slate-300 font-medium mb-1">مقدم الخدمة *</label>
                <select
                  value={newWalletProvider}
                  onChange={(e) => setNewWalletProvider(e.target.value as WalletProvider)}
                  className="w-full bg-slate-800 border border-slate-700 rounded-lg p-2.5 text-white text-sm"
                >
                  <option value="accesspay">أكسس باي (Access Pay)</option>
                  <option value="vodafone">فودافون كاش</option>
                  <option value="orange">أورنج كاش</option>
                  <option value="etisalat">اتصالات كاش</option>
                  <option value="instapay">إنستاباي (InstaPay)</option>
                  <option value="bank_misr">بنك مصر</option>
                  <option value="nbe">البنك الأهلي المصري</option>
                  <option value="cash_vault">خزينة نقدية (كاش يدوي)</option>
                </select>
              </div>

              <div>
                <label className="block text-slate-300 font-medium mb-1">رقم الهاتف أو الحساب *</label>
                <input
                  type="text"
                  required
                  placeholder="010XXXXXXXX أو كود المحفظة"
                  value={newWalletNumber}
                  onChange={(e) => setNewWalletNumber(e.target.value)}
                  className="w-full bg-slate-800 border border-slate-700 rounded-lg p-2.5 text-white text-sm font-mono"
                />
              </div>

              <div>
                <label className="block text-slate-300 font-medium mb-1">الرصيد الافتتاحي (ج.م)</label>
                <input
                  type="number"
                  placeholder="0"
                  value={newWalletBalance}
                  onChange={(e) => setNewWalletBalance(e.target.value)}
                  className="w-full bg-slate-800 border border-slate-700 rounded-lg p-2.5 text-white text-sm font-mono font-bold"
                />
              </div>

              <div>
                <label className="block text-slate-300 font-medium mb-1">الليمات اليومي (ج.م)</label>
                <input
                  type="number"
                  value={newWalletDailyLimit}
                  onChange={(e) => setNewWalletDailyLimit(e.target.value)}
                  className="w-full bg-slate-800 border border-slate-700 rounded-lg p-2.5 text-white text-sm font-mono"
                />
              </div>

              <div>
                <label className="block text-slate-300 font-medium mb-1">الليمات الشهري (ج.م)</label>
                <input
                  type="number"
                  value={newWalletMonthlyLimit}
                  onChange={(e) => setNewWalletMonthlyLimit(e.target.value)}
                  className="w-full bg-slate-800 border border-slate-700 rounded-lg p-2.5 text-white text-sm font-mono"
                />
              </div>
            </div>

            <div className="flex justify-end gap-2 pt-2">
              <button
                type="button"
                onClick={() => setShowAddWallet(false)}
                className="px-3.5 py-2 rounded-lg bg-slate-800 text-slate-300 hover:bg-slate-700 text-xs sm:text-sm font-semibold"
              >
                إلغاء
              </button>
              <button
                type="submit"
                className="px-4 py-2 rounded-lg bg-emerald-600 hover:bg-emerald-500 text-white font-bold text-xs sm:text-sm shadow"
              >
                إضافة المحفظة
              </button>
            </div>
          </form>
        )}

        {/* Existing Wallets Quick List with Edit & Delete Buttons */}
        <div className="space-y-2.5">
          {wallets.map((wallet) => (
            <div
              key={wallet.id}
              className="flex items-center justify-between p-3 sm:p-3.5 rounded-xl bg-slate-900/80 border border-slate-800 hover:border-slate-700 transition"
            >
              <div className="flex items-center gap-3">
                <span
                  className="w-3.5 h-3.5 rounded-full shrink-0"
                  style={{ backgroundColor: wallet.color || '#10b981' }}
                />
                <div>
                  <h4 className="font-bold text-sm sm:text-base text-white">{wallet.name}</h4>
                  <span className="text-xs text-slate-400 font-mono">
                    {wallet.accountNumber} • رصيد:{' '}
                    <strong className="text-emerald-400 font-bold">{wallet.balance.toLocaleString()} ج.م</strong>
                  </span>
                </div>
              </div>

              <div className="flex items-center gap-1.5">
                {onEditWallet && (
                  <button
                    onClick={() => onEditWallet(wallet)}
                    className="flex items-center gap-1 px-2.5 py-1.5 rounded-lg bg-slate-800 hover:bg-slate-700 text-slate-200 text-xs font-semibold border border-slate-700 transition"
                    title="تعديل بيانات المحفظة"
                  >
                    <Edit3 className="w-3.5 h-3.5 text-emerald-400" />
                    <span>تعديل</span>
                  </button>
                )}
                <button
                  onClick={() => {
                    if (window.confirm(`هل أنت متأكد من مسح المحفظة "${wallet.name}"؟`)) {
                      deleteWallet(wallet.id);
                    }
                  }}
                  className="p-1.5 rounded-lg text-slate-400 hover:text-rose-400 hover:bg-slate-800 transition"
                  title="مسح المحفظة"
                >
                  <Trash2 className="w-4 h-4" />
                </button>
              </div>
            </div>
          ))}
        </div>
      </div>

      {/* Security & PIN Settings */}
      <div className="rounded-2xl bg-[#1e293b]/95 border border-slate-700/80 p-4 sm:p-5 shadow">
        <h3 className="text-base font-bold text-white mb-3 flex items-center gap-2">
          <Shield className="w-4 h-4 text-amber-400" />
          <span>تعديل رمز الأمان ورمز الدخول (PIN Code)</span>
        </h3>

        <form onSubmit={handleSavePin} className="space-y-3">
          <div className="max-w-md">
            <div className="flex items-center justify-between mb-1.5">
              <label className="block text-xs sm:text-sm text-slate-300 font-semibold">
                الرمز السري لقفل التطبيق (PIN) — يمكنك تعيين أي عدد من الأرقام
              </label>
              <span className="text-[11px] font-mono text-slate-400">
                {currentPinInput.length > 0 ? `${currentPinInput.length} أرقام` : 'فارغ'}
              </span>
            </div>
            <div className="flex gap-2 items-center">
              <div className="relative flex-1">
                <input
                  type={showPin ? 'text' : 'password'}
                  inputMode="numeric"
                  placeholder="اكتب الرمز السري الجديد (أي طول تريده)..."
                  value={currentPinInput}
                  onChange={(e) => setCurrentPinInput(e.target.value)}
                  className="w-full bg-slate-900 border border-slate-700 rounded-xl px-3.5 py-2.5 pl-11 text-white font-mono text-sm sm:text-base font-bold tracking-wider focus:outline-none focus:border-amber-500 focus:ring-1 focus:ring-amber-500/20 transition"
                />
                {/* Eye toggle button to show/hide the security PIN */}
                <button
                  type="button"
                  onClick={() => setShowPin(!showPin)}
                  className="absolute left-2 top-1/2 -translate-y-1/2 p-1.5 text-slate-400 hover:text-amber-400 hover:bg-slate-800 rounded-lg transition"
                  title={showPin ? 'إخفاء الرمز السري' : 'إظهار الرمز السري'}
                  aria-label={showPin ? 'إخفاء الرمز السري' : 'إظهار الرمز السري'}
                >
                  {showPin ? <EyeOff className="w-4 h-4 text-amber-400" /> : <Eye className="w-4 h-4" />}
                </button>
              </div>
              <button
                type="submit"
                className="px-4 py-2.5 rounded-xl bg-amber-600 hover:bg-amber-500 text-white font-bold text-xs sm:text-sm transition whitespace-nowrap shadow flex items-center gap-1.5"
              >
                <Key className="w-4 h-4" />
                <span>حفظ الرمز</span>
              </button>
            </div>
            {pinSavedFeedback && (
              <span className="text-xs text-emerald-400 mt-1.5 flex items-center gap-1">
                <CheckCircle className="w-3.5 h-3.5" />
                <span>تم تحديث وحفظ رمز الأمان بنجاح ✓ (طول الرمز: {pinCode.length} أرقام)</span>
              </span>
            )}
          </div>
          <p className="text-xs text-slate-400">
            يستخدم هذا الرمز لقفل الشاشة وحماية بياناتك. اضغط على أيقونة العين لإظهار الرقم أو إخفائه أثناء التعديل.
          </p>
        </form>
      </div>

      {/* Fixed Monthly Bills Reminders Configuration */}


      {/* Custom Expense Categories Configuration */}
      <div className="rounded-2xl bg-[#1e293b]/95 border border-slate-700/80 p-4 sm:p-5 shadow">
        <div className="flex flex-col sm:flex-row sm:items-center justify-between gap-3 mb-3">
          <div className="flex items-center gap-2">
            <div className="p-2 rounded-xl bg-purple-500/20 text-purple-400 border border-purple-500/30">
              <Tag className="w-4 h-4" />
            </div>
            <div>
              <h3 className="text-base font-bold text-white">تصنيفات المصروفات المخصصة</h3>
              <p className="text-xs text-slate-400">
                إنشاء وتعديل تصنيفات المصروفات لتظهر في الرسم البياني الدائري وسجل العمليات
              </p>
            </div>
          </div>

          {onOpenManageCategories && (
            <button
              type="button"
              onClick={onOpenManageCategories}
              className="flex items-center gap-2 px-4 py-2 rounded-xl bg-gradient-to-r from-purple-600 to-indigo-600 hover:from-purple-500 hover:to-indigo-500 text-white text-xs sm:text-sm font-bold transition shadow-md self-start sm:self-auto"
            >
              <Tag className="w-4 h-4" />
              <span>إدارة التصنيفات ({expenseCategories.length})</span>
            </button>
          )}
        </div>

        <div className="flex flex-wrap gap-2 pt-2.5 border-t border-slate-800">
          {expenseCategories.map((cat) => (
            <span
              key={cat.id}
              className="inline-flex items-center gap-1.5 px-3 py-1.5 rounded-lg text-xs font-medium bg-slate-900 border border-slate-800 text-slate-200"
            >
              <span className="w-2.5 h-2.5 rounded-full" style={{ backgroundColor: cat.color }} />
              <span>{cat.name}</span>
              {!cat.isDefault && <span className="text-[10px] text-purple-400 font-bold">(مخصص)</span>}
            </span>
          ))}
        </div>
      </div>

      {/* Push Notifications Configuration */}
      <div className="rounded-2xl bg-[#1e293b]/95 border border-slate-700/80 p-4 sm:p-5 shadow">
        <h3 className="text-base font-bold text-white mb-2 flex items-center gap-2">
          <Bell className="w-4 h-4 text-emerald-400" />
          <span>إعدادات الإشعارات والتنبيهات الذكية</span>
        </h3>
        <p className="text-xs sm:text-sm text-slate-400 mb-4">
          يقوم عثمان كاش بإرسال تنبيهات لحظية عند اقتراب استهلاك الليمت الشهري واليومي.
        </p>

        <div className="flex items-center justify-between p-3.5 bg-slate-900 rounded-xl border border-slate-800">
          <div>
            <span className="text-xs sm:text-sm font-bold text-white block">إذن إشعارات المتصفح والـ PWA</span>
            <span className="text-xs text-slate-400 font-mono">
              الحالة الحالية:{' '}
              {pushPermissionStatus === 'granted'
                ? 'مسموح بها (Granted)'
                : pushPermissionStatus === 'denied'
                ? 'محظورة (Denied)'
                : 'بانتظار الموافقة (Default)'}
            </span>
          </div>

          <button
            onClick={onRequestPushPermission}
            className={`px-3.5 py-2 rounded-xl text-xs sm:text-sm font-bold transition ${
              pushPermissionStatus === 'granted'
                ? 'bg-emerald-950 text-emerald-400 border border-emerald-500/30'
                : 'bg-emerald-600 hover:bg-emerald-500 text-white'
            }`}
          >
            {pushPermissionStatus === 'granted' ? 'مفعلة ✓' : 'طلب الإذن'}
          </button>
        </div>
      </div>

      {/* DANGER ZONE: Wipe All Site Data (Requirement 4) */}
      <div className="rounded-2xl bg-rose-950/30 border border-rose-500/40 p-4 sm:p-6 shadow-xl">
        <div className="flex items-start gap-3">
          <div className="p-2.5 rounded-xl bg-rose-500/20 text-rose-400 shrink-0">
            <AlertTriangle className="w-5 h-5 sm:w-6 sm:h-6" />
          </div>
          <div className="flex-1">
            <h3 className="text-base sm:text-lg font-bold text-white">منطقة الخطر: مسح كافة بيانات الموقع</h3>
            <p className="text-xs sm:text-sm text-slate-300 mt-1 leading-relaxed">
              يقوم هذا الإجراء بحذف جميع المحافظ المسجلة، وسجل العمليات والتحويلات، والإشعارات، وإعادة ضبط التطبيق بالكامل إلى نقطة البداية.
            </p>

            <div className="mt-4">
              {!showWipeConfirm ? (
                <button
                  onClick={() => setShowWipeConfirm(true)}
                  className="flex items-center gap-2 px-4 py-2.5 rounded-xl bg-rose-600 hover:bg-rose-500 text-white font-bold text-xs sm:text-sm shadow-lg shadow-rose-950/50 transition active:scale-95"
                >
                  <Trash2 className="w-4 h-4" />
                  <span>مسح كافة بيانات الموقع نهائياً</span>
                </button>
              ) : (
                <div className="p-3.5 rounded-xl bg-rose-900/60 border border-rose-500/60 flex flex-col sm:flex-row items-center justify-between gap-3 animate-fade-in">
                  <div className="text-xs sm:text-sm text-rose-100 font-semibold">
                    هل أنت متأكد تماماً؟ لا يمكن التراجع عن هذه الخطوة بعد مسح البيانات!
                  </div>
                  <div className="flex items-center gap-2 w-full sm:w-auto">
                    <button
                      onClick={() => setShowWipeConfirm(false)}
                      className="flex-1 sm:flex-none px-3.5 py-1.5 rounded-lg bg-slate-800 text-slate-300 text-xs font-bold"
                    >
                      إلغاء
                    </button>
                    <button
                      onClick={handleWipeAllData}
                      className="flex-1 sm:flex-none px-4 py-1.5 rounded-lg bg-rose-700 hover:bg-rose-600 text-white text-xs font-bold shadow transition animate-pulse"
                    >
                      نعم، امسح كل البيانات الآن
                    </button>
                  </div>
                </div>
              )}
            </div>
          </div>
        </div>
      </div>
    </div>
  );
};
