import React from 'react';
import { LayoutDashboard, WalletCards, ArrowLeftRight, History, Settings, Plus } from 'lucide-react';

export type ActiveTab = 'dashboard' | 'wallets' | 'history' | 'settings';

interface BottomNavProps {
  activeTab: ActiveTab;
  setActiveTab: (tab: ActiveTab) => void;
  onOpenQuickAction: () => void;
}

export const BottomNav: React.FC<BottomNavProps> = ({
  activeTab,
  setActiveTab,
  onOpenQuickAction,
}) => {
  return (
    <nav className="fixed bottom-0 left-0 right-0 z-30 bg-[#101827]/95 backdrop-blur-lg border-t border-slate-800/90 pb-[env(safe-area-inset-bottom,8px)] pt-1 sm:hidden">
      <div className="grid grid-cols-5 items-center px-2 py-1 max-w-md mx-auto">
        {/* Tab 1: Dashboard */}
        <button
          onClick={() => setActiveTab('dashboard')}
          className={`flex flex-col items-center justify-center py-1 transition ${
            activeTab === 'dashboard' ? 'text-emerald-400 font-bold' : 'text-slate-400 hover:text-slate-200'
          }`}
        >
          <LayoutDashboard className={`w-5 h-5 ${activeTab === 'dashboard' ? 'stroke-[2.5]' : 'stroke-2'}`} />
          <span className="text-[10px] mt-0.5">الرئيسية</span>
        </button>

        {/* Tab 2: Wallets */}
        <button
          onClick={() => setActiveTab('wallets')}
          className={`flex flex-col items-center justify-center py-1 transition ${
            activeTab === 'wallets' ? 'text-emerald-400 font-bold' : 'text-slate-400 hover:text-slate-200'
          }`}
        >
          <WalletCards className={`w-5 h-5 ${activeTab === 'wallets' ? 'stroke-[2.5]' : 'stroke-2'}`} />
          <span className="text-[10px] mt-0.5">المحافظ</span>
        </button>

        {/* Center Action Button: Quick Operations */}
        <div className="flex flex-col items-center justify-center -mt-5">
          <button
            onClick={onOpenQuickAction}
            className="w-12 h-12 rounded-full bg-gradient-to-tr from-emerald-600 to-teal-400 text-white flex items-center justify-center shadow-lg shadow-emerald-950/80 border-4 border-[#101827] active:scale-95 transition transform"
            title="عملية مالية سريعة"
            aria-label="عملية جديدة"
          >
            <Plus className="w-6 h-6 stroke-[3]" />
          </button>
          <span className="text-[9px] font-bold text-emerald-400 mt-0.5">عملية</span>
        </div>

        {/* Tab 4: History */}
        <button
          onClick={() => setActiveTab('history')}
          className={`flex flex-col items-center justify-center py-1 transition ${
            activeTab === 'history' ? 'text-emerald-400 font-bold' : 'text-slate-400 hover:text-slate-200'
          }`}
        >
          <History className={`w-5 h-5 ${activeTab === 'history' ? 'stroke-[2.5]' : 'stroke-2'}`} />
          <span className="text-[10px] mt-0.5">السجل</span>
        </button>

        {/* Tab 5: Settings */}
        <button
          onClick={() => setActiveTab('settings')}
          className={`flex flex-col items-center justify-center py-1 transition ${
            activeTab === 'settings' ? 'text-emerald-400 font-bold' : 'text-slate-400 hover:text-slate-200'
          }`}
        >
          <Settings className={`w-5 h-5 ${activeTab === 'settings' ? 'stroke-[2.5]' : 'stroke-2'}`} />
          <span className="text-[10px] mt-0.5">الإعدادات</span>
        </button>
      </div>
    </nav>
  );
};
