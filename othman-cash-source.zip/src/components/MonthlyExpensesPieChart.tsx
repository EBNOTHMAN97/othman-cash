import React, { useState, useMemo } from 'react';
import {
  ResponsiveContainer,
  PieChart,
  Pie,
  Cell,
  Tooltip,
  Legend,
} from 'recharts';
import { PieChart as PieChartIcon, Calendar, ArrowUpRight, Filter, TrendingDown, Tag, Plus } from 'lucide-react';
import { useFinancial } from '../context/FinancialContext';

// Color palette designed to be vibrant, eye-catching, and dark-theme friendly
const CATEGORY_COLORS: Record<string, string> = {
  'سحب كاش للعميل': '#10b981', // Emerald
  'سحب نقدي للعميل': '#14b8a6', // Teal
  'سداد فواتير وخدمات': '#3b82f6', // Blue
  'مصاريف تشغيل وإيجار': '#f59e0b', // Amber
  'مشتريات وبضاعة': '#8b5cf6', // Violet
  'عمولات ورسوم بنكية': '#ec4899', // Pink
  'مصاريف نثرية وشخصية': '#f43f5e', // Rose
  'تحويلات منصرفة': '#6366f1', // Indigo
  'تحويل عام للخارج': '#0284c7', // Sky
};

const FALLBACK_COLORS = [
  '#10b981',
  '#f59e0b',
  '#8b5cf6',
  '#3b82f6',
  '#ec4899',
  '#14b8a6',
  '#f43f5e',
  '#6366f1',
  '#84cc16',
  '#06b6d4',
  '#d97706',
  '#a855f7',
];

interface MonthlyExpensesPieChartProps {
  onOpenWithdraw?: () => void;
  onOpenManageCategories?: () => void;
}

export const MonthlyExpensesPieChart: React.FC<MonthlyExpensesPieChartProps> = ({
  onOpenWithdraw,
  onOpenManageCategories,
}) => {
  const { transactions, expenseCategories } = useFinancial();
  const [filterMode, setFilterMode] = useState<'current_month' | 'all'>('current_month');
  const [activeIndex, setActiveIndex] = useState<number | null>(null);

  // Current system date & localized month name
  const currentDate = new Date();
  const currentYear = currentDate.getFullYear();
  const currentMonth = currentDate.getMonth();

  const monthNamesArabic = [
    'يناير', 'فبراير', 'مارس', 'أبريل', 'مايو', 'يونيو',
    'يوليو', 'أغسطس', 'سبتمبر', 'أكتوبر', 'نوفمبر', 'ديسمبر',
  ];
  const currentMonthLabel = `${monthNamesArabic[currentMonth]} ${currentYear}`;

  // Filter expenses (withdrawals + general external transfers) for current month or all time
  const { chartData, totalMonthlyExpenses, transactionCount } = useMemo(() => {
    const expenseTxs = transactions.filter((t) => {
      const isExpense = t.type === 'withdraw' || (t.type === 'transfer' && t.transferKind === 'general');
      if (!isExpense) return false;

      if (filterMode === 'current_month') {
        const txDate = new Date(t.date);
        return txDate.getFullYear() === currentYear && txDate.getMonth() === currentMonth;
      }
      return true;
    });

    const categoryMap: Record<string, { value: number; count: number }> = {};

    expenseTxs.forEach((tx) => {
      const cat = (tx.category && tx.category.trim()) ? tx.category.trim() : 'مصاريف أخرى';
      const expenseAmount = (Number(tx.amount) || 0) + (Number(tx.fee) || 0);

      if (!categoryMap[cat]) {
        categoryMap[cat] = { value: 0, count: 0 };
      }
      categoryMap[cat].value += expenseAmount;
      categoryMap[cat].count += 1;
    });

    const total = Object.values(categoryMap).reduce((acc, curr) => acc + curr.value, 0);

    const data = Object.entries(categoryMap)
      .map(([name, item], index) => {
        // First check user's custom category color
        const matchedCustom = expenseCategories.find(
          (c) => c.name.trim().toLowerCase() === name.trim().toLowerCase()
        );
        const color =
          matchedCustom?.color ||
          CATEGORY_COLORS[name] ||
          FALLBACK_COLORS[index % FALLBACK_COLORS.length];

        const percent = total > 0 ? (item.value / total) * 100 : 0;
        return {
          name,
          value: item.value,
          count: item.count,
          percent: parseFloat(percent.toFixed(1)),
          color,
          isCustom: !!matchedCustom && !matchedCustom.isDefault,
        };
      })
      .sort((a, b) => b.value - a.value);

    return {
      chartData: data,
      totalMonthlyExpenses: total,
      transactionCount: expenseTxs.length,
    };
  }, [transactions, expenseCategories, filterMode, currentYear, currentMonth]);

  // Custom Tooltip component for Recharts
  const CustomTooltip = ({ active, payload }: any) => {
    if (active && payload && payload.length) {
      const data = payload[0].payload;
      return (
        <div className="bg-[#0f172a]/95 border border-slate-700/80 rounded-xl p-3 shadow-2xl backdrop-blur-md text-right min-w-[170px] z-50">
          <div className="flex items-center gap-2 mb-1.5 justify-end">
            <span className="text-sm font-bold text-white">{data.name}</span>
            <span
              className="w-3 h-3 rounded-full shrink-0 shadow-sm"
              style={{ backgroundColor: data.color }}
            />
          </div>
          <div className="text-xs text-slate-300 flex items-center justify-between border-t border-slate-800 pt-1.5">
            <span className="font-mono font-bold text-emerald-400 text-sm">
              {data.value.toLocaleString()} ج.م
            </span>
            <span className="text-slate-400">القيمة:</span>
          </div>
          <div className="text-xs text-slate-400 flex items-center justify-between mt-1">
            <span className="font-mono text-amber-300 font-bold">{data.percent}%</span>
            <span>النسبة:</span>
          </div>
          <div className="text-[11px] text-slate-400 flex items-center justify-between mt-1">
            <span className="font-mono text-slate-300">{data.count} عملية</span>
            <span>التكرار:</span>
          </div>
        </div>
      );
    }
    return null;
  };

  return (
    <div className="rounded-2xl bg-gradient-to-br from-[#1e293b] via-[#172033] to-[#1e293b] border border-slate-700/80 p-4 sm:p-6 shadow-xl">
      {/* Header section with title, month badge, and filter toggle */}
      <div className="flex flex-col sm:flex-row sm:items-center justify-between gap-3 mb-5 border-b border-slate-800/80 pb-4">
        <div>
          <div className="flex items-center gap-2">
            <span className="p-2 rounded-xl bg-rose-500/15 text-rose-400 border border-rose-500/20">
              <PieChartIcon className="w-5 h-5" />
            </span>
            <div>
              <h2 className="text-base sm:text-lg font-black text-white tracking-wide">
                توزيع المصروفات حسب التصنيفات
              </h2>
              <div className="flex items-center gap-2 mt-0.5">
                <span className="flex items-center gap-1 text-xs text-rose-400 font-semibold bg-rose-950/40 border border-rose-800/50 px-2 py-0.5 rounded-full">
                  <Calendar className="w-3 h-3" />
                  <span>{currentMonthLabel}</span>
                </span>
                <span className="text-xs text-slate-400">
                  ({transactionCount} عملية مصروف مسجلة)
                </span>
              </div>
            </div>
          </div>
        </div>

        {/* Action & Filter buttons */}
        <div className="flex flex-wrap items-center gap-2 self-start sm:self-center">
          {onOpenManageCategories && (
            <button
              onClick={onOpenManageCategories}
              className="flex items-center gap-1.5 px-3 py-1.5 rounded-xl bg-purple-500/10 hover:bg-purple-500/20 text-purple-300 border border-purple-500/30 text-xs font-bold transition shadow-sm"
              title="إضافة وتعديل تصنيفات المصروفات المخصصة"
            >
              <Tag className="w-3.5 h-3.5 text-purple-400" />
              <span>إدارة التصنيفات</span>
            </button>
          )}

          <div className="flex bg-slate-900/90 p-1 rounded-xl border border-slate-800 text-xs font-bold">
            <button
              onClick={() => setFilterMode('current_month')}
              className={`px-3 py-1.5 rounded-lg transition ${
                filterMode === 'current_month'
                  ? 'bg-rose-600 text-white shadow'
                  : 'text-slate-400 hover:text-slate-200'
              }`}
            >
              الشهر الحالي
            </button>
            <button
              onClick={() => setFilterMode('all')}
              className={`px-3 py-1.5 rounded-lg transition ${
                filterMode === 'all'
                  ? 'bg-rose-600 text-white shadow'
                  : 'text-slate-400 hover:text-slate-200'
              }`}
            >
              كافة المعاملات
            </button>
          </div>
        </div>
      </div>

      {chartData.length === 0 ? (
        /* Empty State */
        <div className="text-center py-10 px-4 bg-slate-900/40 rounded-xl border border-dashed border-slate-800">
          <div className="w-14 h-14 rounded-full bg-slate-800/80 text-slate-400 mx-auto flex items-center justify-center mb-3">
            <TrendingDown className="w-7 h-7 text-slate-500" />
          </div>
          <h3 className="text-base font-bold text-white mb-1">لا توجد مصروفات مسجلة لهذا الشهر</h3>
          <p className="text-xs text-slate-400 max-w-sm mx-auto mb-4">
            لم يتم تسجيل أي عمليات سحب كاش أو مصروفات خلال شهر {currentMonthLabel}.
          </p>
          {onOpenWithdraw && (
            <button
              onClick={onOpenWithdraw}
              className="inline-flex items-center gap-2 px-4 py-2 rounded-xl bg-rose-600 hover:bg-rose-500 text-white text-xs font-bold transition shadow-lg shadow-rose-950/60"
            >
              <ArrowUpRight className="w-4 h-4" />
              <span>تسجيل سحب كاش / مصروف جديد</span>
            </button>
          )}
        </div>
      ) : (
        /* Chart & Breakdown Grid */
        <div className="grid grid-cols-1 lg:grid-cols-12 gap-6 items-center">
          {/* Pie Chart Display (Left on desktop, Top on mobile) */}
          <div className="lg:col-span-6 flex flex-col items-center justify-center">
            <div className="w-full h-64 sm:h-72 relative">
              <ResponsiveContainer width="100%" height="100%">
                <PieChart>
                  <Pie
                    data={chartData}
                    cx="50%"
                    cy="50%"
                    innerRadius={55}
                    outerRadius={95}
                    paddingAngle={3}
                    dataKey="value"
                    animationDuration={800}
                    onMouseEnter={(_, index) => setActiveIndex(index)}
                    onMouseLeave={() => setActiveIndex(null)}
                  >
                    {chartData.map((entry, index) => (
                      <Cell
                        key={`cell-${index}`}
                        fill={entry.color}
                        stroke="#1e293b"
                        strokeWidth={2}
                        className="transition-all duration-300 hover:opacity-85 cursor-pointer"
                        style={{
                          filter: activeIndex === index ? 'drop-shadow(0px 0px 8px rgba(255,255,255,0.4))' : 'none',
                        }}
                      />
                    ))}
                  </Pie>
                  <Tooltip content={<CustomTooltip />} />
                </PieChart>
              </ResponsiveContainer>

              {/* Center Donut Overlay with Total Sum */}
              <div className="absolute inset-0 flex flex-col items-center justify-center pointer-events-none">
                <span className="text-[11px] text-slate-400 font-semibold">إجمالي المصروفات</span>
                <span className="text-base sm:text-lg font-black text-white font-mono tracking-tight">
                  {totalMonthlyExpenses.toLocaleString()}
                </span>
                <span className="text-[10px] text-rose-400 font-bold">ج.م</span>
              </div>
            </div>

            {/* Quick Helper Text */}
            <p className="text-[11px] text-slate-400 text-center mt-1">
              مرر المؤشر أو اضغط على أجزاء الدائرة لرؤية تفاصيل التصنيف
            </p>
          </div>

          {/* Categories Breakdown List (Right on desktop, Below on mobile) */}
          <div className="lg:col-span-6 space-y-2.5">
            <div className="flex items-center justify-between text-xs text-slate-400 font-semibold px-2 mb-1">
              <span>التصنيف والنسبة</span>
              <span>المبلغ الإجمالي</span>
            </div>

            <div className="max-h-64 sm:max-h-72 overflow-y-auto space-y-2 pr-1 custom-scrollbar">
              {chartData.map((item, index) => {
                const isHovered = activeIndex === index;
                return (
                  <div
                    key={item.name}
                    onMouseEnter={() => setActiveIndex(index)}
                    onMouseLeave={() => setActiveIndex(null)}
                    className={`p-2.5 rounded-xl border transition-all cursor-pointer ${
                      isHovered
                        ? 'bg-slate-800/90 border-slate-600 shadow-md scale-[1.01]'
                        : 'bg-slate-900/60 border-slate-800/80 hover:bg-slate-800/50'
                    }`}
                  >
                    <div className="flex items-center justify-between">
                      <div className="flex items-center gap-2">
                        <span
                          className="w-3.5 h-3.5 rounded-full shrink-0 shadow-sm"
                          style={{ backgroundColor: item.color }}
                        />
                        <span className="text-xs sm:text-sm font-bold text-white">
                          {item.name}
                        </span>
                      </div>

                      <div className="text-left">
                        <span className="text-xs sm:text-sm font-mono font-bold text-rose-300">
                          {item.value.toLocaleString()} <span className="text-[10px] text-slate-400">ج.م</span>
                        </span>
                      </div>
                    </div>

                    {/* Progress Bar & Percentage details */}
                    <div className="mt-2 flex items-center gap-2">
                      <div className="flex-1 h-1.5 bg-slate-800 rounded-full overflow-hidden">
                        <div
                          className="h-full rounded-full transition-all duration-500"
                          style={{
                            width: `${item.percent}%`,
                            backgroundColor: item.color,
                          }}
                        />
                      </div>
                      <span className="text-[11px] font-mono font-bold text-slate-300 shrink-0">
                        {item.percent}%
                      </span>
                      <span className="text-[10px] text-slate-500 shrink-0">
                        ({item.count} عملية)
                      </span>
                    </div>
                  </div>
                );
              })}
            </div>
          </div>
        </div>
      )}
    </div>
  );
};
