import React, { useState } from 'react';
import {
  X,
  Bell,
  BellRing,
  Plus,
  Calendar,
  CheckCircle2,
  Clock,
  AlertTriangle,
  AlertCircle,
  Trash2,
  Send,
  ArrowUpRight,
  Sparkles,
  ShieldAlert,
  Wallet as WalletIcon,
  Filter,
} from 'lucide-react';
import { useFinancial } from '../context/FinancialContext';
import { RecurringBill } from '../types';

interface BillRemindersModalProps {
  isOpen: boolean;
  onClose: () => void;
  onPayBill?: (bill: RecurringBill) => void;
  onRequestPushPermission?: () => Promise<void>;
  pushPermissionStatus?: NotificationPermission;
}

const CATEGORIES = [
  'فواتير وخدمات',
  'إيجار',
  'إنترنت واتصالات',
  'أقساط والتزامات',
  'رواتب وعمالة',
  'صيانة ونظافة',
  'أخرى',
];

const REMINDER_DAYS_OPTIONS = [
  { value: 0, label: 'في نفس يوم الاستحقاق' },
  { value: 1, label: 'قبل الاستحقاق بيوم واحد' },
  { value: 2, label: 'قبل الاستحقاق بيومين' },
  { value: 3, label: 'قبل الاستحقاق بـ 3 أيام' },
  { value: 5, label: 'قبل الاستحقاق بـ 5 أيام' },
  { value: 7, label: 'قبل الاستحقاق بأسبوع' },
];

export const BillRemindersModal: React.FC<BillRemindersModalProps> = ({
  isOpen,
  onClose,
  onPayBill,
  onRequestPushPermission,
  pushPermissionStatus = 'default',
}) => {
  const {
    bills,
    wallets,
    addBill,
    updateBill,
    deleteBill,
    markBillAsPaid,
    markBillAsUnpaid,
    triggerTestBillReminder,
  } = useFinancial();

  const [activeTab, setActiveTab] = useState<'list' | 'add'>('list');
  const [filterType, setFilterType] = useState<'all' | 'due' | 'paid'>('all');

  // Form State for Adding New Bill
  const [title, setTitle] = useState('');
  const [amount, setAmount] = useState('');
  const [category, setCategory] = useState(CATEGORIES[0]);
  const [dueDay, setDueDay] = useState('15');
  const [reminderDaysBefore, setReminderDaysBefore] = useState(2);
  const [reminderTime, setReminderTime] = useState('09:00');
  const [selectedWalletId, setSelectedWalletId] = useState<string>(wallets[0]?.id || '');
  const [notes, setNotes] = useState('');
  const [autoNotification, setAutoNotification] = useState(true);

  if (!isOpen) return null;

  const today = new Date();
  const currentDay = today.getDate();
  const currentMonthKey = `${today.getFullYear()}-${String(today.getMonth() + 1).padStart(2, '0')}`;

  const totalMonthlyAmount = bills.reduce((acc, b) => acc + (b.isActive ? b.amount : 0), 0);
  const paidThisMonthCount = bills.filter((b) => b.lastPaidMonth === currentMonthKey).length;
  const paidThisMonthAmount = bills
    .filter((b) => b.lastPaidMonth === currentMonthKey)
    .reduce((acc, b) => acc + b.amount, 0);

  const handleCreateBill = (e: React.FormEvent) => {
    e.preventDefault();
    if (!title.trim() || !amount) return;

    const parsedAmount = parseFloat(amount);
    const parsedDueDay = parseInt(dueDay, 10);
    const wallet = wallets.find((w) => w.id === selectedWalletId);

    addBill({
      title: title.trim(),
      amount: parsedAmount,
      category,
      dueDay: parsedDueDay,
      reminderDaysBefore,
      reminderTime,
      walletId: selectedWalletId || undefined,
      walletName: wallet ? wallet.name : undefined,
      notes: notes.trim() || undefined,
      isActive: true,
      autoNotification,
      lastPaidMonth: '',
    });

    // Reset Form
    setTitle('');
    setAmount('');
    setNotes('');
    setActiveTab('list');
  };

  const getBillStatus = (bill: RecurringBill) => {
    const isPaid = bill.lastPaidMonth === currentMonthKey;
    if (isPaid) {
      return {
        label: 'تم السداد لهذا الشهر',
        badgeClass: 'bg-emerald-500/20 text-emerald-400 border-emerald-500/30',
        icon: <CheckCircle2 className="w-3.5 h-3.5" />,
        isPaid: true,
        daysRemaining: null,
      };
    }

    const daysRemaining = bill.dueDay - currentDay;

    if (daysRemaining === 0) {
      return {
        label: 'مستحقة اليوم!',
        badgeClass: 'bg-rose-500/25 text-rose-300 border-rose-500/40 animate-pulse',
        icon: <AlertCircle className="w-3.5 h-3.5" />,
        isPaid: false,
        daysRemaining: 0,
      };
    }

    if (daysRemaining < 0) {
      return {
        label: `متأخرة منذ ${Math.abs(daysRemaining)} يوم`,
        badgeClass: 'bg-amber-500/25 text-amber-300 border-amber-500/40',
        icon: <AlertTriangle className="w-3.5 h-3.5" />,
        isPaid: false,
        daysRemaining,
      };
    }

    if (daysRemaining <= bill.reminderDaysBefore) {
      return {
        label: `مستحقة خلال ${daysRemaining} يوم`,
        badgeClass: 'bg-sky-500/20 text-sky-300 border-sky-500/30',
        icon: <Clock className="w-3.5 h-3.5" />,
        isPaid: false,
        daysRemaining,
      };
    }

    return {
      label: `تستحق بعد ${daysRemaining} يوم`,
      badgeClass: 'bg-slate-700/50 text-slate-300 border-slate-600',
      icon: <Calendar className="w-3.5 h-3.5" />,
      isPaid: false,
      daysRemaining,
    };
  };

  const filteredBills = bills.filter((b) => {
    const isPaid = b.lastPaidMonth === currentMonthKey;
    if (filterType === 'paid') return isPaid;
    if (filterType === 'due') return !isPaid;
    return true;
  });

  return (
    <div className="fixed inset-0 z-50 flex items-center justify-center p-3 sm:p-4 bg-black/80 backdrop-blur-sm animate-fade-in">
      <div className="relative w-full max-w-2xl rounded-2xl bg-[#1e293b] border border-slate-700 p-4 sm:p-6 shadow-2xl text-white max-h-[92vh] flex flex-col">
        {/* Close Button */}
        <button
          onClick={onClose}
          className="absolute left-4 top-4 p-2 text-slate-400 hover:text-white rounded-full bg-slate-800 hover:bg-slate-700 transition"
          aria-label="إغلاق"
        >
          <X className="w-5 h-5" />
        </button>

        {/* Modal Header */}
        <div className="flex items-center gap-3 pb-3 border-b border-slate-800">
          <div className="p-2.5 rounded-xl bg-gradient-to-tr from-amber-500/20 to-emerald-500/20 text-amber-400 border border-amber-500/30">
            <BellRing className="w-6 h-6 animate-pulse" />
          </div>
          <div>
            <div className="flex items-center gap-2">
              <h2 className="text-base sm:text-lg font-bold">تنبيهات الفواتير الشهرية الثابتة</h2>
              <span className="text-[10px] font-bold bg-emerald-500/20 text-emerald-300 px-2 py-0.5 rounded-full border border-emerald-500/30">
                إشعارات تلقائية
              </span>
            </div>
            <p className="text-xs text-slate-400">
              تذكير دوري بمواعيد استحقاق الإيجارات، الكهرباء، الإنترنت والأقساط
            </p>
          </div>
        </div>

        {/* Push Notification Permission Bar */}
        {pushPermissionStatus !== 'granted' && onRequestPushPermission && (
          <div className="mt-3 p-3 bg-gradient-to-r from-amber-950/40 to-slate-900 rounded-xl border border-amber-600/30 flex items-center justify-between gap-3">
            <div className="flex items-center gap-2">
              <ShieldAlert className="w-4 h-4 text-amber-400 shrink-0" />
              <p className="text-xs text-amber-200">
                لتلقي التنبيهات على شاشة هاتفك مباشرة عند موعد كل فاتورة، يرجى تفعيل إشعارات الجهاز.
              </p>
            </div>
            <button
              onClick={onRequestPushPermission}
              className="px-3 py-1.5 rounded-lg bg-amber-600 hover:bg-amber-500 text-white text-xs font-bold transition whitespace-nowrap shadow"
            >
              تفعيل التنبيهات
            </button>
          </div>
        )}

        {/* Summary Stats Cards */}
        <div className="grid grid-cols-2 sm:grid-cols-4 gap-2.5 my-3">
          <div className="p-2.5 rounded-xl bg-slate-900/90 border border-slate-800">
            <span className="text-[10px] text-slate-400 block">إجمالي الالتزامات</span>
            <span className="text-xs sm:text-sm font-bold text-white">
              {totalMonthlyAmount.toLocaleString()} <span className="text-[10px]">ج.م</span>
            </span>
          </div>
          <div className="p-2.5 rounded-xl bg-slate-900/90 border border-slate-800">
            <span className="text-[10px] text-slate-400 block">الفواتير المسجلة</span>
            <span className="text-xs sm:text-sm font-bold text-amber-400">{bills.length} فاتورة</span>
          </div>
          <div className="p-2.5 rounded-xl bg-slate-900/90 border border-slate-800">
            <span className="text-[10px] text-slate-400 block">تم سداده هذا الشهر</span>
            <span className="text-xs sm:text-sm font-bold text-emerald-400">
              {paidThisMonthAmount.toLocaleString()} <span className="text-[10px]">ج.م</span>
            </span>
          </div>
          <div className="p-2.5 rounded-xl bg-slate-900/90 border border-slate-800">
            <span className="text-[10px] text-slate-400 block">متبقي للسداد</span>
            <span className="text-xs sm:text-sm font-bold text-rose-400">
              {Math.max(0, totalMonthlyAmount - paidThisMonthAmount).toLocaleString()}{' '}
              <span className="text-[10px]">ج.م</span>
            </span>
          </div>
        </div>

        {/* Tab Controls: List vs Add */}
        <div className="flex items-center justify-between gap-2 border-b border-slate-800 pb-2 mb-3">
          <div className="flex gap-2">
            <button
              onClick={() => setActiveTab('list')}
              className={`px-3 py-1.5 rounded-lg text-xs font-bold transition ${
                activeTab === 'list'
                  ? 'bg-emerald-600 text-white'
                  : 'bg-slate-800 text-slate-300 hover:bg-slate-700'
              }`}
            >
              قائمة الفواتير والتنبيهات ({bills.length})
            </button>
            <button
              onClick={() => setActiveTab('add')}
              className={`flex items-center gap-1.5 px-3 py-1.5 rounded-lg text-xs font-bold transition ${
                activeTab === 'add'
                  ? 'bg-emerald-600 text-white'
                  : 'bg-slate-800 text-slate-300 hover:bg-slate-700'
              }`}
            >
              <Plus className="w-3.5 h-3.5" />
              <span>إضافة فاتورة دورية</span>
            </button>
          </div>

          {activeTab === 'list' && (
            <div className="flex items-center gap-1 bg-slate-900 p-0.5 rounded-lg border border-slate-800 text-[11px]">
              <button
                onClick={() => setFilterType('all')}
                className={`px-2 py-0.5 rounded ${
                  filterType === 'all' ? 'bg-slate-700 text-white font-bold' : 'text-slate-400'
                }`}
              >
                الكل
              </button>
              <button
                onClick={() => setFilterType('due')}
                className={`px-2 py-0.5 rounded ${
                  filterType === 'due' ? 'bg-amber-600/80 text-white font-bold' : 'text-slate-400'
                }`}
              >
                مستحقة ({bills.length - paidThisMonthCount})
              </button>
              <button
                onClick={() => setFilterType('paid')}
                className={`px-2 py-0.5 rounded ${
                  filterType === 'paid' ? 'bg-emerald-600/80 text-white font-bold' : 'text-slate-400'
                }`}
              >
                مدفوعة ({paidThisMonthCount})
              </button>
            </div>
          )}
        </div>

        {/* Tab Content: List View */}
        {activeTab === 'list' && (
          <div className="flex-1 overflow-y-auto space-y-3 pr-1">
            {filteredBills.length === 0 ? (
              <div className="py-12 text-center text-slate-400">
                <Bell className="w-10 h-10 mx-auto text-slate-600 mb-2 opacity-50" />
                <p className="text-sm font-semibold">لا توجد فواتير دورية ضمن هذا التصنيف.</p>
                <button
                  onClick={() => setActiveTab('add')}
                  className="mt-3 inline-flex items-center gap-1.5 px-3 py-1.5 rounded-lg bg-emerald-600 hover:bg-emerald-500 text-white text-xs font-bold transition"
                >
                  <Plus className="w-3.5 h-3.5" />
                  <span>إضافة أول فاتورة الآن</span>
                </button>
              </div>
            ) : (
              filteredBills.map((bill) => {
                const status = getBillStatus(bill);
                const isPaid = status.isPaid;

                return (
                  <div
                    key={bill.id}
                    className={`rounded-xl border p-3 sm:p-4 transition ${
                      isPaid
                        ? 'bg-slate-900/50 border-slate-800 opacity-80'
                        : 'bg-slate-900/90 border-slate-700 hover:border-slate-600 shadow-sm'
                    }`}
                  >
                    <div className="flex flex-col sm:flex-row sm:items-center justify-between gap-2.5">
                      {/* Left: Info */}
                      <div>
                        <div className="flex items-center gap-2 mb-1 flex-wrap">
                          <h3 className="text-sm font-bold text-white">{bill.title}</h3>
                          <span
                            className={`flex items-center gap-1 text-[10px] font-bold px-2 py-0.5 rounded-full border ${status.badgeClass}`}
                          >
                            {status.icon}
                            <span>{status.label}</span>
                          </span>
                          <span className="text-[10px] text-slate-400 bg-slate-800 px-2 py-0.5 rounded">
                            {bill.category}
                          </span>
                        </div>

                        <div className="flex items-center gap-3 text-xs text-slate-300 flex-wrap">
                          <span className="font-bold text-emerald-400 font-mono">
                            {bill.amount.toLocaleString()} ج.م
                          </span>
                          <span className="text-slate-400 flex items-center gap-1">
                            <Calendar className="w-3 h-3 text-slate-400" />
                            يوم {bill.dueDay} من كل شهر
                          </span>
                          <span className="text-slate-400 flex items-center gap-1">
                            <Bell className="w-3 h-3 text-amber-400" />
                            تنبيه قبل {bill.reminderDaysBefore === 0 ? 'نفس اليوم' : `${bill.reminderDaysBefore} أيام`}
                          </span>
                          {bill.walletName && (
                            <span className="text-slate-400 flex items-center gap-1">
                              <WalletIcon className="w-3 h-3 text-sky-400" />
                              {bill.walletName}
                            </span>
                          )}
                        </div>

                        {bill.notes && (
                          <p className="text-[11px] text-slate-400 mt-1 italic">{bill.notes}</p>
                        )}
                      </div>

                      {/* Right: Actions */}
                      <div className="flex items-center gap-2 self-end sm:self-center flex-wrap">
                        {/* Test Notification Button */}
                        <button
                          type="button"
                          onClick={() => triggerTestBillReminder(bill.id)}
                          className="p-1.5 rounded-lg bg-slate-800 hover:bg-slate-700 text-amber-400 text-xs transition"
                          title="تجربة إرسال التنبيه الآن لهاتفك"
                        >
                          <Send className="w-3.5 h-3.5" />
                        </button>

                        {/* Pay Now Button (if onPayBill provided) */}
                        {!isPaid && onPayBill && (
                          <button
                            type="button"
                            onClick={() => {
                              onPayBill(bill);
                              onClose();
                            }}
                            className="flex items-center gap-1 px-2.5 py-1.5 rounded-lg bg-emerald-600 hover:bg-emerald-500 text-white text-xs font-bold transition shadow"
                          >
                            <ArrowUpRight className="w-3.5 h-3.5" />
                            <span>سداد فوري</span>
                          </button>
                        )}

                        {/* Mark as paid / unpaid toggle */}
                        {isPaid ? (
                          <button
                            type="button"
                            onClick={() => markBillAsUnpaid(bill.id)}
                            className="text-xs px-2.5 py-1.5 rounded-lg bg-slate-800 hover:bg-slate-700 text-slate-300 transition"
                          >
                            إلغاء السداد
                          </button>
                        ) : (
                          <button
                            type="button"
                            onClick={() => markBillAsPaid(bill.id)}
                            className="flex items-center gap-1 text-xs px-2.5 py-1.5 rounded-lg bg-slate-800 hover:bg-slate-700 text-emerald-400 font-semibold border border-emerald-500/30 transition"
                          >
                            <CheckCircle2 className="w-3.5 h-3.5" />
                            <span>تم السداد</span>
                          </button>
                        )}

                        {/* Active toggle */}
                        <button
                          type="button"
                          onClick={() => updateBill({ ...bill, isActive: !bill.isActive })}
                          className={`p-1.5 rounded-lg transition ${
                            bill.isActive
                              ? 'bg-emerald-500/20 text-emerald-400 border border-emerald-500/30'
                              : 'bg-slate-800 text-slate-500'
                          }`}
                          title={bill.isActive ? 'التنبيه مفعل (انقر للتعطيل)' : 'التنبيه معطل (انقر للتفعيل)'}
                        >
                          <Bell className="w-3.5 h-3.5" />
                        </button>

                        {/* Delete */}
                        <button
                          type="button"
                          onClick={() => deleteBill(bill.id)}
                          className="p-1.5 rounded-lg bg-slate-800 hover:bg-rose-900/40 text-slate-400 hover:text-rose-400 transition"
                          title="حذف الفاتورة والتنبيه"
                        >
                          <Trash2 className="w-3.5 h-3.5" />
                        </button>
                      </div>
                    </div>
                  </div>
                );
              })
            )}
          </div>
        )}

        {/* Tab Content: Add View */}
        {activeTab === 'add' && (
          <form onSubmit={handleCreateBill} className="flex-1 overflow-y-auto space-y-3.5 text-xs sm:text-sm pr-1">
            <div className="grid grid-cols-1 sm:grid-cols-2 gap-3">
              <div>
                <label className="block text-slate-300 font-semibold mb-1">اسم الفاتورة أو الالتزام *</label>
                <input
                  type="text"
                  required
                  placeholder="مثال: فاتورة كهرباء المحل، إيجار المعرض..."
                  value={title}
                  onChange={(e) => setTitle(e.target.value)}
                  className="w-full bg-slate-900 border border-slate-700 rounded-xl px-3 py-2.5 text-white focus:outline-none focus:border-emerald-500 text-sm font-semibold"
                />
              </div>

              <div>
                <label className="block text-slate-300 font-semibold mb-1">المبلغ المطلوب (ج.م) *</label>
                <div className="relative">
                  <input
                    type="number"
                    min="1"
                    step="any"
                    required
                    placeholder="مثال: 1500"
                    value={amount}
                    onChange={(e) => setAmount(e.target.value)}
                    className="w-full bg-slate-900 border border-slate-700 rounded-xl px-3 py-2.5 text-white focus:outline-none focus:border-emerald-500 text-sm font-bold pl-12"
                  />
                  <span className="absolute left-3 top-1/2 -translate-y-1/2 text-xs text-slate-400 font-bold">
                    ج.م
                  </span>
                </div>
              </div>
            </div>

            <div className="grid grid-cols-1 sm:grid-cols-3 gap-3">
              <div>
                <label className="block text-slate-300 font-semibold mb-1">تصنيف الفاتورة</label>
                <select
                  value={category}
                  onChange={(e) => setCategory(e.target.value)}
                  className="w-full bg-slate-900 border border-slate-700 rounded-xl px-3 py-2.5 text-white focus:outline-none focus:border-emerald-500 text-xs sm:text-sm font-semibold"
                >
                  {CATEGORIES.map((cat) => (
                    <option key={cat} value={cat}>
                      {cat}
                    </option>
                  ))}
                </select>
              </div>

              <div>
                <label className="block text-slate-300 font-semibold mb-1">يوم الاستحقاق الشهري (1 - 31) *</label>
                <input
                  type="number"
                  min="1"
                  max="31"
                  required
                  value={dueDay}
                  onChange={(e) => setDueDay(e.target.value)}
                  className="w-full bg-slate-900 border border-slate-700 rounded-xl px-3 py-2.5 text-white focus:outline-none focus:border-emerald-500 text-xs sm:text-sm font-semibold"
                />
              </div>

              <div>
                <label className="block text-slate-300 font-semibold mb-1">موعد إرسال التنبيه</label>
                <select
                  value={reminderDaysBefore}
                  onChange={(e) => setReminderDaysBefore(parseInt(e.target.value, 10))}
                  className="w-full bg-slate-900 border border-slate-700 rounded-xl px-3 py-2.5 text-white focus:outline-none focus:border-emerald-500 text-xs sm:text-sm font-semibold"
                >
                  {REMINDER_DAYS_OPTIONS.map((opt) => (
                    <option key={opt.value} value={opt.value}>
                      {opt.label}
                    </option>
                  ))}
                </select>
              </div>
            </div>

            <div className="grid grid-cols-1 sm:grid-cols-2 gap-3">
              <div>
                <label className="block text-slate-300 font-semibold mb-1">المحفظة المقترحة للدفع</label>
                <select
                  value={selectedWalletId}
                  onChange={(e) => setSelectedWalletId(e.target.value)}
                  className="w-full bg-slate-900 border border-slate-700 rounded-xl px-3 py-2.5 text-white focus:outline-none focus:border-emerald-500 text-xs sm:text-sm font-semibold"
                >
                  <option value="">بدون محفظة محددة</option>
                  {wallets.map((w) => (
                    <option key={w.id} value={w.id}>
                      {w.name} ({w.balance.toLocaleString()} ج.م)
                    </option>
                  ))}
                </select>
              </div>

              <div>
                <label className="block text-slate-300 font-semibold mb-1">وقت التنبيه اليومي</label>
                <input
                  type="time"
                  value={reminderTime}
                  onChange={(e) => setReminderTime(e.target.value)}
                  className="w-full bg-slate-900 border border-slate-700 rounded-xl px-3 py-2.5 text-white focus:outline-none focus:border-emerald-500 text-xs sm:text-sm font-semibold"
                />
              </div>
            </div>

            <div>
              <label className="block text-slate-300 font-semibold mb-1">ملاحظات أو رقم الاشتراك (اختياري)</label>
              <textarea
                rows={2}
                placeholder="مثال: رقم السداد الإلكتروني، كود فودافون كاش *9*، اسم المالك..."
                value={notes}
                onChange={(e) => setNotes(e.target.value)}
                className="w-full bg-slate-900 border border-slate-700 rounded-xl px-3 py-2 text-white focus:outline-none focus:border-emerald-500 text-xs resize-none"
              />
            </div>

            <div className="p-3 bg-slate-900/80 rounded-xl border border-slate-800 flex items-center justify-between">
              <div>
                <span className="text-xs font-bold text-white block">إرسال إشعار للنظام وللهاتف</span>
                <span className="text-[11px] text-slate-400">
                  إرسال Push Notification وتنبيه في مركز الإشعارات عند اقتراب الموعد
                </span>
              </div>
              <input
                type="checkbox"
                checked={autoNotification}
                onChange={(e) => setAutoNotification(e.target.checked)}
                className="w-4 h-4 accent-emerald-500 rounded cursor-pointer"
              />
            </div>

            <div className="pt-3 border-t border-slate-700/80 flex items-center justify-end gap-2.5">
              <button
                type="button"
                onClick={() => setActiveTab('list')}
                className="px-4 py-2.5 rounded-xl bg-slate-800 hover:bg-slate-700 text-slate-300 font-bold transition text-xs sm:text-sm"
              >
                إلغاء
              </button>
              <button
                type="submit"
                className="flex items-center gap-2 px-5 py-2.5 rounded-xl bg-gradient-to-r from-emerald-600 to-teal-600 hover:from-emerald-500 hover:to-teal-500 text-white font-bold transition text-xs sm:text-sm shadow-lg shadow-emerald-950/60"
              >
                <Plus className="w-4 h-4" />
                <span>حفظ وجدولة التنبيه الشهري</span>
              </button>
            </div>
          </form>
        )}
      </div>
    </div>
  );
};
