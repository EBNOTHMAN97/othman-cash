import React from 'react';
import { X, CheckCheck, Trash2, Bell, AlertTriangle, AlertCircle, CheckCircle2, Info } from 'lucide-react';
import { useFinancial } from '../context/FinancialContext';
import { SystemNotification } from '../types';

interface NotificationCenterProps {
  isOpen: boolean;
  onClose: () => void;
  onRequestPushPermission: () => Promise<void>;
  pushPermissionStatus: NotificationPermission;
  onOpenBillReminders?: () => void;
}

export const NotificationCenter: React.FC<NotificationCenterProps> = ({
  isOpen,
  onClose,
  onRequestPushPermission,
  pushPermissionStatus,
  onOpenBillReminders,
}) => {
  const {
    notifications,
    bills,
    markNotificationAsRead,
    markAllNotificationsAsRead,
    clearNotifications,
  } = useFinancial();

  if (!isOpen) return null;

  const today = new Date();
  const currentMonthKey = `${today.getFullYear()}-${String(today.getMonth() + 1).padStart(2, '0')}`;
  const dueBillsCount = bills.filter((b) => b.isActive && b.lastPaidMonth !== currentMonthKey).length;

  const getIcon = (type: SystemNotification['type']) => {
    switch (type) {
      case 'warning':
        return <AlertTriangle className="w-4 h-4 text-amber-400 shrink-0" />;
      case 'alert':
        return <AlertCircle className="w-4 h-4 text-rose-400 shrink-0" />;
      case 'success':
        return <CheckCircle2 className="w-4 h-4 text-emerald-400 shrink-0" />;
      case 'info':
      default:
        return <Info className="w-4 h-4 text-sky-400 shrink-0" />;
    }
  };

  return (
    <div className="fixed inset-0 z-50 flex items-center justify-end bg-black/60 backdrop-blur-sm animate-fade-in">
      <div className="relative w-full max-w-md h-full bg-[#1e293b] border-r border-slate-700/80 p-5 shadow-2xl flex flex-col text-white">
        {/* Header */}
        <div className="flex items-center justify-between pb-3 border-b border-slate-800">
          <div className="flex items-center gap-2">
            <Bell className="w-5 h-5 text-emerald-400" />
            <h2 className="text-base font-bold">مركز الإشعارات والتنبيهات</h2>
          </div>
          <button
            onClick={onClose}
            className="p-1.5 text-slate-400 hover:text-white rounded-lg bg-slate-800 transition"
          >
            <X className="w-4 h-4" />
          </button>
        </div>

        {/* Push Notification Permission Card */}
        <div className="my-2.5 p-3 bg-slate-900 rounded-xl border border-slate-800 flex items-center justify-between gap-2">
          <div>
            <h3 className="text-xs font-bold text-slate-200">إشعارات النظام (Push)</h3>
            <p className="text-[11px] text-slate-400">
              {pushPermissionStatus === 'granted'
                ? 'مفعلة — ستصلك تنبيهات الليمات فوراً'
                : 'تلقي تنبيهات عند اقتراب انتهاء الليمت'}
            </p>
          </div>
          {pushPermissionStatus !== 'granted' ? (
            <button
              onClick={onRequestPushPermission}
              className="px-2.5 py-1 rounded-lg bg-emerald-600 hover:bg-emerald-500 text-white text-xs font-bold transition whitespace-nowrap"
            >
              تفعيل
            </button>
          ) : (
            <span className="text-[11px] text-emerald-400 font-bold bg-emerald-950 px-2 py-0.5 rounded-full border border-emerald-500/30">
              مفعل
            </span>
          )}
        </div>

        {/* Fixed Monthly Bills Reminders Banner */}
        {onOpenBillReminders && (
          <div className="mb-3 p-3 bg-gradient-to-r from-amber-950/30 to-slate-900 rounded-xl border border-amber-600/30 flex items-center justify-between gap-2">
            <div>
              <div className="flex items-center gap-1.5">
                <span className="text-xs font-bold text-white">تنبيهات الفواتير الشهرية</span>
                {dueBillsCount > 0 && (
                  <span className="text-[10px] bg-amber-500/20 text-amber-300 px-1.5 py-0.2 rounded font-bold border border-amber-500/30">
                    {dueBillsCount} مستحقة
                  </span>
                )}
              </div>
              <p className="text-[11px] text-slate-400">
                جدول ومواعيد دفع الفواتير الثابتة
              </p>
            </div>
            <button
              onClick={onOpenBillReminders}
              className="px-2.5 py-1 rounded-lg bg-amber-600 hover:bg-amber-500 text-white text-xs font-bold transition whitespace-nowrap shadow"
            >
              إدارة التنبيهات
            </button>
          </div>
        )}

        {/* Batch Actions */}
        {notifications.length > 0 && (
          <div className="flex items-center justify-between text-xs text-slate-400 mb-2">
            <button
              onClick={markAllNotificationsAsRead}
              className="flex items-center gap-1 hover:text-emerald-400 transition"
            >
              <CheckCheck className="w-3.5 h-3.5" />
              <span>تحديد الكل كمقروء</span>
            </button>
            <button
              onClick={clearNotifications}
              className="flex items-center gap-1 hover:text-rose-400 transition"
            >
              <Trash2 className="w-3.5 h-3.5" />
              <span>مسح السجل</span>
            </button>
          </div>
        )}

        {/* List of Notifications */}
        <div className="flex-1 overflow-y-auto space-y-2.5 pr-1">
          {notifications.length === 0 ? (
            <div className="py-12 text-center text-slate-400 text-xs">
              لا توجد إشعارات جديدة حالياً.
            </div>
          ) : (
            notifications.map((notif) => (
              <div
                key={notif.id}
                onClick={() => markNotificationAsRead(notif.id)}
                className={`p-3 rounded-xl border transition cursor-pointer ${
                  notif.read
                    ? 'bg-slate-900/40 border-slate-800/60 opacity-75'
                    : 'bg-slate-900/90 border-slate-700 shadow-sm'
                }`}
              >
                <div className="flex items-start gap-2.5">
                  <div className="mt-0.5">{getIcon(notif.type)}</div>
                  <div className="flex-1">
                    <div className="flex items-center justify-between gap-1 mb-1">
                      <h4 className="text-xs font-bold text-white line-clamp-1">{notif.title}</h4>
                      <span className="text-[10px] text-slate-400 font-mono shrink-0">{notif.timestamp}</span>
                    </div>
                    <p className="text-[11px] text-slate-300 leading-relaxed">{notif.message}</p>
                  </div>
                </div>
              </div>
            ))
          )}
        </div>
      </div>
    </div>
  );
};
