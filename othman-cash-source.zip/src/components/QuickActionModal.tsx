import React, { useState } from 'react';
import {
  X,
  ArrowDownRight,
  ArrowUpRight,
  ArrowLeftRight,
  Send,
  AlertCircle,
  CheckCircle,
  WifiOff,
} from 'lucide-react';
import { Transaction } from '../types';
import { useFinancial, getLocalDateKey } from '../context/FinancialContext';
import { useOnlineStatus } from '../hooks/useOnlineStatus';

interface QuickActionModalProps {
  isOpen: boolean;
  onClose: () => void;
  initialType?: 'deposit' | 'withdraw' | 'transfer' | 'transfer_internal' | 'transfer_general';
  preselectedWalletId?: string;
  onTransactionSuccess?: (transaction: Transaction) => void;
}

export const QuickActionModal: React.FC<QuickActionModalProps> = ({
  isOpen,
  onClose,
  initialType = 'deposit',
  preselectedWalletId,
  onTransactionSuccess,
}) => {
  const {
    wallets,
    deposit,
    withdraw,
    transfer,
    transferGeneral,
    getWalletDailyLimitStats,
  } = useFinancial();
  const isOnline = useOnlineStatus();

  // Normalize initialType
  const initialActionType =
    initialType === 'transfer_general' || initialType === 'transfer_internal'
      ? 'transfer'
      : initialType;
  const initialTransferSubtype =
    initialType === 'transfer_general' ? 'general' : 'internal';

  const [actionType, setActionType] = useState<'deposit' | 'withdraw' | 'transfer'>(initialActionType);
  const [transferSubtype, setTransferSubtype] = useState<'internal' | 'general'>(initialTransferSubtype);

  const [selectedWalletId, setSelectedWalletId] = useState<string>(
    preselectedWalletId || (wallets[0]?.id ?? '')
  );
  const [targetWalletId, setTargetWalletId] = useState<string>(
    wallets.find((w) => w.id !== selectedWalletId)?.id || ''
  );
  const [amount, setAmount] = useState<string>('');
  const [fee, setFee] = useState<string>('0');
  const [recipientPhone, setRecipientPhone] = useState<string>('');
  const [recipientName, setRecipientName] = useState<string>('');
  const [notes, setNotes] = useState<string>('');

  const getLocalDateTime = () => {
    const now = new Date();
    const year = now.getFullYear();
    const month = String(now.getMonth() + 1).padStart(2, '0');
    const day = String(now.getDate()).padStart(2, '0');
    const hours = String(now.getHours()).padStart(2, '0');
    const minutes = String(now.getMinutes()).padStart(2, '0');
    return `${year}-${month}-${day}T${hours}:${minutes}`;
  };

  const [transactionDate, setTransactionDate] = useState<string>(getLocalDateTime());
  const [feedback, setFeedback] = useState<{ success: boolean; message: string } | null>(null);

  React.useEffect(() => {
    if (initialType === 'transfer_general') {
      setActionType('transfer');
      setTransferSubtype('general');
    } else if (initialType === 'transfer_internal') {
      setActionType('transfer');
      setTransferSubtype('internal');
    } else {
      setActionType(initialType);
      if (initialType === 'transfer') {
        setTransferSubtype('general');
      }
    }

    setTransactionDate(getLocalDateTime());
  }, [initialType, isOpen]);

  React.useEffect(() => {
    if (preselectedWalletId) {
      setSelectedWalletId(preselectedWalletId);
    } else if (!selectedWalletId && wallets.length > 0) {
      setSelectedWalletId(wallets[0].id);
    }
  }, [preselectedWalletId, wallets, isOpen]);

  // Keep target wallet valid if selected wallet changes
  React.useEffect(() => {
    if (targetWalletId === selectedWalletId) {
      const nextTarget = wallets.find((w) => w.id !== selectedWalletId);
      if (nextTarget) {
        setTargetWalletId(nextTarget.id);
      }
    }
  }, [selectedWalletId, wallets, targetWalletId]);

  if (!isOpen) return null;

  const currentWallet = wallets.find((w) => w.id === selectedWalletId);
  const numericAmount = parseFloat(amount) || 0;
  const numericFee = parseFloat(fee) || 0;

  const handleSubmit = (e: React.FormEvent) => {
    e.preventDefault();
    setFeedback(null);

    if (!isOnline) {
      setFeedback({
        success: false,
        message: 'لا يمكن إتمام المعاملة: الجهاز غير متصل بالإنترنت حالياً.',
      });
      return;
    }

    if (numericAmount <= 0) {
      setFeedback({ success: false, message: 'يرجى إدخال مبلغ صحيح أكبر من الصفر.' });
      return;
    }

    const customDateIso = transactionDate ? new Date(transactionDate).toISOString() : new Date().toISOString();

    const handleSuccessCompletion = (res: { success: boolean; message: string; transaction?: Transaction }) => {
      setAmount('');
      setRecipientPhone('');
      setRecipientName('');
      setNotes('');
      setFeedback(null);
      onClose(); // إغلاق نافذة العملية فور إتمامها
      if (res.transaction && onTransactionSuccess) {
        onTransactionSuccess(res.transaction);
      }
    };

    if (actionType === 'deposit') {
      const res = deposit(selectedWalletId, numericAmount, notes, numericFee, customDateIso);
      if (res.success) {
        handleSuccessCompletion(res);
      } else {
        setFeedback(res);
      }
    } else if (actionType === 'withdraw') {
      const res = withdraw(
        selectedWalletId,
        numericAmount,
        recipientPhone,
        recipientName,
        notes,
        numericFee,
        customDateIso
      );
      if (res.success) {
        handleSuccessCompletion(res);
      } else {
        setFeedback(res);
      }
    } else if (actionType === 'transfer') {
      if (transferSubtype === 'internal') {
        // التحويل بين المحافظ (داخلي)
        if (!targetWalletId) {
          setFeedback({ success: false, message: 'يرجى اختيار المحفظة المستلمة للتحويل الداخلي.' });
          return;
        }
        const res = transfer(selectedWalletId, targetWalletId, numericAmount, notes, numericFee, customDateIso, 'تحويل بين المحافظ');
        if (res.success) {
          handleSuccessCompletion(res);
        } else {
          setFeedback(res);
        }
      } else {
        // التحويل بشكل عام (خارجي)
        const res = transferGeneral(
          selectedWalletId,
          numericAmount,
          recipientPhone,
          recipientName,
          undefined,
          notes,
          numericFee,
          customDateIso
        );
        if (res.success) {
          handleSuccessCompletion(res);
        } else {
          setFeedback(res);
        }
      }
    }
  };

  return (
    <div className="fixed inset-0 z-50 flex items-center justify-center p-4 sm:p-6 bg-black/80 backdrop-blur-sm animate-fade-in">
      <div className="relative w-full max-w-lg rounded-3xl bg-[#1e293b] border border-slate-700/80 p-6 sm:p-8 pt-7 sm:pt-8 shadow-2xl text-white max-h-[90vh] overflow-y-auto">
        {/* Close Button: inwards and downwards with safe padding */}
        <button
          onClick={onClose}
          className="absolute left-5 top-5 sm:left-6 sm:top-6 p-2 text-slate-400 hover:text-white rounded-full bg-slate-800 hover:bg-slate-700 transition z-10 active:scale-95 shadow-sm"
          aria-label="إغلاق"
        >
          <X className="w-5 h-5" />
        </button>

        <h2 className="text-lg sm:text-xl font-bold mb-4 pl-12 flex items-center gap-2">
          <span>تنفيذ عملية مالية</span>
        </h2>

        {/* Offline Warning Notice */}
        {!isOnline && (
          <div className="mb-4 p-3 rounded-xl bg-red-950/60 border border-red-500/40 text-red-200 text-xs flex items-center gap-2">
            <WifiOff className="w-4 h-4 shrink-0 text-red-400" />
            <span>
              <strong>انقطاع الاتصال:</strong> العمليات المالية معطلة مؤقتاً حتى إعادة الاتصال بالخادم.
            </span>
          </div>
        )}

        {/* Main 3 Action Tabs: Deposit, Withdraw, Transfer */}
        <div className="grid grid-cols-3 gap-1.5 p-1 bg-slate-900 rounded-xl mb-4">
          <button
            type="button"
            onClick={() => {
              setActionType('deposit');
              setFeedback(null);
            }}
            className={`flex items-center justify-center gap-1.5 py-2.5 rounded-lg text-xs sm:text-sm font-bold transition ${
              actionType === 'deposit'
                ? 'bg-emerald-600 text-white shadow'
                : 'text-slate-400 hover:text-white'
            }`}
          >
            <ArrowDownRight className="w-4 h-4" />
            <span>إضافة أموال</span>
          </button>
          <button
            type="button"
            onClick={() => {
              setActionType('withdraw');
              setFeedback(null);
            }}
            className={`flex items-center justify-center gap-1.5 py-2.5 rounded-lg text-xs sm:text-sm font-bold transition ${
              actionType === 'withdraw'
                ? 'bg-rose-600 text-white shadow'
                : 'text-slate-400 hover:text-white'
            }`}
          >
            <ArrowUpRight className="w-4 h-4" />
            <span>سحب أموال</span>
          </button>
          <button
            type="button"
            onClick={() => {
              setActionType('transfer');
              setFeedback(null);
            }}
            className={`flex items-center justify-center gap-1.5 py-2.5 rounded-lg text-xs sm:text-sm font-bold transition ${
              actionType === 'transfer'
                ? 'bg-indigo-600 text-white shadow'
                : 'text-slate-400 hover:text-white'
            }`}
          >
            <ArrowLeftRight className="w-4 h-4" />
            <span>تحويل أموال</span>
          </button>
        </div>

        {/* SEPARATED TRANSFER SECTION (Requirement: الفصل بين التحويل بشكل عام والتحويل بين المحافظ) */}
        {actionType === 'transfer' && (
          <div className="p-2.5 bg-slate-900/95 border border-indigo-500/30 rounded-2xl mb-4 shadow-inner">
            <div className="flex items-center justify-between mb-2 px-1">
              <span className="text-xs font-bold text-slate-200 flex items-center gap-1.5">
                <ArrowLeftRight className="w-3.5 h-3.5 text-indigo-400" />
                اختر قسم التحويل المطلوب:
              </span>
              <span className="text-[10px] text-indigo-300 font-medium">حدد نوع العملية</span>
            </div>

            <div className="grid grid-cols-2 gap-2">
              <button
                type="button"
                onClick={() => {
                  setTransferSubtype('general');
                  setFeedback(null);
                }}
                className={`flex flex-col items-center justify-center py-2.5 px-2 rounded-xl text-xs font-bold transition border ${
                  transferSubtype === 'general'
                    ? 'bg-gradient-to-r from-blue-600 to-indigo-600 text-white border-blue-400 shadow-md shadow-blue-950/50'
                    : 'bg-slate-800/80 text-slate-400 hover:text-white border-slate-700/80'
                }`}
              >
                <div className="flex items-center gap-1.5">
                  <Send className="w-3.5 h-3.5" />
                  <span>التحويل بشكل عام</span>
                </div>
                <span className="text-[10px] opacity-80 mt-0.5 font-normal">
                  تحويل خارجي (لعميل أو رقم آخر)
                </span>
              </button>

              <button
                type="button"
                onClick={() => {
                  setTransferSubtype('internal');
                  setFeedback(null);
                }}
                className={`flex flex-col items-center justify-center py-2.5 px-2 rounded-xl text-xs font-bold transition border ${
                  transferSubtype === 'internal'
                    ? 'bg-gradient-to-r from-indigo-600 to-purple-600 text-white border-indigo-400 shadow-md shadow-indigo-950/50'
                    : 'bg-slate-800/80 text-slate-400 hover:text-white border-slate-700/80'
                }`}
              >
                <div className="flex items-center gap-1.5">
                  <ArrowLeftRight className="w-3.5 h-3.5" />
                  <span>التحويل بين المحافظ</span>
                </div>
                <span className="text-[10px] opacity-80 mt-0.5 font-normal">
                  تحويل داخلي بين محافظي
                </span>
              </button>
            </div>
          </div>
        )}

        {/* Feedback Banner */}
        {feedback && (
          <div
            className={`mb-4 p-3 rounded-xl border text-xs flex items-center gap-2 ${
              feedback.success
                ? 'bg-emerald-950/60 border-emerald-500/40 text-emerald-200'
                : 'bg-rose-950/60 border-rose-500/40 text-rose-200'
            }`}
          >
            {feedback.success ? (
              <CheckCircle className="w-4 h-4 shrink-0 text-emerald-400" />
            ) : (
              <AlertCircle className="w-4 h-4 shrink-0 text-rose-400" />
            )}
            <span>{feedback.message}</span>
          </div>
        )}

        <form onSubmit={handleSubmit} className="space-y-4 text-xs sm:text-sm">
          {/* Source Wallet Selection */}
          <div>
            <label className="block text-slate-300 font-semibold mb-1">
              {actionType === 'transfer' ? 'المحفظة المصدر (الخصم)' : 'المحفظة'}
            </label>
            <select
              value={selectedWalletId}
              onChange={(e) => setSelectedWalletId(e.target.value)}
              className="w-full bg-slate-900 border border-slate-700 rounded-xl px-3 py-2.5 text-white focus:outline-none focus:border-emerald-500"
            >
              {wallets.map((w) => (
                <option key={w.id} value={w.id}>
                  {w.name} — رصيد: {w.balance.toLocaleString()} ج.م
                </option>
              ))}
            </select>
          </div>

          {/* Current Wallet Limits Info (Dynamic based on transaction date) */}
          {currentWallet && (() => {
            const dateStats = getWalletDailyLimitStats(selectedWalletId, transactionDate);
            const isToday = getLocalDateKey(transactionDate) === getLocalDateKey();
            const dateLabel = isToday ? 'اليوم' : getLocalDateKey(transactionDate);

            return (
              <div className="p-3 bg-slate-900/60 rounded-xl border border-slate-800 flex flex-col sm:flex-row justify-between items-start sm:items-center gap-2 text-[11px] text-slate-400">
                <div>
                  <span>الرصيد المتاح: </span>
                  <strong className="text-emerald-400 font-bold">{currentWallet.balance.toLocaleString()} ج.م</strong>
                </div>
                <div className="flex items-center gap-1.5 flex-wrap">
                  <span>
                    متبقي ليمت تاريخ (<span className="text-indigo-300 font-bold font-mono">{dateLabel}</span>):
                  </span>
                  <strong className={`${dateStats.remaining <= 5000 ? 'text-rose-400' : 'text-amber-400'} font-bold font-mono`}>
                    {dateStats.remaining.toLocaleString()} ج.م
                  </strong>
                  <span className="text-slate-500 text-[10px]">
                    (مستهلك {dateStats.spent.toLocaleString()} من {dateStats.limit.toLocaleString()} ج.م)
                  </span>
                </div>
              </div>
            );
          })()}

          {/* CASE 1: Transfer Between Wallets (Internal) */}
          {actionType === 'transfer' && transferSubtype === 'internal' && (
            <div>
              <label className="block text-slate-300 font-semibold mb-1">المحفظة المستلمة (الإيداع)</label>
              <select
                value={targetWalletId}
                onChange={(e) => setTargetWalletId(e.target.value)}
                className="w-full bg-slate-900 border border-slate-700 rounded-xl px-3 py-2.5 text-white focus:outline-none focus:border-indigo-500"
              >
                {wallets
                  .filter((w) => w.id !== selectedWalletId)
                  .map((w) => (
                    <option key={w.id} value={w.id}>
                      {w.name} — رصيد: {w.balance.toLocaleString()} ج.م
                    </option>
                  ))}
              </select>
            </div>
          )}

          {/* CASE 2: General Transfer (External) OR Withdraw */}
          {((actionType === 'transfer' && transferSubtype === 'general') || actionType === 'withdraw') && (
            <>
              <div className="grid grid-cols-1 sm:grid-cols-2 gap-3">
                <div>
                  <label className="block text-slate-300 font-semibold mb-1">
                    {actionType === 'transfer' ? 'رقم هاتف / حساب المستلم' : 'رقم هاتف العميل (اختياري)'}
                  </label>
                  <input
                    type="tel"
                    placeholder="010XXXXXXXX أو عنوان إنستاباي"
                    value={recipientPhone}
                    onChange={(e) => setRecipientPhone(e.target.value)}
                    className="w-full bg-slate-900 border border-slate-700 rounded-xl px-3 py-2 text-white focus:outline-none focus:border-indigo-500"
                  />
                </div>
                <div>
                  <label className="block text-slate-300 font-semibold mb-1">
                    {actionType === 'transfer' ? 'اسم المستلم / الجهه (اختياري)' : 'اسم العميل (اختياري)'}
                  </label>
                  <input
                    type="text"
                    placeholder="محمد أحمد / شركة..."
                    value={recipientName}
                    onChange={(e) => setRecipientName(e.target.value)}
                    className="w-full bg-slate-900 border border-slate-700 rounded-xl px-3 py-2 text-white focus:outline-none focus:border-indigo-500"
                  />
                </div>
              </div>
            </>
          )}

          {/* Amount & Fee */}
          <div className="grid grid-cols-1 sm:grid-cols-2 gap-3">
            <div>
              <label className="block text-slate-300 font-semibold mb-1">المبلغ (ج.م) *</label>
              <input
                type="number"
                step="any"
                required
                placeholder="0.00"
                value={amount}
                onChange={(e) => setAmount(e.target.value)}
                className="w-full bg-slate-900 border border-slate-700 rounded-xl px-3 py-2.5 text-emerald-300 font-bold text-base focus:outline-none focus:border-emerald-500"
              />
            </div>
            <div>
              <label className="block text-slate-300 font-semibold mb-1">العمولة / المصاريف (ج.م)</label>
              <input
                type="number"
                step="any"
                placeholder="0"
                value={fee}
                onChange={(e) => setFee(e.target.value)}
                className="w-full bg-slate-900 border border-slate-700 rounded-xl px-3 py-2.5 text-white focus:outline-none focus:border-emerald-500"
              />
            </div>
          </div>

          {/* Quick preset amount chips */}
          <div className="flex gap-2 overflow-x-auto pb-1 no-scrollbar">
            {[500, 1000, 2500, 5000, 10000, 20000].map((preset) => (
              <button
                type="button"
                key={preset}
                onClick={() => setAmount(preset.toString())}
                className="px-2.5 py-1 rounded-lg bg-slate-800 hover:bg-slate-700 text-slate-300 text-xs font-semibold whitespace-nowrap border border-slate-700"
              >
                +{preset.toLocaleString()}
              </button>
            ))}
          </div>

          {/* Transaction Date (Default: Today, but editable) */}
          <div>
            <div className="flex items-center justify-between mb-1">
              <label className="text-slate-300 font-semibold text-xs sm:text-sm">تاريخ وتوقيت المعاملة</label>
              <span className="text-[11px] text-emerald-400 font-medium">
                {getLocalDateKey(transactionDate) === getLocalDateKey()
                  ? 'اليوم (تسجل في ليمت اليوم تلقائياً)'
                  : `تاريخ مخصص (${getLocalDateKey(transactionDate)}) - تسجل في ليمت هذا اليوم`}
              </span>
            </div>
            <div className="flex gap-2">
              <input
                type="datetime-local"
                value={transactionDate}
                onChange={(e) => setTransactionDate(e.target.value)}
                className="flex-1 bg-slate-900 border border-slate-700 rounded-xl px-3 py-2 text-white font-mono focus:outline-none focus:border-emerald-500 text-xs sm:text-sm"
              />
              <button
                type="button"
                onClick={() => setTransactionDate(getLocalDateTime())}
                className="px-3 py-2 rounded-xl bg-slate-800 hover:bg-slate-700 text-slate-300 text-xs font-semibold border border-slate-700 transition shrink-0"
              >
                الآن
              </button>
            </div>
          </div>

          {/* Notes */}
          <div>
            <label className="block text-slate-300 font-semibold mb-1">ملاحظات العملية</label>
            <input
              type="text"
              placeholder="وصف مختصر للعملية..."
              value={notes}
              onChange={(e) => setNotes(e.target.value)}
              className="w-full bg-slate-900 border border-slate-700 rounded-xl px-3 py-2 text-white focus:outline-none focus:border-emerald-500"
            />
          </div>

          {/* Submit Button */}
          <button
            type="submit"
            disabled={!isOnline}
            className={`w-full py-3 px-4 rounded-xl font-bold text-sm shadow-lg transition flex items-center justify-center gap-2 ${
              !isOnline
                ? 'bg-slate-700 text-slate-400 cursor-not-allowed'
                : actionType === 'deposit'
                ? 'bg-emerald-600 hover:bg-emerald-500 text-white shadow-emerald-900/40'
                : actionType === 'withdraw'
                ? 'bg-rose-600 hover:bg-rose-500 text-white shadow-rose-900/40'
                : transferSubtype === 'general'
                ? 'bg-gradient-to-r from-blue-600 to-indigo-600 hover:from-blue-500 hover:to-indigo-500 text-white shadow-indigo-900/40'
                : 'bg-gradient-to-r from-indigo-600 to-purple-600 hover:from-indigo-500 hover:to-purple-500 text-white shadow-purple-950/40'
            }`}
          >
            {!isOnline ? (
              <>
                <WifiOff className="w-4 h-4" />
                <span>غير متصل - العمليات المالية معطلة</span>
              </>
            ) : actionType === 'deposit' ? (
              <>
                <ArrowDownRight className="w-4 h-4" />
                <span>تأكيد الإيداع ({numericAmount > 0 ? numericAmount.toLocaleString() + ' ج.م' : ''})</span>
              </>
            ) : actionType === 'withdraw' ? (
              <>
                <ArrowUpRight className="w-4 h-4" />
                <span>تأكيد السحب ({numericAmount > 0 ? numericAmount.toLocaleString() + ' ج.م' : ''})</span>
              </>
            ) : transferSubtype === 'general' ? (
              <>
                <Send className="w-4 h-4" />
                <span>تأكيد التحويل بشكل عام ({numericAmount > 0 ? numericAmount.toLocaleString() + ' ج.م' : ''})</span>
              </>
            ) : (
              <>
                <ArrowLeftRight className="w-4 h-4" />
                <span>تأكيد التحويل بين المحافظ ({numericAmount > 0 ? numericAmount.toLocaleString() + ' ج.م' : ''})</span>
              </>
            )}
          </button>
        </form>
      </div>
    </div>
  );
};
