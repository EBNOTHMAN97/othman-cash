import React, { useState, useMemo } from 'react';
import { Search, X, Tag, FileText, CheckCircle2, RotateCcw } from 'lucide-react';
import { useFinancial } from '../context/FinancialContext';
import { Transaction } from '../types';
import { TransactionsTable } from './TransactionsTable';

interface HistoryTabContentProps {
  onEditTransaction?: (tx: Transaction) => void;
  onOpenManageCategories?: () => void;
}

export const HistoryTabContent: React.FC<HistoryTabContentProps> = ({
  onEditTransaction,
  onOpenManageCategories,
}) => {
  const { transactions, expenseCategories } = useFinancial();
  const [searchQuery, setSearchQuery] = useState<string>('');
  const [selectedCategory, setSelectedCategory] = useState<string>('');

  // Extract unique categories present in transactions + user custom categories
  const availableCategories = useMemo(() => {
    const set = new Set<string>();
    
    // Add user's custom & system categories first
    expenseCategories.forEach((c) => set.add(c.name.trim()));

    // Add any category found in existing transactions
    transactions.forEach((tx) => {
      if (tx.category && tx.category.trim()) {
        set.add(tx.category.trim());
      }
    });

    return Array.from(set);
  }, [transactions, expenseCategories]);

  // Combined search term (either free text or selected category)
  const effectiveQuery = selectedCategory || searchQuery;

  // Count matching transactions for instant feedback
  const matchingCount = useMemo(() => {
    if (!effectiveQuery.trim()) return transactions.length;
    const q = effectiveQuery.toLowerCase().trim();
    return transactions.filter((tx) => {
      const matchCategory = tx.category ? tx.category.toLowerCase().includes(q) : false;
      const matchNotes = tx.notes ? tx.notes.toLowerCase().includes(q) : false;
      const matchRecipient = tx.recipientName ? tx.recipientName.toLowerCase().includes(q) : false;
      const matchRef = tx.referenceNumber ? tx.referenceNumber.toLowerCase().includes(q) : false;
      const matchWallet = (tx.walletName ? tx.walletName.toLowerCase().includes(q) : false) ||
                          (tx.targetWalletName ? tx.targetWalletName.toLowerCase().includes(q) : false);
      const matchPhone = tx.recipientPhone ? tx.recipientPhone.includes(q) : false;
      return matchCategory || matchNotes || matchRecipient || matchRef || matchWallet || matchPhone;
    }).length;
  }, [transactions, effectiveQuery]);

  const handleClear = () => {
    setSearchQuery('');
    setSelectedCategory('');
  };

  const handleSelectCategory = (cat: string) => {
    if (selectedCategory === cat) {
      setSelectedCategory('');
    } else {
      setSelectedCategory(cat);
      setSearchQuery('');
    }
  };

  const handleInputChange = (e: React.ChangeEvent<HTMLInputElement>) => {
    setSearchQuery(e.target.value);
    if (selectedCategory) {
      setSelectedCategory('');
    }
  };

  return (
    <div className="space-y-4">
      {/* Search Input Card Above Transactions Table */}
      <div className="rounded-2xl bg-[#1e293b]/95 border border-slate-700/80 p-4 sm:p-5 shadow-xl transition-all">
        <div className="flex flex-col md:flex-row md:items-center justify-between gap-3 mb-3">
          <div>
            <div className="flex items-center gap-2">
              <div className="p-2 rounded-xl bg-emerald-500/10 border border-emerald-500/20 text-emerald-400">
                <Search className="w-5 h-5" />
              </div>
              <div>
                <h2 className="text-base sm:text-lg font-bold text-white tracking-wide">
                  البحث في سجل العمليات
                </h2>
                <p className="text-xs text-slate-400">
                  تصفية فورية بالوصف أو اسم التصنيف لعرض المعاملات المطلوبة بدقة
                </p>
              </div>
            </div>
          </div>

          {/* Quick Result Counter */}
          <div className="flex items-center gap-2 self-start md:self-auto">
            <span className="text-xs font-semibold px-3 py-1.5 rounded-xl bg-slate-900 border border-slate-700/80 text-slate-300">
              {effectiveQuery.trim() ? (
                <>
                  مطابقة <strong className="text-emerald-400 font-mono mx-1">{matchingCount}</strong> من{' '}
                  <span className="font-mono">{transactions.length}</span>
                </>
              ) : (
                <>
                  إجمالي العمليات: <strong className="text-emerald-400 font-mono">{transactions.length}</strong>
                </>
              )}
            </span>

            {effectiveQuery.trim() && (
              <button
                onClick={handleClear}
                className="flex items-center gap-1 text-xs text-rose-400 hover:text-rose-300 px-2.5 py-1.5 rounded-xl bg-rose-500/10 border border-rose-500/20 transition hover:bg-rose-500/20"
                title="إعادة ضبط البحث"
              >
                <RotateCcw className="w-3.5 h-3.5" />
                <span>إعادة ضبط</span>
              </button>
            )}
          </div>
        </div>

        {/* The Main Search Input Field */}
        <div className="relative">
          <div className="absolute inset-y-0 right-0 pr-3.5 flex items-center pointer-events-none text-slate-400">
            <Search className="w-5 h-5 text-emerald-400" />
          </div>
          <input
            type="text"
            id="history-transactions-search-input"
            value={searchQuery || selectedCategory}
            onChange={handleInputChange}
            placeholder="ابحث بالوصف أو اسم التصنيف (مثال: سحب كاش، فواتير، مشتريات، توريد، شحن)..."
            className="w-full bg-slate-900/90 border border-slate-700 hover:border-slate-600 focus:border-emerald-500 focus:ring-2 focus:ring-emerald-500/20 rounded-xl pr-11 pl-10 py-3 text-sm text-white placeholder-slate-400 transition outline-none shadow-inner"
          />
          {(searchQuery || selectedCategory) && (
            <button
              onClick={handleClear}
              className="absolute inset-y-0 left-0 pl-3 flex items-center text-slate-400 hover:text-white transition"
              title="مسح حقل البحث"
            >
              <div className="p-1 rounded-full bg-slate-800 hover:bg-slate-700 text-slate-300">
                <X className="w-3.5 h-3.5" />
              </div>
            </button>
          )}
        </div>

        {/* Quick Category Chips / Pills */}
        <div className="mt-3 pt-3 border-t border-slate-800/80">
          <div className="flex flex-wrap items-center justify-between gap-2 text-xs text-slate-400 mb-2">
            <div className="flex items-center gap-2">
              <Tag className="w-3.5 h-3.5 text-emerald-400" />
              <span className="font-semibold">تصنيفات المصروفات والعمليات:</span>
              {selectedCategory && (
                <span className="text-emerald-400 bg-emerald-500/10 px-2 py-0.5 rounded-md text-[11px] font-medium border border-emerald-500/20">
                  محدد: {selectedCategory}
                </span>
              )}
            </div>

            {onOpenManageCategories && (
              <button
                type="button"
                onClick={onOpenManageCategories}
                className="inline-flex items-center gap-1 text-[11px] font-bold text-purple-400 hover:text-purple-300 px-2.5 py-1 rounded-lg bg-purple-500/10 border border-purple-500/30 transition hover:bg-purple-500/20"
              >
                <span>+ إنشاء / إدارة التصنيفات</span>
              </button>
            )}
          </div>
          <div className="flex flex-wrap gap-1.5 max-h-24 overflow-y-auto no-scrollbar">
            <button
              onClick={handleClear}
              className={`px-3 py-1 rounded-lg text-xs font-semibold transition ${
                !effectiveQuery.trim()
                  ? 'bg-emerald-600 text-white shadow-sm'
                  : 'bg-slate-900 text-slate-400 hover:text-slate-200 border border-slate-800'
              }`}
            >
              جميع التصنيفات
            </button>
            {availableCategories.map((cat) => {
              const isSelected = selectedCategory === cat || searchQuery.toLowerCase().trim() === cat.toLowerCase().trim();
              return (
                <button
                  key={cat}
                  onClick={() => handleSelectCategory(cat)}
                  className={`inline-flex items-center gap-1 px-3 py-1 rounded-lg text-xs font-medium transition ${
                    isSelected
                      ? 'bg-emerald-600 text-white border border-emerald-500 shadow-sm'
                      : 'bg-slate-900/90 text-slate-300 hover:text-emerald-300 hover:border-slate-700 border border-slate-800/90'
                  }`}
                >
                  <span>{cat}</span>
                  {isSelected && <CheckCircle2 className="w-3 h-3 text-white" />}
                </button>
              );
            })}
          </div>
        </div>
      </div>

      {/* Transactions Table (Filtered by Search Query) */}
      <TransactionsTable
        onEditTransaction={onEditTransaction}
        searchQuery={effectiveQuery}
        onSearchQueryChange={(newVal) => {
          setSelectedCategory('');
          setSearchQuery(newVal);
        }}
        hideInternalSearch={true}
        title="سجل العمليات والتحويلات"
        subtitle={
          effectiveQuery.trim()
            ? `نتائج البحث عن "${effectiveQuery}" (${matchingCount} عملية)`
            : 'سجل محاسبي لحظي لجميع حركات الإيداع والسحب والتحويل'
        }
      />
    </div>
  );
};
