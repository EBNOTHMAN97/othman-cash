import React, { useState, useMemo } from 'react';
import { Search, X, RotateCcw } from 'lucide-react';
import { useFinancial } from '../context/FinancialContext';
import { Transaction } from '../types';
import { TransactionsTable } from './TransactionsTable';

interface HistoryTabContentProps {
  onEditTransaction?: (tx: Transaction) => void;
}

export const HistoryTabContent: React.FC<HistoryTabContentProps> = ({
  onEditTransaction,
}) => {
  const { transactions } = useFinancial();
  const [searchQuery, setSearchQuery] = useState<string>('');

  const effectiveQuery = searchQuery.trim();

  // Count matching transactions for instant feedback
  const matchingCount = useMemo(() => {
    if (!effectiveQuery) return transactions.length;
    const q = effectiveQuery.toLowerCase();
    return transactions.filter((tx) => {
      const matchNotes = tx.notes ? tx.notes.toLowerCase().includes(q) : false;
      const matchRecipient = tx.recipientName ? tx.recipientName.toLowerCase().includes(q) : false;
      const matchRef = tx.referenceNumber ? tx.referenceNumber.toLowerCase().includes(q) : false;
      const matchWallet = (tx.walletName ? tx.walletName.toLowerCase().includes(q) : false) ||
                          (tx.targetWalletName ? tx.targetWalletName.toLowerCase().includes(q) : false);
      const matchPhone = tx.recipientPhone ? tx.recipientPhone.includes(q) : false;
      return matchNotes || matchRecipient || matchRef || matchWallet || matchPhone;
    }).length;
  }, [transactions, effectiveQuery]);

  const handleClear = () => {
    setSearchQuery('');
  };

  return (
    <div className="space-y-4">
      {/* Search Input Card Above Transactions Table */}
      <div className="rounded-2xl bg-[#1e293b]/95 border border-slate-700/80 p-4 sm:p-5 shadow-xl transition-all">
        <div className="flex flex-col md:flex-row md:items-center justify-between gap-3 mb-3">
          <div>
            <div className="flex items-center gap-2">
              <div className="p-2 rounded-xl bg-emerald-500/10 border border-emerald-500/20 text-emerald-400">
                <Search className="w-5 h-5" />
              </div>
              <div>
                <h2 className="text-base sm:text-lg font-bold text-white tracking-wide">
                  البحث في سجل العمليات
                </h2>
                <p className="text-xs text-slate-400">
                  تصفية فورية بالوصف، اسم المحفظة، رقم الهاتف، أو رقم المرجع
                </p>
              </div>
            </div>
          </div>

          {/* Quick Result Counter */}
          <div className="flex items-center gap-2 self-start md:self-auto">
            <span className="text-xs font-semibold px-3 py-1.5 rounded-xl bg-slate-900 border border-slate-700/80 text-slate-300">
              {effectiveQuery ? (
                <>
                  مطابقة <strong className="text-emerald-400 font-mono mx-1">{matchingCount}</strong> من{' '}
                  <span className="font-mono">{transactions.length}</span>
                </>
              ) : (
                <>
                  إجمالي العمليات: <strong className="text-emerald-400 font-mono">{transactions.length}</strong>
                </>
              )}
            </span>

            {effectiveQuery && (
              <button
                onClick={handleClear}
                className="flex items-center gap-1 text-xs text-rose-400 hover:text-rose-300 px-2.5 py-1.5 rounded-xl bg-rose-500/10 border border-rose-500/20 transition hover:bg-rose-500/20"
                title="إعادة ضبط البحث"
              >
                <RotateCcw className="w-3.5 h-3.5" />
                <span>إعادة ضبط</span>
              </button>
            )}
          </div>
        </div>

        {/* The Main Search Input Field */}
        <div className="relative">
          <div className="absolute inset-y-0 right-0 pr-3.5 flex items-center pointer-events-none text-slate-400">
            <Search className="w-5 h-5 text-emerald-400" />
          </div>
          <input
            type="text"
            id="history-transactions-search-input"
            value={searchQuery}
            onChange={(e) => setSearchQuery(e.target.value)}
            placeholder="ابحث بالوصف أو اسم المحفظة أو رقم الهاتف أو رقم المرجع..."
            className="w-full bg-slate-900/90 border border-slate-700 hover:border-slate-600 focus:border-emerald-500 focus:ring-2 focus:ring-emerald-500/20 rounded-xl pr-11 pl-10 py-3 text-sm text-white placeholder-slate-400 transition outline-none shadow-inner"
          />
          {searchQuery && (
            <button
              onClick={handleClear}
              className="absolute inset-y-0 left-0 pl-3 flex items-center text-slate-400 hover:text-white transition"
              title="مسح حقل البحث"
            >
              <div className="p-1 rounded-full bg-slate-800 hover:bg-slate-700 text-slate-300">
                <X className="w-3.5 h-3.5" />
              </div>
            </button>
          )}
        </div>
      </div>

      {/* Transactions Table (Filtered by Search Query) */}
      <TransactionsTable
        onEditTransaction={onEditTransaction}
        searchQuery={effectiveQuery}
        onSearchQueryChange={(newVal) => setSearchQuery(newVal)}
        hideInternalSearch={true}
        title="سجل العمليات والتحويلات"
        subtitle={
          effectiveQuery
            ? `نتائج البحث عن "${effectiveQuery}" (${matchingCount} عملية)`
            : 'سجل محاسبي لحظي لجميع حركات الإيداع والسحب والتحويل'
        }
      />
    </div>
  );
};
