import React from 'react';
import { TrendingUp, PieChart, ArrowDownRight, ArrowUpRight, DollarSign, Wallet as WalletIcon } from 'lucide-react';
import { useFinancial } from '../context/FinancialContext';

export const AnalyticsCharts: React.FC = () => {
  const { wallets, transactions, totalBalance, totalDailySpent, totalMonthlySpent } = useFinancial();

  const totalDeposits = transactions
    .filter((t) => t.type === 'deposit')
    .reduce((sum, t) => sum + t.amount, 0);

  const totalWithdrawals = transactions
    .filter((t) => t.type === 'withdraw')
    .reduce((sum, t) => sum + t.amount, 0);

  const totalFees = transactions.reduce((sum, t) => sum + t.fee, 0);

  const netCashflow = totalDeposits - totalWithdrawals;

  return (
    <div className="space-y-4">
      {/* 4 Stat Metric Cards (Mobile Grid) */}
      <div className="grid grid-cols-2 lg:grid-cols-4 gap-2.5 sm:gap-4">
        {/* Metric 1: Total Balance */}
        <div className="rounded-2xl bg-gradient-to-br from-emerald-950/60 to-slate-900 border border-emerald-500/30 p-3.5 sm:p-4 shadow">
          <div className="flex items-center justify-between mb-1.5">
            <span className="text-[11px] sm:text-xs text-slate-300 font-semibold">إجمالي السيولة</span>
            <div className="p-1.5 rounded-lg bg-emerald-500/20 text-emerald-400">
              <WalletIcon className="w-4 h-4" />
            </div>
          </div>
          <div className="flex items-baseline gap-1">
            <span className="text-lg sm:text-2xl font-black text-white font-mono">
              {totalBalance.toLocaleString()}
            </span>
            <span className="text-[10px] sm:text-xs text-emerald-400 font-bold">ج.م</span>
          </div>
          <span className="text-[10px] text-slate-400 mt-1 block">عبر {wallets.length} محافظ نشطة</span>
        </div>

        {/* Metric 2: Today's Spent / Limits */}
        <div className="rounded-2xl bg-slate-900/80 border border-slate-800 p-3.5 sm:p-4 shadow">
          <div className="flex items-center justify-between mb-1.5">
            <span className="text-[11px] sm:text-xs text-slate-300 font-semibold">مصروف الليمت اليوم</span>
            <div className="p-1.5 rounded-lg bg-amber-500/20 text-amber-400">
              <TrendingUp className="w-4 h-4" />
            </div>
          </div>
          <div className="flex items-baseline gap-1">
            <span className="text-lg sm:text-2xl font-black text-amber-300 font-mono">
              {totalDailySpent.toLocaleString()}
            </span>
            <span className="text-[10px] sm:text-xs text-amber-400 font-bold">ج.م</span>
          </div>
          <span className="text-[10px] text-slate-400 mt-1 block">تحديث لحظي لليمات اليوم</span>
        </div>

        {/* Metric 3: Total Deposits */}
        <div className="rounded-2xl bg-slate-900/80 border border-slate-800 p-3.5 sm:p-4 shadow">
          <div className="flex items-center justify-between mb-1.5">
            <span className="text-[11px] sm:text-xs text-slate-300 font-semibold">إجمالي الإيداعات</span>
            <div className="p-1.5 rounded-lg bg-emerald-500/20 text-emerald-400">
              <ArrowDownRight className="w-4 h-4" />
            </div>
          </div>
          <div className="flex items-baseline gap-1">
            <span className="text-lg sm:text-2xl font-black text-emerald-300 font-mono">
              {totalDeposits.toLocaleString()}
            </span>
            <span className="text-[10px] sm:text-xs text-emerald-400 font-bold">ج.م</span>
          </div>
          <span className="text-[10px] text-slate-400 mt-1 block">مدفوعات مستلمة</span>
        </div>

        {/* Metric 4: Total Withdrawals */}
        <div className="rounded-2xl bg-slate-900/80 border border-slate-800 p-3.5 sm:p-4 shadow">
          <div className="flex items-center justify-between mb-1.5">
            <span className="text-[11px] sm:text-xs text-slate-300 font-semibold">إجمالي السحوبات</span>
            <div className="p-1.5 rounded-lg bg-rose-500/20 text-rose-400">
              <ArrowUpRight className="w-4 h-4" />
            </div>
          </div>
          <div className="flex items-baseline gap-1">
            <span className="text-lg sm:text-2xl font-black text-rose-300 font-mono">
              {totalWithdrawals.toLocaleString()}
            </span>
            <span className="text-[10px] sm:text-xs text-rose-400 font-bold">ج.م</span>
          </div>
          <span className="text-[10px] text-slate-400 mt-1 block">تحويلات كاش منصرفة</span>
        </div>
      </div>

      {/* Visual Distribution Bars */}
      <div className="grid grid-cols-1 lg:grid-cols-2 gap-3 sm:gap-4">
        {/* Wallet Balance Distribution */}
        <div className="rounded-2xl bg-[#1e293b]/90 border border-slate-700/80 p-4 shadow">
          <h3 className="text-xs sm:text-sm font-bold text-white mb-3 flex items-center gap-1.5">
            <PieChart className="w-4 h-4 text-emerald-400" />
            <span>توزيع السيولة النقدية بين المحافظ</span>
          </h3>

          <div className="space-y-2.5">
            {wallets.map((w) => {
              const share = totalBalance > 0 ? Math.round((w.balance / totalBalance) * 100) : 0;
              return (
                <div key={w.id}>
                  <div className="flex justify-between items-center text-xs mb-1">
                    <span className="text-slate-300 line-clamp-1">{w.name}</span>
                    <span className="font-mono text-slate-400">
                      {w.balance.toLocaleString()} ج.م ({share}%)
                    </span>
                  </div>
                  <div className="w-full bg-slate-800 h-2 rounded-full overflow-hidden">
                    <div
                      className="h-full rounded-full transition-all duration-300"
                      style={{
                        width: `${share}%`,
                        backgroundColor: w.color || '#10b981',
                      }}
                    />
                  </div>
                </div>
              );
            })}
          </div>
        </div>

        {/* Cashflow Ratio Card */}
        <div className="rounded-2xl bg-[#1e293b]/90 border border-slate-700/80 p-4 shadow flex flex-col justify-between">
          <div>
            <h3 className="text-xs sm:text-sm font-bold text-white mb-3 flex items-center gap-1.5">
              <TrendingUp className="w-4 h-4 text-teal-400" />
              <span>معدل السيولة وصافي التدفق النقدي</span>
            </h3>

            <div className="bg-slate-900/70 rounded-xl p-3 border border-slate-800 mb-3 flex justify-between items-center">
              <div>
                <span className="text-[11px] text-slate-400 block">صافي الحركة اليومية (إيداع - سحب)</span>
                <span
                  className={`text-lg font-black font-mono ${
                    netCashflow >= 0 ? 'text-emerald-400' : 'text-rose-400'
                  }`}
                >
                  {netCashflow >= 0 ? `+${netCashflow.toLocaleString()}` : netCashflow.toLocaleString()} ج.م
                </span>
              </div>
              <div className="text-left">
                <span className="text-[11px] text-slate-400 block">إجمالي العمولات المحصلة</span>
                <span className="text-sm font-bold text-amber-300 font-mono">
                  {totalFees.toLocaleString()} ج.م
                </span>
              </div>
            </div>

            {/* In vs Out Progress */}
            <div className="space-y-2">
              <div className="flex justify-between text-xs text-slate-400">
                <span>نسبة الإيداعات والسحوبات</span>
                <span>
                  {totalDeposits + totalWithdrawals > 0
                    ? `${Math.round((totalDeposits / (totalDeposits + totalWithdrawals)) * 100)}% إيداع`
                    : '100%'}
                </span>
              </div>
              <div className="w-full bg-rose-500/80 h-3 rounded-full overflow-hidden flex">
                <div
                  className="bg-emerald-500 h-full transition-all duration-500"
                  style={{
                    width: `${
                      totalDeposits + totalWithdrawals > 0
                        ? (totalDeposits / (totalDeposits + totalWithdrawals)) * 100
                        : 50
                    }%`,
                  }}
                  title="إيداعات"
                />
              </div>
              <div className="flex justify-between text-[11px]">
                <span className="text-emerald-400 font-medium">● إيداعات: {totalDeposits.toLocaleString()} ج.م</span>
                <span className="text-rose-400 font-medium">● سحوبات: {totalWithdrawals.toLocaleString()} ج.م</span>
              </div>
            </div>
          </div>

          <div className="mt-3 pt-3 border-t border-slate-800 text-[11px] text-slate-400 text-center">
            تتم معالجة وإعادة احتساب الأرصدة والعمولات بدقة محاسبية فورية.
          </div>
        </div>
      </div>
    </div>
  );
};
