import React, { useState, useEffect } from 'react';
import { X, Save, Trash2, AlertCircle } from 'lucide-react';
import { Transaction } from '../types';

interface EditTransactionModalProps {
  isOpen: boolean;
  transaction: Transaction | null;
  onClose: () => void;
  onSave: (updatedTx: Transaction) => void;
  onDelete: (transactionId: string) => void;
}

export const EditTransactionModal: React.FC<EditTransactionModalProps> = ({
  isOpen,
  transaction,
  onClose,
  onSave,
  onDelete,
}) => {
  const [amount, setAmount] = useState('');
  const [fee, setFee] = useState('');
  const [referenceNumber, setReferenceNumber] = useState('');
  const [recipientPhone, setRecipientPhone] = useState('');
  const [recipientName, setRecipientName] = useState('');
  const [notes, setNotes] = useState('');
  const [category, setCategory] = useState('');
  const [confirmDelete, setConfirmDelete] = useState(false);

  useEffect(() => {
    if (transaction) {
      setAmount(transaction.amount.toString());
      setFee(transaction.fee.toString());
      setReferenceNumber(transaction.referenceNumber);
      setRecipientPhone(transaction.recipientPhone || '');
      setRecipientName(transaction.recipientName || '');
      setNotes(transaction.notes || '');
      setCategory(transaction.category || '');
      setConfirmDelete(false);
    }
  }, [transaction]);

  if (!isOpen || !transaction) return null;

  const handleSubmit = (e: React.FormEvent) => {
    e.preventDefault();
    const numAmount = parseFloat(amount);
    if (!numAmount || numAmount <= 0) return;

    onSave({
      ...transaction,
      amount: numAmount,
      fee: parseFloat(fee) || 0,
      referenceNumber: referenceNumber.trim() || transaction.referenceNumber,
      recipientPhone: recipientPhone.trim() || undefined,
      recipientName: recipientName.trim() || undefined,
      notes: notes.trim() || undefined,
      category: category.trim() || transaction.category,
    });
    onClose();
  };

  const handleDelete = () => {
    if (confirmDelete) {
      onDelete(transaction.id);
      onClose();
    } else {
      setConfirmDelete(true);
    }
  };

  const getTypeLabel = (type: Transaction['type']) => {
    switch (type) {
      case 'deposit': return 'إيداع نقدي';
      case 'withdraw': return 'سحب كاش';
      case 'transfer': return 'تحويل بين المحافظ';
    }
  };

  return (
    <div className="fixed inset-0 z-50 flex items-center justify-center p-3 sm:p-4 bg-black/80 backdrop-blur-sm animate-fade-in">
      <div className="relative w-full max-w-lg rounded-2xl bg-[#1e293b] border border-slate-700 p-5 sm:p-6 shadow-2xl text-white max-h-[90vh] overflow-y-auto">
        <button
          onClick={onClose}
          className="absolute left-4 top-4 p-2 text-slate-400 hover:text-white rounded-full bg-slate-800 hover:bg-slate-700 transition"
        >
          <X className="w-5 h-5" />
        </button>

        <div className="mb-4">
          <h2 className="text-lg sm:text-xl font-bold flex items-center gap-2">
            <span>تعديل المعاملة المالية</span>
          </h2>
          <p className="text-xs text-slate-400 mt-1">
            نوع العملية: <strong className="text-emerald-400">{getTypeLabel(transaction.type)}</strong> • المحفظة: {transaction.walletName}
          </p>
        </div>

        <form onSubmit={handleSubmit} className="space-y-4 text-xs sm:text-sm">
          <div className="grid grid-cols-1 sm:grid-cols-2 gap-3">
            <div>
              <label className="block text-slate-300 font-semibold mb-1">المبلغ (ج.م) *</label>
              <input
                type="number"
                step="any"
                required
                value={amount}
                onChange={(e) => setAmount(e.target.value)}
                className="w-full bg-slate-900 border border-slate-700 rounded-xl px-3 py-2.5 text-emerald-300 font-bold font-mono focus:outline-none focus:border-emerald-500 text-base"
              />
            </div>
            <div>
              <label className="block text-slate-300 font-semibold mb-1">العمولة (ج.م)</label>
              <input
                type="number"
                step="any"
                value={fee}
                onChange={(e) => setFee(e.target.value)}
                className="w-full bg-slate-900 border border-slate-700 rounded-xl px-3 py-2.5 text-white font-mono focus:outline-none focus:border-emerald-500 text-sm"
              />
            </div>
          </div>

          <div className="grid grid-cols-1 sm:grid-cols-2 gap-3">
            <div>
              <label className="block text-slate-300 font-semibold mb-1">رقم المرجع / الإيصال</label>
              <input
                type="text"
                value={referenceNumber}
                onChange={(e) => setReferenceNumber(e.target.value)}
                className="w-full bg-slate-900 border border-slate-700 rounded-xl px-3 py-2 text-white font-mono focus:outline-none focus:border-emerald-500 text-sm"
              />
            </div>
            <div>
              <label className="block text-slate-300 font-semibold mb-1">تصنيف العملية</label>
              <input
                type="text"
                value={category}
                onChange={(e) => setCategory(e.target.value)}
                className="w-full bg-slate-900 border border-slate-700 rounded-xl px-3 py-2 text-white focus:outline-none focus:border-emerald-500 text-sm"
              />
            </div>
          </div>

          <div className="grid grid-cols-1 sm:grid-cols-2 gap-3">
            <div>
              <label className="block text-slate-300 font-semibold mb-1">هاتف العميل / المستلم</label>
              <input
                type="tel"
                value={recipientPhone}
                onChange={(e) => setRecipientPhone(e.target.value)}
                placeholder="010XXXXXXXX"
                className="w-full bg-slate-900 border border-slate-700 rounded-xl px-3 py-2 text-white font-mono focus:outline-none focus:border-emerald-500 text-sm"
              />
            </div>
            <div>
              <label className="block text-slate-300 font-semibold mb-1">اسم العميل</label>
              <input
                type="text"
                value={recipientName}
                onChange={(e) => setRecipientName(e.target.value)}
                placeholder="اسم العميل..."
                className="w-full bg-slate-900 border border-slate-700 rounded-xl px-3 py-2 text-white focus:outline-none focus:border-emerald-500 text-sm"
              />
            </div>
          </div>

          <div>
            <label className="block text-slate-300 font-semibold mb-1">ملاحظات العملية</label>
            <input
              type="text"
              value={notes}
              onChange={(e) => setNotes(e.target.value)}
              placeholder="وصف إضافي..."
              className="w-full bg-slate-900 border border-slate-700 rounded-xl px-3 py-2 text-white focus:outline-none focus:border-emerald-500 text-sm"
            />
          </div>

          <div className="pt-4 border-t border-slate-800 flex flex-col sm:flex-row items-center justify-between gap-3">
            <button
              type="button"
              onClick={handleDelete}
              className={`w-full sm:w-auto px-4 py-2.5 rounded-xl font-bold text-xs flex items-center justify-center gap-1.5 transition ${
                confirmDelete
                  ? 'bg-rose-700 text-white animate-pulse'
                  : 'bg-rose-950/60 text-rose-300 border border-rose-600/40 hover:bg-rose-900/60'
              }`}
            >
              <Trash2 className="w-4 h-4" />
              <span>{confirmDelete ? 'تأكيد حذف المعاملة وإلغاء أثرها!' : 'حذف المعاملة'}</span>
            </button>

            <div className="flex items-center gap-2 w-full sm:w-auto">
              <button
                type="button"
                onClick={onClose}
                className="flex-1 sm:flex-none px-4 py-2.5 rounded-xl bg-slate-800 hover:bg-slate-700 text-slate-300 font-semibold text-xs sm:text-sm transition"
              >
                إلغاء
              </button>
              <button
                type="submit"
                className="flex-1 sm:flex-none px-5 py-2.5 rounded-xl bg-emerald-600 hover:bg-emerald-500 text-white font-bold text-xs sm:text-sm shadow-md transition flex items-center justify-center gap-1.5"
              >
                <Save className="w-4 h-4" />
                <span>حفظ التعديل</span>
              </button>
            </div>
          </div>
        </form>
      </div>
    </div>
  );
};
