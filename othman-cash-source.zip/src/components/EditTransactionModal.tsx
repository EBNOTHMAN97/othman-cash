import React, { useState, useEffect, useMemo } from 'react';
import { 
  X, 
  Save, 
  Trash2, 
  Calendar, 
  Clock, 
  Wallet as WalletIcon, 
  ArrowLeftRight, 
  Check, 
  RotateCcw,
  AlertCircle
} from 'lucide-react';
import { Transaction } from '../types';
import { useFinancial } from '../context/FinancialContext';

interface EditTransactionModalProps {
  isOpen: boolean;
  transaction: Transaction | null;
  onClose: () => void;
  onSave: (updatedTx: Transaction) => void;
  onDelete: (transactionId: string) => void;
}

// Convert ISO string to datetime-local input string (YYYY-MM-DDTHH:mm)
function toDatetimeLocalString(dateStr: string): string {
  try {
    const d = new Date(dateStr);
    if (isNaN(d.getTime())) {
      const now = new Date();
      return formatLocalDate(now);
    }
    return formatLocalDate(d);
  } catch {
    return '';
  }
}

function formatLocalDate(d: Date): string {
  const pad = (n: number) => String(n).padStart(2, '0');
  const year = d.getFullYear();
  const month = pad(d.getMonth() + 1);
  const day = pad(d.getDate());
  const hours = pad(d.getHours());
  const minutes = pad(d.getMinutes());
  return `${year}-${month}-${day}T${hours}:${minutes}`;
}

// Format date into human-readable Arabic
function formatArabicDateTime(dateStr: string): string {
  try {
    const d = new Date(dateStr);
    if (isNaN(d.getTime())) return 'تاريخ غير صالح';
    return d.toLocaleDateString('ar-EG', {
      weekday: 'long',
      year: 'numeric',
      month: 'long',
      day: 'numeric',
      hour: '2-digit',
      minute: '2-digit',
    });
  } catch {
    return dateStr;
  }
}

export const EditTransactionModal: React.FC<EditTransactionModalProps> = ({
  isOpen,
  transaction,
  onClose,
  onSave,
  onDelete,
}) => {
  const { wallets } = useFinancial();

  // Form states
  const [dateInput, setDateInput] = useState('');
  const [amount, setAmount] = useState('');
  const [fee, setFee] = useState('');
  const [selectedWalletId, setSelectedWalletId] = useState('');
  const [selectedTargetWalletId, setSelectedTargetWalletId] = useState('');
  const [referenceNumber, setReferenceNumber] = useState('');
  const [recipientPhone, setRecipientPhone] = useState('');
  const [recipientName, setRecipientName] = useState('');
  const [notes, setNotes] = useState('');
  const [status, setStatus] = useState<Transaction['status']>('completed');
  const [confirmDelete, setConfirmDelete] = useState(false);

  // Initialize form when transaction changes
  useEffect(() => {
    if (transaction) {
      setDateInput(toDatetimeLocalString(transaction.date));
      setAmount(transaction.amount.toString());
      setFee(transaction.fee.toString());
      setSelectedWalletId(transaction.walletId);
      setSelectedTargetWalletId(transaction.targetWalletId || '');
      setReferenceNumber(transaction.referenceNumber);
      setRecipientPhone(transaction.recipientPhone || '');
      setRecipientName(transaction.recipientName || '');
      setNotes(transaction.notes || '');
      setStatus(transaction.status || 'completed');
      setConfirmDelete(false);
    }
  }, [transaction]);

  if (!isOpen || !transaction) return null;

  // Quick date presets handlers
  const handleSetNow = () => {
    setDateInput(formatLocalDate(new Date()));
  };

  const handleSetYesterday = () => {
    const d = new Date();
    d.setDate(d.getDate() - 1);
    setDateInput(formatLocalDate(d));
  };

  const handleResetDate = () => {
    if (transaction) {
      setDateInput(toDatetimeLocalString(transaction.date));
    }
  };

  const handleSubmit = (e: React.FormEvent) => {
    e.preventDefault();
    const numAmount = parseFloat(amount);
    if (!numAmount || numAmount <= 0) return;

    // Resolve wallet names
    const sourceWallet = wallets.find((w) => w.id === selectedWalletId);
    const targetWallet = selectedTargetWalletId
      ? wallets.find((w) => w.id === selectedTargetWalletId)
      : undefined;

    // Convert local date input to ISO string
    let finalDateIso = transaction.date;
    if (dateInput) {
      try {
        const parsed = new Date(dateInput);
        if (!isNaN(parsed.getTime())) {
          finalDateIso = parsed.toISOString();
        }
      } catch {
        finalDateIso = transaction.date;
      }
    }

    const updatedTx: Transaction = {
      ...transaction,
      date: finalDateIso,
      amount: numAmount,
      fee: parseFloat(fee) || 0,
      walletId: selectedWalletId || transaction.walletId,
      walletName: sourceWallet?.name || transaction.walletName,
      targetWalletId: selectedTargetWalletId || undefined,
      targetWalletName: targetWallet?.name || (selectedTargetWalletId ? undefined : transaction.targetWalletName),
      referenceNumber: referenceNumber.trim() || transaction.referenceNumber,
      recipientPhone: recipientPhone.trim() || undefined,
      recipientName: recipientName.trim() || undefined,
      notes: notes.trim() || undefined,
      category: transaction.category,
      status,
    };

    onSave(updatedTx);
    onClose();
  };

  const handleDelete = () => {
    if (confirmDelete) {
      onDelete(transaction.id);
      onClose();
    } else {
      setConfirmDelete(true);
    }
  };

  const getTypeLabel = (type: Transaction['type'], transferKind?: string) => {
    switch (type) {
      case 'deposit':
        return 'إيداع نقدي';
      case 'withdraw':
        return 'سحب كاش';
      case 'transfer':
        return transferKind === 'general' ? 'تحويل عام (خارجي)' : 'تحويل بين المحافظ';
      default:
        return 'معاملة مالية';
    }
  };

  // Human readable preview of the currently selected date
  const readableSelectedDate = dateInput ? formatArabicDateTime(dateInput) : '';

  return (
    <div className="fixed inset-0 z-50 flex items-center justify-center p-4 sm:p-6 bg-black/80 backdrop-blur-sm animate-fade-in">
      <div className="relative w-full max-w-xl rounded-3xl bg-[#1e293b] border border-slate-700/80 p-6 sm:p-8 pt-7 sm:pt-8 shadow-2xl text-white max-h-[92vh] overflow-y-auto">
        {/* Close Button: placed inwards and downwards */}
        <button
          onClick={onClose}
          className="absolute left-5 top-5 sm:left-6 sm:top-6 p-2 text-slate-400 hover:text-white rounded-full bg-slate-800/90 hover:bg-slate-700 transition z-10 active:scale-95 shadow-sm"
          aria-label="إغلاق"
        >
          <X className="w-5 h-5" />
        </button>

        {/* Header */}
        <div className="mb-5 pl-12 sm:pl-14">
          <div className="flex items-center gap-2">
            <span className="p-2 rounded-xl bg-emerald-500/10 border border-emerald-500/20 text-emerald-400">
              <Calendar className="w-5 h-5" />
            </span>
            <div>
              <h2 className="text-lg sm:text-xl font-black flex items-center gap-2 text-white">
                <span>تعديل المعاملة وتاريخ إجرائها</span>
              </h2>
              <p className="text-xs text-slate-400 mt-0.5">
                نوع العملية: <strong className="text-emerald-400">{getTypeLabel(transaction.type, transaction.transferKind)}</strong> • المرجع: <span className="font-mono text-slate-300">{transaction.referenceNumber}</span>
              </p>
            </div>
          </div>
        </div>

        <form onSubmit={handleSubmit} className="space-y-4 text-xs sm:text-sm">
          {/* SECTION 1: Date & Time of Transaction (تعديل تاريخ المعاملة) */}
          <div className="p-3.5 rounded-xl bg-slate-900/90 border border-emerald-500/30 shadow-inner space-y-2.5">
            <div className="flex items-center justify-between">
              <label className="text-emerald-300 font-bold flex items-center gap-1.5 text-xs sm:text-sm">
                <Clock className="w-4 h-4 text-emerald-400" />
                <span>تاريخ وتوقيت العملية التي تمت بها *</span>
              </label>

              {/* Quick Preset Buttons */}
              <div className="flex items-center gap-1.5">
                <button
                  type="button"
                  onClick={handleSetNow}
                  className="px-2 py-1 rounded-lg bg-emerald-600/20 hover:bg-emerald-600/40 text-emerald-300 text-[11px] font-bold border border-emerald-500/30 transition"
                  title="تعيين للوقت الحالي"
                >
                  الآن
                </button>
                <button
                  type="button"
                  onClick={handleSetYesterday}
                  className="px-2 py-1 rounded-lg bg-slate-800 hover:bg-slate-700 text-slate-300 text-[11px] font-medium border border-slate-700 transition"
                  title="تعيين لتاريخ أمس"
                >
                  أمس
                </button>
                <button
                  type="button"
                  onClick={handleResetDate}
                  className="p-1 rounded-lg bg-slate-800 hover:bg-slate-700 text-slate-400 hover:text-white transition"
                  title="استعادة التاريخ الأصلي"
                >
                  <RotateCcw className="w-3.5 h-3.5" />
                </button>
              </div>
            </div>

            <input
              type="datetime-local"
              required
              value={dateInput}
              onChange={(e) => setDateInput(e.target.value)}
              className="w-full bg-[#101827] border border-slate-700 focus:border-emerald-500 rounded-xl px-3 py-2.5 text-white font-mono text-sm focus:outline-none transition shadow-sm"
              dir="ltr"
            />

            {readableSelectedDate && (
              <div className="text-[11px] sm:text-xs text-slate-400 flex items-center gap-1.5 pt-0.5">
                <span className="text-emerald-400 font-semibold">التاريخ المحدد:</span>
                <span className="text-slate-200 font-medium">{readableSelectedDate}</span>
              </div>
            )}
          </div>

          {/* SECTION 2: Amount & Fee */}
          <div className="grid grid-cols-1 sm:grid-cols-2 gap-3">
            <div>
              <label className="block text-slate-300 font-semibold mb-1">المبلغ (ج.م) *</label>
              <input
                type="number"
                step="any"
                required
                min="0.01"
                value={amount}
                onChange={(e) => setAmount(e.target.value)}
                className="w-full bg-slate-900 border border-slate-700 focus:border-emerald-500 rounded-xl px-3 py-2.5 text-emerald-300 font-bold font-mono focus:outline-none text-base"
              />
            </div>
            <div>
              <label className="block text-slate-300 font-semibold mb-1">العمولة (ج.م)</label>
              <input
                type="number"
                step="any"
                min="0"
                value={fee}
                onChange={(e) => setFee(e.target.value)}
                className="w-full bg-slate-900 border border-slate-700 focus:border-emerald-500 rounded-xl px-3 py-2.5 text-white font-mono focus:outline-none text-sm"
              />
            </div>
          </div>

          {/* SECTION 3: Wallets (Source and Target) */}
          <div className="grid grid-cols-1 sm:grid-cols-2 gap-3">
            <div>
              <label className="block text-slate-300 font-semibold mb-1 flex items-center gap-1.5">
                <WalletIcon className="w-3.5 h-3.5 text-emerald-400" />
                <span>المحفظة المنفذة *</span>
              </label>
              <select
                value={selectedWalletId}
                onChange={(e) => setSelectedWalletId(e.target.value)}
                className="w-full bg-slate-900 border border-slate-700 focus:border-emerald-500 rounded-xl px-3 py-2.5 text-white text-xs sm:text-sm focus:outline-none"
              >
                {wallets.map((w) => (
                  <option key={w.id} value={w.id}>
                    {w.name} ({w.balance.toLocaleString()} ج.م)
                  </option>
                ))}
              </select>
            </div>

            {transaction.type === 'transfer' ? (
              <div>
                <label className="block text-slate-300 font-semibold mb-1 flex items-center gap-1.5">
                  <ArrowLeftRight className="w-3.5 h-3.5 text-indigo-400" />
                  <span>المحفظة المستلمة</span>
                </label>
                <select
                  value={selectedTargetWalletId}
                  onChange={(e) => setSelectedTargetWalletId(e.target.value)}
                  className="w-full bg-slate-900 border border-slate-700 focus:border-emerald-500 rounded-xl px-3 py-2.5 text-white text-xs sm:text-sm focus:outline-none"
                >
                  <option value="">-- بدون محفظة داخلية (تحويل خارجي) --</option>
                  {wallets
                    .filter((w) => w.id !== selectedWalletId)
                    .map((w) => (
                      <option key={w.id} value={w.id}>
                        {w.name} ({w.balance.toLocaleString()} ج.م)
                      </option>
                    ))}
                </select>
              </div>
            ) : (
              <div>
                <label className="block text-slate-300 font-semibold mb-1">رقم المرجع / الإيصال</label>
                <input
                  type="text"
                  value={referenceNumber}
                  onChange={(e) => setReferenceNumber(e.target.value)}
                  className="w-full bg-slate-900 border border-slate-700 focus:border-emerald-500 rounded-xl px-3 py-2.5 text-white font-mono focus:outline-none text-sm"
                />
              </div>
            )}
          </div>

          {/* SECTION 4: Reference Number (if transfer) */}
          {transaction.type === 'transfer' && (
            <div>
              <label className="block text-slate-300 font-semibold mb-1">رقم المرجع / الإيصال</label>
              <input
                type="text"
                value={referenceNumber}
                onChange={(e) => setReferenceNumber(e.target.value)}
                className="w-full bg-slate-900 border border-slate-700 focus:border-emerald-500 rounded-xl px-3 py-2 text-white font-mono focus:outline-none text-sm"
              />
            </div>
          )}

          {/* SECTION 5: Recipient Info */}
          <div className="grid grid-cols-1 sm:grid-cols-2 gap-3">
            <div>
              <label className="block text-slate-300 font-semibold mb-1">هاتف العميل / المستلم</label>
              <input
                type="tel"
                value={recipientPhone}
                onChange={(e) => setRecipientPhone(e.target.value)}
                placeholder="010XXXXXXXX"
                className="w-full bg-slate-900 border border-slate-700 focus:border-emerald-500 rounded-xl px-3 py-2 text-white font-mono focus:outline-none text-sm"
                dir="ltr"
              />
            </div>
            <div>
              <label className="block text-slate-300 font-semibold mb-1">اسم العميل / المستلم</label>
              <input
                type="text"
                value={recipientName}
                onChange={(e) => setRecipientName(e.target.value)}
                placeholder="اسم العميل..."
                className="w-full bg-slate-900 border border-slate-700 focus:border-emerald-500 rounded-xl px-3 py-2 text-white focus:outline-none text-sm"
              />
            </div>
          </div>

          {/* SECTION 6: Notes & Status */}
          <div className="grid grid-cols-1 sm:grid-cols-3 gap-3">
            <div className="sm:col-span-2">
              <label className="block text-slate-300 font-semibold mb-1">ملاحظات إضافية</label>
              <input
                type="text"
                value={notes}
                onChange={(e) => setNotes(e.target.value)}
                placeholder="أي تفاصيل أو سبب العملية..."
                className="w-full bg-slate-900 border border-slate-700 focus:border-emerald-500 rounded-xl px-3 py-2 text-white focus:outline-none text-sm"
              />
            </div>
            <div>
              <label className="block text-slate-300 font-semibold mb-1">حالة العملية</label>
              <select
                value={status}
                onChange={(e) => setStatus(e.target.value as Transaction['status'])}
                className="w-full bg-slate-900 border border-slate-700 focus:border-emerald-500 rounded-xl px-3 py-2 text-white text-xs sm:text-sm focus:outline-none"
              >
                <option value="completed">مكتملة (ناجحة)</option>
                <option value="pending">قيد الانتظار</option>
                <option value="failed">ملغاة / فاشلة</option>
              </select>
            </div>
          </div>

          {/* ACTION BUTTONS */}
          <div className="pt-4 border-t border-slate-800 flex flex-col sm:flex-row items-center justify-between gap-3">
            <button
              type="button"
              onClick={handleDelete}
              className={`w-full sm:w-auto px-4 py-2.5 rounded-xl font-bold text-xs flex items-center justify-center gap-1.5 transition ${
                confirmDelete
                  ? 'bg-rose-700 text-white animate-pulse'
                  : 'bg-rose-950/60 text-rose-300 border border-rose-600/40 hover:bg-rose-900/60'
              }`}
            >
              <Trash2 className="w-4 h-4" />
              <span>{confirmDelete ? 'اضغط مرة أخرى للتأكيد!' : 'حذف المعاملة'}</span>
            </button>

            <div className="flex items-center gap-2 w-full sm:w-auto">
              <button
                type="button"
                onClick={onClose}
                className="flex-1 sm:flex-none px-4 py-2.5 rounded-xl bg-slate-800 hover:bg-slate-700 text-slate-300 font-semibold text-xs sm:text-sm transition"
              >
                إلغاء
              </button>
              <button
                type="submit"
                className="flex-1 sm:flex-none px-5 py-2.5 rounded-xl bg-emerald-600 hover:bg-emerald-500 text-white font-bold text-xs sm:text-sm shadow-md transition flex items-center justify-center gap-1.5"
              >
                <Save className="w-4 h-4" />
                <span>حفظ التعديلات والتاريخ</span>
              </button>
            </div>
          </div>
        </form>
      </div>
    </div>
  );
};
