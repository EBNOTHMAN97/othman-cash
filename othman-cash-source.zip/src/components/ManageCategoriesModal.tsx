import React, { useState } from 'react';
import { X, Tag, Plus, Trash2, Check, AlertCircle, CheckCircle2, Palette, Sparkles } from 'lucide-react';
import { useFinancial } from '../context/FinancialContext';

interface ManageCategoriesModalProps {
  isOpen: boolean;
  onClose: () => void;
  onCategoryCreated?: (categoryName: string) => void;
}

const PRESET_COLORS = [
  '#10b981', // emerald
  '#06b6d4', // cyan
  '#3b82f6', // blue
  '#6366f1', // indigo
  '#8b5cf6', // violet
  '#d946ef', // fuchsia
  '#ec4899', // pink
  '#f43f5e', // rose
  '#f59e0b', // amber
  '#f97316', // orange
  '#84cc16', // lime
  '#14b8a6', // teal
];

const PRESET_NAMES = [
  'تسويق وإعلانات',
  'شحن وتوصيل',
  'صيانة وتجهيزات',
  'سلف وقروض',
  'بوفيه وضيافة',
  'أدوات ومهمات',
  'اشتراكات برامج',
  'إكراميات ونثريات',
];

export const ManageCategoriesModal: React.FC<ManageCategoriesModalProps> = ({
  isOpen,
  onClose,
  onCategoryCreated,
}) => {
  const { expenseCategories, addExpenseCategory, deleteExpenseCategory, transactions } = useFinancial();

  const [newCatName, setNewCatName] = useState('');
  const [selectedColor, setSelectedColor] = useState(PRESET_COLORS[0]);
  const [feedback, setFeedback] = useState<{ success: boolean; message: string } | null>(null);
  const [confirmDeleteId, setConfirmDeleteId] = useState<string | null>(null);

  if (!isOpen) return null;

  const handleAddCategory = (e: React.FormEvent) => {
    e.preventDefault();
    setFeedback(null);

    const res = addExpenseCategory(newCatName, selectedColor);
    setFeedback(res);

    if (res.success) {
      if (onCategoryCreated && res.category) {
        onCategoryCreated(res.category.name);
      }
      setNewCatName('');
      // rotate next color
      const currentIndex = PRESET_COLORS.indexOf(selectedColor);
      const nextIndex = (currentIndex + 1) % PRESET_COLORS.length;
      setSelectedColor(PRESET_COLORS[nextIndex]);
    }
  };

  const handleDelete = (id: string) => {
    const res = deleteExpenseCategory(id);
    setFeedback(res);
    setConfirmDeleteId(null);
  };

  // Calculate usage stats per category
  const categoryStats = expenseCategories.map((cat) => {
    const txs = transactions.filter(
      (tx) => tx.type === 'withdraw' && tx.category && tx.category.trim() === cat.name.trim()
    );
    const totalAmount = txs.reduce((sum, tx) => sum + (Number(tx.amount) || 0) + (Number(tx.fee) || 0), 0);
    return {
      ...cat,
      usageCount: txs.length,
      totalAmount,
    };
  });

  return (
    <div className="fixed inset-0 z-50 flex items-center justify-center p-3 sm:p-4 bg-black/80 backdrop-blur-sm animate-fade-in">
      <div className="relative w-full max-w-lg rounded-2xl bg-[#1e293b] border border-slate-700 p-5 sm:p-6 shadow-2xl text-white max-h-[90vh] overflow-y-auto">
        {/* Close Button */}
        <button
          onClick={onClose}
          className="absolute left-4 top-4 p-2 text-slate-400 hover:text-white rounded-full bg-slate-800 hover:bg-slate-700 transition"
        >
          <X className="w-5 h-5" />
        </button>

        {/* Modal Header */}
        <div className="flex items-center gap-2.5 mb-2">
          <div className="p-2 rounded-xl bg-purple-500/10 border border-purple-500/20 text-purple-400">
            <Tag className="w-5 h-5" />
          </div>
          <div>
            <h2 className="text-lg font-bold">إدارة تصنيفات المصروفات</h2>
            <p className="text-xs text-slate-400">
              أنشئ تصنيفات مخصصة تظهر تلقائياً في الرسم البياني الدائري وسجل العمليات
            </p>
          </div>
        </div>

        {/* Feedback Alert */}
        {feedback && (
          <div
            className={`my-3 p-3 rounded-xl border text-xs flex items-center gap-2 ${
              feedback.success
                ? 'bg-emerald-950/60 border-emerald-500/40 text-emerald-200'
                : 'bg-rose-950/60 border-rose-500/40 text-rose-200'
            }`}
          >
            {feedback.success ? (
              <CheckCircle2 className="w-4 h-4 shrink-0 text-emerald-400" />
            ) : (
              <AlertCircle className="w-4 h-4 shrink-0 text-rose-400" />
            )}
            <span>{feedback.message}</span>
          </div>
        )}

        {/* Create New Category Form */}
        <form onSubmit={handleAddCategory} className="my-4 p-4 rounded-xl bg-slate-900 border border-slate-800 space-y-3">
          <div className="flex items-center justify-between">
            <span className="text-xs font-bold text-slate-200 flex items-center gap-1.5">
              <Sparkles className="w-3.5 h-3.5 text-purple-400" />
              إنشاء تصنيف جديد للمصروفات
            </span>
            <span className="text-[11px] text-slate-400">تظهر في الرسم البياني فوراً</span>
          </div>

          <div>
            <input
              type="text"
              required
              placeholder="اكتب اسم التصنيف (مثال: تسويق وإعلانات)..."
              value={newCatName}
              onChange={(e) => setNewCatName(e.target.value)}
              className="w-full bg-slate-800/90 border border-slate-700 rounded-xl px-3 py-2.5 text-white text-xs sm:text-sm focus:outline-none focus:border-purple-500"
            />
          </div>

          {/* Quick preset name suggestions */}
          <div>
            <div className="text-[11px] text-slate-400 mb-1.5">اقتراحات سريعة:</div>
            <div className="flex flex-wrap gap-1.5">
              {PRESET_NAMES.map((preset) => (
                <button
                  type="button"
                  key={preset}
                  onClick={() => setNewCatName(preset)}
                  className="px-2 py-0.5 rounded-lg bg-slate-800 hover:bg-slate-700 text-slate-300 text-[11px] border border-slate-700 transition"
                >
                  +{preset}
                </button>
              ))}
            </div>
          </div>

          {/* Color Picker Swatches */}
          <div>
            <div className="flex items-center justify-between text-[11px] text-slate-400 mb-1.5">
              <span className="flex items-center gap-1">
                <Palette className="w-3 h-3 text-purple-400" />
                اختر لون التصنيف في الرسم البياني:
              </span>
              <div className="flex items-center gap-1.5">
                <span className="w-3 h-3 rounded-full" style={{ backgroundColor: selectedColor }} />
                <span className="font-mono text-slate-300">{selectedColor}</span>
              </div>
            </div>
            <div className="flex flex-wrap items-center gap-2">
              {PRESET_COLORS.map((c) => (
                <button
                  type="button"
                  key={c}
                  onClick={() => setSelectedColor(c)}
                  className={`w-7 h-7 rounded-full border-2 transition-all flex items-center justify-center ${
                    selectedColor === c ? 'scale-110 border-white shadow-lg' : 'border-transparent hover:scale-105'
                  }`}
                  style={{ backgroundColor: c }}
                  title={c}
                >
                  {selectedColor === c && <Check className="w-3.5 h-3.5 text-white drop-shadow" />}
                </button>
              ))}
              <input
                type="color"
                value={selectedColor}
                onChange={(e) => setSelectedColor(e.target.value)}
                className="w-7 h-7 rounded-full cursor-pointer bg-transparent border-0"
                title="لون مخصص"
              />
            </div>
          </div>

          {/* Add Button */}
          <button
            type="submit"
            className="w-full py-2.5 px-4 rounded-xl font-bold text-xs sm:text-sm bg-gradient-to-r from-purple-600 to-indigo-600 hover:from-purple-500 hover:to-indigo-500 text-white shadow-md shadow-purple-950/40 transition flex items-center justify-center gap-2"
          >
            <Plus className="w-4 h-4" />
            <span>إضافة التصنيف الآن</span>
          </button>
        </form>

        {/* List of Existing Categories */}
        <div className="space-y-2 mt-4">
          <div className="flex items-center justify-between text-xs font-bold text-slate-300 mb-1">
            <span>التصنيفات المتاحة ({expenseCategories.length}):</span>
            <span className="text-[11px] text-slate-400 font-normal">
              إجمالي المستخدم: {categoryStats.filter((c) => c.usageCount > 0).length} تصنيف
            </span>
          </div>

          <div className="max-h-60 overflow-y-auto space-y-2 pr-1 no-scrollbar">
            {categoryStats.map((cat) => (
              <div
                key={cat.id}
                className="p-2.5 rounded-xl bg-slate-900/80 border border-slate-800 flex items-center justify-between gap-3 text-xs"
              >
                <div className="flex items-center gap-2.5 min-w-0">
                  <span
                    className="w-4 h-4 rounded-full shrink-0 shadow-sm"
                    style={{ backgroundColor: cat.color }}
                  />
                  <div className="truncate">
                    <span className="font-bold text-white block truncate">{cat.name}</span>
                    <span className="text-[10px] text-slate-400">
                      {cat.usageCount > 0 ? (
                        <>
                          <strong className="text-emerald-400 font-mono">{cat.usageCount}</strong> عملية •{' '}
                          <strong className="text-slate-300 font-mono">{cat.totalAmount.toLocaleString()} ج.م</strong>
                        </>
                      ) : (
                        'لا توجد عمليات بعد'
                      )}
                    </span>
                  </div>
                </div>

                <div className="flex items-center gap-2 shrink-0">
                  {cat.isDefault ? (
                    <span className="text-[10px] font-semibold px-2 py-0.5 rounded-full bg-slate-800 text-slate-400 border border-slate-700">
                      افتراضي
                    </span>
                  ) : (
                    <>
                      {confirmDeleteId === cat.id ? (
                        <div className="flex items-center gap-1.5 animate-fade-in">
                          <button
                            onClick={() => handleDelete(cat.id)}
                            className="px-2 py-1 rounded bg-rose-600 hover:bg-rose-500 text-white text-[11px] font-bold"
                          >
                            تأكيد الحذف
                          </button>
                          <button
                            onClick={() => setConfirmDeleteId(null)}
                            className="px-2 py-1 rounded bg-slate-800 hover:bg-slate-700 text-slate-300 text-[11px]"
                          >
                            إلغاء
                          </button>
                        </div>
                      ) : (
                        <button
                          onClick={() => setConfirmDeleteId(cat.id)}
                          className="p-1.5 rounded-lg bg-slate-800 hover:bg-rose-950/40 text-slate-400 hover:text-rose-400 border border-slate-700 transition"
                          title="حذف هذا التصنيف"
                        >
                          <Trash2 className="w-3.5 h-3.5" />
                        </button>
                      )}
                    </>
                  )}
                </div>
              </div>
            ))}
          </div>
        </div>
      </div>
    </div>
  );
};
