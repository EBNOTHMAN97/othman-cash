import React, { useState } from 'react';
import { X, PlusCircle, WalletCards, CheckCircle2, ShieldCheck } from 'lucide-react';
import { Wallet, WalletProvider } from '../types';

interface CreateWalletModalProps {
  isOpen: boolean;
  onClose: () => void;
  onSave: (wallet: Omit<Wallet, 'id' | 'lastUpdated'>) => void;
}

const PROVIDER_OPTIONS: { id: WalletProvider; name: string; defaultColor: string; defaultDaily: number; defaultMonthly: number }[] = [
  { id: 'vodafone', name: 'فودافون كاش', defaultColor: '#e60000', defaultDaily: 60000, defaultMonthly: 200000 },
  { id: 'instapay', name: 'إنستاباي (IPN)', defaultColor: '#7c3aed', defaultDaily: 120000, defaultMonthly: 400000 },
  { id: 'orange', name: 'أورنج كاش', defaultColor: '#ff7900', defaultDaily: 60000, defaultMonthly: 200000 },
  { id: 'etisalat', name: 'اتصالات كاش', defaultColor: '#009639', defaultDaily: 60000, defaultMonthly: 200000 },
  { id: 'accesspay', name: 'أكسس باي (Access Pay)', defaultColor: '#0ea5e9', defaultDaily: 80000, defaultMonthly: 300000 },
  { id: 'nbe', name: 'البنك الأهلي المصري (NBE)', defaultColor: '#0284c7', defaultDaily: 500000, defaultMonthly: 2000000 },
  { id: 'bank_misr', name: 'بنك مصر', defaultColor: '#f59e0b', defaultDaily: 500000, defaultMonthly: 2000000 },
  { id: 'cash_vault', name: 'الخزينة النقدية (كاش يدوي)', defaultColor: '#10b981', defaultDaily: 250000, defaultMonthly: 1000000 },
];

export const CreateWalletModal: React.FC<CreateWalletModalProps> = ({
  isOpen,
  onClose,
  onSave,
}) => {
  const [name, setName] = useState('');
  const [provider, setProvider] = useState<WalletProvider>('vodafone');
  const [accountNumber, setAccountNumber] = useState('');
  const [balance, setBalance] = useState('');
  const [dailyLimit, setDailyLimit] = useState('60000');
  const [monthlyLimit, setMonthlyLimit] = useState('200000');
  const [note, setNote] = useState('');
  const [customColor, setCustomColor] = useState('#e60000');
  const [isActive, setIsActive] = useState(true);

  if (!isOpen) return null;

  const handleProviderChange = (newProvider: WalletProvider) => {
    setProvider(newProvider);
    const found = PROVIDER_OPTIONS.find((p) => p.id === newProvider);
    if (found) {
      setCustomColor(found.defaultColor);
      setDailyLimit(found.defaultDaily.toString());
      setMonthlyLimit(found.defaultMonthly.toString());
      if (!name) {
        setName(found.name);
      }
    }
  };

  const handleSubmit = (e: React.FormEvent) => {
    e.preventDefault();
    if (!name.trim() || !accountNumber.trim()) return;

    const initialBalance = parseFloat(balance) || 0;
    const parsedDaily = parseFloat(dailyLimit) || 60000;
    const parsedMonthly = parseFloat(monthlyLimit) || 200000;

    onSave({
      name: name.trim(),
      provider,
      accountNumber: accountNumber.trim(),
      balance: initialBalance,
      dailyLimit: parsedDaily,
      dailySpent: 0,
      monthlyLimit: parsedMonthly,
      monthlySpent: 0,
      isActive,
      color: customColor,
      note: note.trim() || undefined,
    });

    // Reset form
    setName('');
    setAccountNumber('');
    setBalance('');
    setNote('');
    onClose();
  };

  return (
    <div className="fixed inset-0 z-50 flex items-center justify-center p-4 sm:p-6 bg-black/80 backdrop-blur-sm animate-fade-in">
      <div className="relative w-full max-w-lg rounded-3xl bg-[#1e293b] border border-slate-700/80 p-6 sm:p-8 pt-7 sm:pt-8 shadow-2xl text-white max-h-[92vh] overflow-y-auto">
        {/* Close Button: placed inwards and downwards */}
        <button
          onClick={onClose}
          className="absolute left-5 top-5 sm:left-6 sm:top-6 p-2 text-slate-400 hover:text-white rounded-full bg-slate-800 hover:bg-slate-700 transition z-10 active:scale-95 shadow-sm"
          aria-label="إغلاق"
        >
          <X className="w-5 h-5" />
        </button>

        {/* Modal Title with safe clearance */}
        <div className="flex items-center gap-2.5 mb-5 pl-12 sm:pl-14">
          <div className="p-2 rounded-xl bg-emerald-500/20 text-emerald-400 shrink-0">
            <WalletCards className="w-5 h-5" />
          </div>
          <div>
            <h2 className="text-lg sm:text-xl font-bold">إنشاء محفظة / حساب جديد</h2>
            <p className="text-xs text-slate-400">إضافة محفظة إلكترونية أو حساب بنكي إلى شبكة عثمان كاش</p>
          </div>
        </div>

        <form onSubmit={handleSubmit} className="space-y-4 text-xs sm:text-sm">
          {/* Provider Selection */}
          <div>
            <label className="block text-slate-300 font-semibold mb-1.5">مقدم الخدمة / نوع المحفظة *</label>
            <div className="grid grid-cols-2 sm:grid-cols-4 gap-2">
              {PROVIDER_OPTIONS.map((item) => (
                <button
                  type="button"
                  key={item.id}
                  onClick={() => handleProviderChange(item.id)}
                  className={`p-2 rounded-xl border text-right transition flex flex-col justify-between ${
                    provider === item.id
                      ? 'bg-slate-800 border-emerald-500 shadow-sm shadow-emerald-500/20'
                      : 'bg-slate-900/80 border-slate-700 hover:border-slate-600'
                  }`}
                >
                  <div className="flex items-center justify-between mb-1">
                    <span
                      className="w-3 h-3 rounded-full shrink-0"
                      style={{ backgroundColor: item.defaultColor }}
                    />
                    {provider === item.id && (
                      <CheckCircle2 className="w-3.5 h-3.5 text-emerald-400" />
                    )}
                  </div>
                  <span className="text-[11px] font-bold text-slate-200 line-clamp-1">{item.name}</span>
                </button>
              ))}
            </div>
          </div>

          {/* Name & Account Number */}
          <div className="grid grid-cols-1 sm:grid-cols-2 gap-3">
            <div>
              <label className="block text-slate-300 font-semibold mb-1">اسم المحفظة التميزي *</label>
              <input
                type="text"
                required
                placeholder="مثال: فودافون كاش - فرع 2"
                value={name}
                onChange={(e) => setName(e.target.value)}
                className="w-full bg-slate-900 border border-slate-700 rounded-xl px-3 py-2.5 text-white focus:outline-none focus:border-emerald-500 text-sm font-semibold"
              />
            </div>

            <div>
              <label className="block text-slate-300 font-semibold mb-1">رقم الهاتف / رقم الحساب *</label>
              <input
                type="text"
                required
                placeholder="مثال: 01012345678 أو اسم IPN"
                value={accountNumber}
                onChange={(e) => setAccountNumber(e.target.value)}
                className="w-full bg-slate-900 border border-slate-700 rounded-xl px-3 py-2.5 text-white focus:outline-none focus:border-emerald-500 text-sm font-semibold dir-ltr text-right"
              />
            </div>
          </div>

          {/* Initial Balance */}
          <div>
            <label className="block text-slate-300 font-semibold mb-1">الرصيد الافتتاحي (ج.م) *</label>
            <div className="relative">
              <input
                type="number"
                min="0"
                step="any"
                required
                placeholder="0"
                value={balance}
                onChange={(e) => setBalance(e.target.value)}
                className="w-full bg-slate-900 border border-slate-700 rounded-xl px-3 py-2.5 text-white focus:outline-none focus:border-emerald-500 text-sm font-bold pl-12"
              />
              <span className="absolute left-3 top-1/2 -translate-y-1/2 text-xs text-slate-400 font-bold">
                ج.م
              </span>
            </div>
          </div>

          {/* Limits: Daily & Monthly */}
          <div className="grid grid-cols-1 sm:grid-cols-2 gap-3">
            <div>
              <label className="block text-slate-300 font-semibold mb-1">الحد اليومي (الليميت) ج.م *</label>
              <input
                type="number"
                min="1000"
                required
                value={dailyLimit}
                onChange={(e) => setDailyLimit(e.target.value)}
                className="w-full bg-slate-900 border border-slate-700 rounded-xl px-3 py-2.5 text-white focus:outline-none focus:border-emerald-500 text-sm font-semibold"
              />
            </div>

            <div>
              <label className="block text-slate-300 font-semibold mb-1">الحد الشهري (الليميت) ج.م *</label>
              <input
                type="number"
                min="5000"
                required
                value={monthlyLimit}
                onChange={(e) => setMonthlyLimit(e.target.value)}
                className="w-full bg-slate-900 border border-slate-700 rounded-xl px-3 py-2.5 text-white focus:outline-none focus:border-emerald-500 text-sm font-semibold"
              />
            </div>
          </div>

          {/* Color & Status */}
          <div className="grid grid-cols-1 sm:grid-cols-2 gap-3 items-center">
            <div>
              <label className="block text-slate-300 font-semibold mb-1">لون تمييز المحفظة</label>
              <div className="flex items-center gap-2 bg-slate-900 border border-slate-700 rounded-xl px-3 py-2">
                <input
                  type="color"
                  value={customColor}
                  onChange={(e) => setCustomColor(e.target.value)}
                  className="w-8 h-8 rounded-lg cursor-pointer bg-transparent border-0"
                />
                <span className="text-xs font-mono text-slate-300">{customColor}</span>
              </div>
            </div>

            <div className="pt-4 sm:pt-0">
              <label className="flex items-center gap-2 cursor-pointer select-none">
                <input
                  type="checkbox"
                  checked={isActive}
                  onChange={(e) => setIsActive(e.target.checked)}
                  className="w-4 h-4 accent-emerald-500 rounded cursor-pointer"
                />
                <span className="text-xs font-bold text-slate-200">المحفظة نشطة وجاهزة للعمليات</span>
              </label>
            </div>
          </div>

          {/* Notes */}
          <div>
            <label className="block text-slate-300 font-semibold mb-1">ملاحظات إضافية (اختياري)</label>
            <textarea
              rows={2}
              placeholder="مثال: مخصصة لمعاملات الفرع الثاني، عمولات خاصة..."
              value={note}
              onChange={(e) => setNote(e.target.value)}
              className="w-full bg-slate-900 border border-slate-700 rounded-xl px-3 py-2 text-white focus:outline-none focus:border-emerald-500 text-xs resize-none"
            />
          </div>

          {/* Action Buttons */}
          <div className="pt-3 border-t border-slate-700/80 flex items-center justify-end gap-2.5">
            <button
              type="button"
              onClick={onClose}
              className="px-4 py-2.5 rounded-xl bg-slate-800 hover:bg-slate-700 text-slate-300 font-bold transition text-xs sm:text-sm"
            >
              إلغاء
            </button>
            <button
              type="submit"
              className="flex items-center gap-2 px-5 py-2.5 rounded-xl bg-gradient-to-r from-emerald-600 to-teal-600 hover:from-emerald-500 hover:to-teal-500 text-white font-bold transition text-xs sm:text-sm shadow-lg shadow-emerald-950/60"
            >
              <PlusCircle className="w-4 h-4" />
              <span>إنشاء المحفظة وحفظها</span>
            </button>
          </div>
        </form>
      </div>
    </div>
  );
};
