import React from 'react';
import { CalendarRange, AlertTriangle, ShieldCheck } from 'lucide-react';
import { useFinancial } from '../context/FinancialContext';

export const MonthlyLimitsTracker: React.FC = () => {
  const { wallets } = useFinancial();

  const totalMonthlyLimit = wallets.reduce((acc, w) => acc + w.monthlyLimit, 0);
  const totalMonthlySpent = wallets.reduce((acc, w) => acc + w.monthlySpent, 0);
  const overallMonthlyPercent = totalMonthlyLimit > 0 
    ? Math.min(100, Math.round((totalMonthlySpent / totalMonthlyLimit) * 100))
    : 0;

  return (
    <div className="rounded-2xl bg-[#1e293b]/95 border border-slate-700/80 p-4 sm:p-6 shadow-xl">
      <div className="flex flex-col sm:flex-row sm:items-center justify-between gap-3 mb-5 pb-3.5 border-b border-slate-800">
        <div>
          <h2 className="text-lg sm:text-xl font-bold text-white flex items-center gap-2">
            <CalendarRange className="w-5 h-5 text-indigo-400" />
            <span>متابعة الليمت الشهري للمحافظ</span>
          </h2>
          <p className="text-xs sm:text-sm text-slate-400 mt-0.5">
            مراقبة الحد الأقصى الشهري للسحب والتحويلات لتجنب توقف المحافظ قبل نهاية الشهر
          </p>
        </div>

        {/* Overall Monthly Spent Badge */}
        <div className="bg-slate-900/90 border border-slate-800 px-3.5 py-1.5 rounded-xl flex items-center gap-2 text-xs sm:text-sm">
          <span className="text-slate-400">إجمالي استهلاك الشهر:</span>
          <span className="font-mono font-black text-indigo-300 text-sm sm:text-base">
            {overallMonthlyPercent}%
          </span>
        </div>
      </div>

      {/* Grid of Wallets Monthly Limits */}
      <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-3.5 sm:gap-4">
        {wallets.map((wallet) => {
          const monthlyPercent = Math.min(100, Math.round((wallet.monthlySpent / wallet.monthlyLimit) * 100));
          const monthlyRemaining = Math.max(0, wallet.monthlyLimit - wallet.monthlySpent);
          const isWarning = monthlyPercent >= 80;

          return (
            <div
              key={wallet.id}
              className={`rounded-2xl p-4 border transition-all duration-200 ${
                isWarning
                  ? 'bg-rose-950/20 border-rose-500/50 shadow-md shadow-rose-950/30'
                  : 'bg-slate-900/80 border-slate-800 hover:border-slate-700'
              }`}
            >
              <div className="flex items-center justify-between mb-2.5">
                <span className="font-bold text-sm sm:text-base text-white line-clamp-1">{wallet.name}</span>
                <span
                  className={`text-xs font-mono font-extrabold px-2 py-0.5 rounded-full ${
                    monthlyPercent >= 85
                      ? 'bg-rose-500/20 text-rose-300 border border-rose-500/40'
                      : monthlyPercent >= 70
                      ? 'bg-amber-500/20 text-amber-300 border border-amber-500/40'
                      : 'bg-indigo-500/20 text-indigo-300 border border-indigo-500/40'
                  }`}
                >
                  {monthlyPercent}%
                </span>
              </div>

              {/* Monthly Progress Bar */}
              <div className="w-full bg-slate-800 h-2.5 rounded-full overflow-hidden mb-3">
                <div
                  className={`h-full rounded-full transition-all duration-500 ${
                    monthlyPercent >= 85
                      ? 'bg-gradient-to-r from-amber-500 to-rose-500'
                      : monthlyPercent >= 70
                      ? 'bg-gradient-to-r from-indigo-500 to-amber-500'
                      : 'bg-gradient-to-r from-teal-500 to-indigo-500'
                  }`}
                  style={{ width: `${monthlyPercent}%` }}
                />
              </div>

              {/* Numbers Detail */}
              <div className="flex justify-between items-center text-xs text-slate-300">
                <div>
                  <span className="text-slate-400 block text-[11px]">المصروف الشهري</span>
                  <strong className="font-mono text-white text-xs sm:text-sm">
                    {wallet.monthlySpent.toLocaleString()} ج.م
                  </strong>
                </div>
                <div className="text-left">
                  <span className="text-slate-400 block text-[11px]">الحد الأقصى الشهري</span>
                  <strong className="font-mono text-indigo-300 text-xs sm:text-sm">
                    {wallet.monthlyLimit.toLocaleString()} ج.م
                  </strong>
                </div>
              </div>

              <div className="mt-2.5 pt-2 border-t border-slate-800/80 flex items-center justify-between text-[11px]">
                <span className="text-slate-400">المتبقي لليمت هذا الشهر:</span>
                <span className={`font-mono font-bold ${isWarning ? 'text-rose-400' : 'text-emerald-400'}`}>
                  {monthlyRemaining.toLocaleString()} ج.م
                </span>
              </div>
            </div>
          );
        })}
      </div>
    </div>
  );
};
