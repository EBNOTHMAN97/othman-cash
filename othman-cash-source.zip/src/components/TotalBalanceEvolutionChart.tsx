import React, { useMemo } from 'react';
import {
  ResponsiveContainer,
  AreaChart,
  Area,
  XAxis,
  YAxis,
  CartesianGrid,
  Tooltip,
} from 'recharts';
import {
  TrendingUp,
  TrendingDown,
  Wallet as WalletIcon,
  ArrowUpRight,
  ArrowDownRight,
  Activity,
  Calendar,
} from 'lucide-react';
import { useFinancial, getLocalDateKey } from '../context/FinancialContext';

interface DayBalancePoint {
  dateKey: string;
  dayLabel: string;
  fullDateLabel: string;
  balance: number;
  netChange: number;
  inflow: number;
  outflow: number;
  txCount: number;
  isToday: boolean;
}

export const TotalBalanceEvolutionChart: React.FC = () => {
  const { totalBalance, transactions, wallets } = useFinancial();

  // Compute 7-day balance evolution points
  const chartData: DayBalancePoint[] = useMemo(() => {
    const today = new Date();
    const days: { dateKey: string; dateObj: Date; isToday: boolean }[] = [];

    for (let i = 6; i >= 0; i--) {
      const d = new Date(today);
      d.setDate(today.getDate() - i);
      const dateKey = getLocalDateKey(d);
      days.push({
        dateKey,
        dateObj: d,
        isToday: i === 0,
      });
    }

    // Step 1: Calculate net balance impact for each dateKey
    const dayStats: Record<string, { inflow: number; outflow: number; count: number }> = {};
    days.forEach((day) => {
      dayStats[day.dateKey] = { inflow: 0, outflow: 0, count: 0 };
    });

    transactions.forEach((tx) => {
      if (tx.status === 'failed') return;
      const key = getLocalDateKey(tx.date);
      if (dayStats[key]) {
        dayStats[key].count += 1;
        const amt = Number(tx.amount) || 0;
        if (tx.type === 'deposit') {
          dayStats[key].inflow += amt;
        } else if (tx.type === 'withdraw') {
          dayStats[key].outflow += amt;
        } else if (tx.type === 'transfer' && tx.transferKind === 'general') {
          dayStats[key].outflow += amt;
        }
      }
    });

    // Step 2: Backward accumulation from today's live total balance
    // End-of-day balance for today is current live totalBalance.
    // Balance(day i-1) = Balance(day i) - NetChange(day i)
    const pointsReversed: DayBalancePoint[] = [];
    let runningBalance = totalBalance;

    for (let i = days.length - 1; i >= 0; i--) {
      const day = days[i];
      const stat = dayStats[day.dateKey] || { inflow: 0, outflow: 0, count: 0 };
      const net = stat.inflow - stat.outflow;

      const dayName = day.dateObj.toLocaleDateString('ar-EG', { weekday: 'short' });
      const dayMonth = `${day.dateObj.getDate()}/${day.dateObj.getMonth() + 1}`;
      const dayLabel = day.isToday ? 'اليوم' : `${dayName} ${dayMonth}`;

      const fullDateLabel = day.dateObj.toLocaleDateString('ar-EG', {
        weekday: 'long',
        year: 'numeric',
        month: 'long',
        day: 'numeric',
      });

      pointsReversed.push({
        dateKey: day.dateKey,
        dayLabel,
        fullDateLabel,
        balance: Math.max(0, Math.round(runningBalance)),
        netChange: net,
        inflow: stat.inflow,
        outflow: stat.outflow,
        txCount: stat.count,
        isToday: day.isToday,
      });

      // Prepare runningBalance for the preceding day
      runningBalance = runningBalance - net;
    }

    // Reverse to chronological order (6 days ago -> today)
    return pointsReversed.reverse();
  }, [totalBalance, transactions]);

  // Statistics over the 7 days
  const startBalance = chartData[0]?.balance ?? totalBalance;
  const currentBalance = chartData[chartData.length - 1]?.balance ?? totalBalance;
  const net7DaysChange = currentBalance - startBalance;
  const percentChange = startBalance > 0 ? (net7DaysChange / startBalance) * 100 : 0;
  const maxBalance = Math.max(...chartData.map((d) => d.balance), totalBalance);
  const minBalance = Math.min(...chartData.map((d) => d.balance), totalBalance);

  return (
    <div className="rounded-2xl bg-[#1e293b]/95 border border-slate-700/80 p-4 sm:p-6 shadow-xl transition-all">
      {/* Header and Title */}
      <div className="flex flex-col sm:flex-row sm:items-center justify-between gap-3 mb-5 pb-4 border-b border-slate-800">
        <div>
          <h2 className="text-lg sm:text-xl font-bold text-white flex items-center gap-2">
            <span className="p-2 rounded-xl bg-emerald-500/10 border border-emerald-500/20 text-emerald-400">
              <Activity className="w-5 h-5" />
            </span>
            <span>تطور إجمالي الرصيد (الأيام الـ 7 الماضية)</span>
          </h2>
          <p className="text-xs sm:text-sm text-slate-400 mt-1">
            مخطط بياني ذكي يوضح مسار نمو وتغير إجمالي السيولة النقدية لجميع المحافظ ({wallets.length} محافظ)
          </p>
        </div>

        {/* 7-day Change Badge */}
        <div className="flex items-center gap-2 self-start sm:self-auto">
          <div
            className={`flex items-center gap-1.5 px-3.5 py-1.5 rounded-xl border text-xs sm:text-sm font-bold font-mono ${
              net7DaysChange >= 0
                ? 'bg-emerald-950/50 text-emerald-300 border-emerald-500/40'
                : 'bg-rose-950/50 text-rose-300 border-rose-500/40'
            }`}
          >
            {net7DaysChange >= 0 ? (
              <TrendingUp className="w-4 h-4 text-emerald-400" />
            ) : (
              <TrendingDown className="w-4 h-4 text-rose-400" />
            )}
            <span>
              {net7DaysChange >= 0 ? '+' : ''}
              {net7DaysChange.toLocaleString()} ج.م
            </span>
            <span className="text-[11px] opacity-80">
              ({percentChange >= 0 ? '+' : ''}
              {percentChange.toFixed(1)}%)
            </span>
          </div>
        </div>
      </div>

      {/* Mini Stat Cards Row */}
      <div className="grid grid-cols-2 lg:grid-cols-4 gap-2.5 sm:gap-3.5 mb-5">
        {/* Metric 1: Current Total Balance */}
        <div className="p-3 sm:p-3.5 rounded-xl bg-slate-900/90 border border-slate-800">
          <span className="text-[11px] text-slate-400 block font-medium">الرصيد الحالي اليوم</span>
          <div className="flex items-baseline gap-1 mt-1">
            <span className="text-base sm:text-xl font-black text-white font-mono">
              {totalBalance.toLocaleString()}
            </span>
            <span className="text-[10px] sm:text-xs font-bold text-emerald-400">ج.م</span>
          </div>
        </div>

        {/* Metric 2: 7-Day Net Change */}
        <div className="p-3 sm:p-3.5 rounded-xl bg-slate-900/90 border border-slate-800">
          <span className="text-[11px] text-slate-400 block font-medium">صافي التغير خلال 7 أيام</span>
          <div className="flex items-baseline gap-1 mt-1">
            <span
              className={`text-base sm:text-xl font-black font-mono ${
                net7DaysChange >= 0 ? 'text-emerald-400' : 'text-rose-400'
              }`}
            >
              {net7DaysChange >= 0 ? '+' : ''}
              {net7DaysChange.toLocaleString()}
            </span>
            <span className="text-[10px] sm:text-xs font-bold text-slate-400">ج.م</span>
          </div>
        </div>

        {/* Metric 3: Peak Balance */}
        <div className="p-3 sm:p-3.5 rounded-xl bg-slate-900/90 border border-slate-800">
          <span className="text-[11px] text-slate-400 block font-medium">أعلى رصيد تم تسجيله</span>
          <div className="flex items-baseline gap-1 mt-1">
            <span className="text-base sm:text-xl font-black text-sky-400 font-mono">
              {maxBalance.toLocaleString()}
            </span>
            <span className="text-[10px] sm:text-xs font-bold text-slate-400">ج.م</span>
          </div>
        </div>

        {/* Metric 4: Lowest Balance */}
        <div className="p-3 sm:p-3.5 rounded-xl bg-slate-900/90 border border-slate-800">
          <span className="text-[11px] text-slate-400 block font-medium">أدنى رصيد خلال الفترة</span>
          <div className="flex items-baseline gap-1 mt-1">
            <span className="text-base sm:text-xl font-black text-amber-400 font-mono">
              {minBalance.toLocaleString()}
            </span>
            <span className="text-[10px] sm:text-xs font-bold text-slate-400">ج.م</span>
          </div>
        </div>
      </div>

      {/* Main Recharts Area Chart */}
      <div className="w-full h-64 sm:h-72 mt-2" dir="ltr">
        <ResponsiveContainer width="100%" height="100%">
          <AreaChart data={chartData} margin={{ top: 12, right: 12, left: -10, bottom: 0 }}>
            <defs>
              <linearGradient id="balanceEvolutionGradient" x1="0" y1="0" x2="0" y2="1">
                <stop offset="0%" stopColor="#10b981" stopOpacity={0.45} />
                <stop offset="85%" stopColor="#10b981" stopOpacity={0.03} />
                <stop offset="100%" stopColor="#10b981" stopOpacity={0.0} />
              </linearGradient>
            </defs>

            <CartesianGrid strokeDasharray="3 3" stroke="#334155" opacity={0.35} vertical={false} />

            <XAxis
              dataKey="dayLabel"
              stroke="#64748b"
              tick={{ fill: '#94a3b8', fontSize: 11 }}
              tickLine={false}
              axisLine={{ stroke: '#334155' }}
            />

            <YAxis
              stroke="#64748b"
              tick={{ fill: '#94a3b8', fontSize: 11 }}
              tickLine={false}
              axisLine={false}
              tickFormatter={(v: number) => {
                if (v >= 1_000_000) return `${(v / 1_000_000).toFixed(1)}M`;
                if (v >= 1_000) return `${(v / 1_000).toFixed(0)}k`;
                return `${v}`;
              }}
              domain={['dataMin - 5000', 'dataMax + 5000']}
            />

            <Tooltip
              content={({ active, payload }) => {
                if (!active || !payload || !payload.length) return null;
                const point = payload[0].payload as DayBalancePoint;
                return (
                  <div
                    className="rounded-xl bg-[#0f172a] border border-slate-700 p-3 shadow-2xl text-right min-w-[200px]"
                    dir="rtl"
                  >
                    <div className="flex items-center justify-between pb-2 mb-2 border-b border-slate-800 text-xs text-slate-300">
                      <span className="font-bold text-white flex items-center gap-1.5">
                        <Calendar className="w-3.5 h-3.5 text-emerald-400" />
                        <span>{point.dayLabel}</span>
                      </span>
                      <span className="text-[10px] text-slate-400 font-mono">{point.dateKey}</span>
                    </div>

                    <div className="space-y-1.5 text-xs">
                      <div className="flex items-center justify-between">
                        <span className="text-slate-400">إجمالي الرصيد:</span>
                        <span className="font-mono font-black text-emerald-400 text-sm">
                          {point.balance.toLocaleString()} ج.م
                        </span>
                      </div>

                      <div className="flex items-center justify-between">
                        <span className="text-slate-400">صافي حركة اليوم:</span>
                        <span
                          className={`font-mono font-bold ${
                            point.netChange > 0
                              ? 'text-emerald-400'
                              : point.netChange < 0
                              ? 'text-rose-400'
                              : 'text-slate-400'
                          }`}
                        >
                          {point.netChange > 0 ? '+' : ''}
                          {point.netChange.toLocaleString()} ج.م
                        </span>
                      </div>

                      {point.txCount > 0 && (
                        <div className="flex items-center justify-between text-[11px] pt-1 border-t border-slate-800/60 text-slate-400">
                          <span>عدد الحركات:</span>
                          <span className="font-mono text-slate-200">{point.txCount} عملية</span>
                        </div>
                      )}
                    </div>
                  </div>
                );
              }}
            />

            <Area
              type="monotone"
              dataKey="balance"
              stroke="#10b981"
              strokeWidth={3}
              fill="url(#balanceEvolutionGradient)"
              activeDot={{
                r: 6,
                fill: '#10b981',
                stroke: '#ffffff',
                strokeWidth: 2,
              }}
            />
          </AreaChart>
        </ResponsiveContainer>
      </div>
    </div>
  );
};
