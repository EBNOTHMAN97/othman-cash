import React, { useState } from 'react';
import { Search, ArrowDownRight, ArrowUpRight, ArrowLeftRight, Send, Download, Edit3, Trash2 } from 'lucide-react';
import { useFinancial } from '../context/FinancialContext';
import { Transaction } from '../types';

interface TransactionsTableProps {
  onEditTransaction?: (tx: Transaction) => void;
  title?: string;
  subtitle?: string;
  searchQuery?: string;
  onSearchQueryChange?: (query: string) => void;
  hideInternalSearch?: boolean;
}

export const TransactionsTable: React.FC<TransactionsTableProps> = ({
  onEditTransaction,
  title = 'سجل العمليات والتحويلات',
  subtitle = 'سجل محاسبي لحظي لجميع حركات الإيداع والسحب والتحويل',
  searchQuery,
  onSearchQueryChange,
  hideInternalSearch = false,
}) => {
  const { transactions, deleteTransaction } = useFinancial();
  const [filterType, setFilterType] = useState<string>('all');
  const [internalSearchQuery, setInternalSearchQuery] = useState<string>('');

  const effectiveSearchQuery = searchQuery !== undefined ? searchQuery : internalSearchQuery;
  const handleSearchChange = (val: string) => {
    if (onSearchQueryChange) {
      onSearchQueryChange(val);
    } else {
      setInternalSearchQuery(val);
    }
  };

  const filtered = transactions.filter((tx) => {
    if (filterType === 'deposit' && tx.type !== 'deposit') return false;
    if (filterType === 'withdraw' && tx.type !== 'withdraw') return false;
    if (
      filterType === 'transfer_general' &&
      !(tx.type === 'transfer' && (tx.transferKind === 'general' || (!tx.targetWalletId && tx.transferKind !== 'internal')))
    ) {
      return false;
    }
    if (
      filterType === 'transfer_internal' &&
      !(tx.type === 'transfer' && (tx.transferKind === 'internal' || !!tx.targetWalletId))
    ) {
      return false;
    }

    if (effectiveSearchQuery.trim()) {
      const q = effectiveSearchQuery.toLowerCase().trim();
      const matchCategory = tx.category ? tx.category.toLowerCase().includes(q) : false;
      const matchNotes = tx.notes ? tx.notes.toLowerCase().includes(q) : false;
      const matchRecipient = tx.recipientName ? tx.recipientName.toLowerCase().includes(q) : false;
      const matchRef = tx.referenceNumber ? tx.referenceNumber.toLowerCase().includes(q) : false;
      const matchWallet = (tx.walletName ? tx.walletName.toLowerCase().includes(q) : false) ||
                          (tx.targetWalletName ? tx.targetWalletName.toLowerCase().includes(q) : false);
      const matchPhone = tx.recipientPhone ? tx.recipientPhone.includes(q) : false;
      return matchCategory || matchNotes || matchRecipient || matchRef || matchWallet || matchPhone;
    }
    return true;
  });

  const formatDate = (dateStr: string) => {
    try {
      const d = new Date(dateStr);
      return d.toLocaleDateString('ar-EG', {
        month: 'short',
        day: 'numeric',
        hour: '2-digit',
        minute: '2-digit',
      });
    } catch {
      return dateStr;
    }
  };

  const getBadge = (
    type: Transaction['type'],
    transferKind?: Transaction['transferKind'],
    targetWalletName?: string
  ) => {
    switch (type) {
      case 'deposit':
        return {
          label: 'إيداع نقدي',
          icon: <ArrowDownRight className="w-4 h-4 text-emerald-400" />,
          color: 'text-emerald-300 bg-emerald-500/20 border-emerald-500/40',
          sign: '+',
          amountColor: 'text-emerald-400 font-extrabold',
        };
      case 'withdraw':
        return {
          label: 'سحب كاش',
          icon: <ArrowUpRight className="w-4 h-4 text-rose-400" />,
          color: 'text-rose-300 bg-rose-500/20 border-rose-500/40',
          sign: '-',
          amountColor: 'text-rose-400 font-extrabold',
        };
      case 'transfer':
        if (transferKind === 'general' || (!targetWalletName && transferKind !== 'internal')) {
          return {
            label: 'تحويل عام (خارجي)',
            icon: <Send className="w-4 h-4 text-sky-400" />,
            color: 'text-sky-300 bg-sky-500/20 border-sky-500/40',
            sign: '↗',
            amountColor: 'text-sky-400 font-extrabold',
          };
        }
        return {
          label: 'تحويل بين المحافظ',
          icon: <ArrowLeftRight className="w-4 h-4 text-indigo-400" />,
          color: 'text-indigo-300 bg-indigo-500/20 border-indigo-500/40',
          sign: '⇄',
          amountColor: 'text-indigo-400 font-extrabold',
        };
    }
  };

  const exportCSV = () => {
    const headers = ['رقم العملية', 'النوع', 'التصنيف', 'المحفظة', 'المبلغ', 'العمولة', 'التاريخ', 'ملاحظات'];
    const rows = filtered.map((tx) => [
      tx.referenceNumber,
      tx.type,
      `"${tx.category || ''}"`,
      tx.walletName,
      tx.amount,
      tx.fee,
      tx.date,
      `"${tx.notes || ''}"`,
    ]);
    const csvContent = 'data:text/csv;charset=utf-8,\uFEFF' + [headers.join(','), ...rows.map((e) => e.join(','))].join('\n');
    const encodedUri = encodeURI(csvContent);
    const link = document.createElement('a');
    link.setAttribute('href', encodedUri);
    link.setAttribute('download', `othman_cash_transactions_${new Date().toISOString().slice(0, 10)}.csv`);
    document.body.appendChild(link);
    link.click();
    document.body.removeChild(link);
  };

  return (
    <div className="rounded-2xl bg-[#1e293b]/95 border border-slate-700/80 p-4 sm:p-6 shadow-xl">
      {/* Header and Controls */}
      <div className="flex flex-col sm:flex-row sm:items-center justify-between gap-3 mb-4 pb-3.5 border-b border-slate-800">
        <div>
          <h2 className="text-lg sm:text-xl font-bold text-white tracking-wide">{title}</h2>
          <p className="text-xs sm:text-sm text-slate-400 mt-0.5">{subtitle}</p>
        </div>

        <div className="flex items-center gap-2">
          <button
            onClick={exportCSV}
            className="flex items-center gap-1.5 px-3.5 py-2 rounded-xl bg-slate-800 hover:bg-slate-700 text-slate-200 text-xs sm:text-sm font-semibold border border-slate-700 transition"
            title="تصدير كملف CSV"
          >
            <Download className="w-4 h-4 text-emerald-400" />
            <span>تصدير CSV</span>
          </button>
        </div>
      </div>

      {/* Filter and Search Bar */}
      <div className="flex flex-col sm:flex-row gap-2.5 mb-4">
        {/* Search Input (shown when internal search is not hidden) */}
        {!hideInternalSearch && (
          <div className="relative flex-1">
            <Search className="w-4 h-4 text-slate-400 absolute right-3.5 top-3.5" />
            <input
              type="text"
              placeholder="بحث بالوصف أو اسم التصنيف أو رقم العملية أو المحفظة..."
              value={effectiveSearchQuery}
              onChange={(e) => handleSearchChange(e.target.value)}
              className="w-full bg-slate-900 border border-slate-700/80 rounded-xl pr-10 pl-3.5 py-2.5 text-xs sm:text-sm text-white focus:outline-none focus:border-emerald-500"
            />
          </div>
        )}

        {/* Filter Buttons */}
        <div className="flex gap-1.5 overflow-x-auto pb-1 no-scrollbar">
          {[
            { id: 'all', label: 'الكل' },
            { id: 'deposit', label: 'إيداعات' },
            { id: 'withdraw', label: 'سحوبات' },
            { id: 'transfer_general', label: 'تحويل عام (خارجي)' },
            { id: 'transfer_internal', label: 'تحويل بين المحافظ' },
          ].map((tab) => (
            <button
              key={tab.id}
              onClick={() => setFilterType(tab.id)}
              className={`px-3 py-1.5 sm:px-3.5 sm:py-2 rounded-xl text-xs sm:text-sm font-bold transition whitespace-nowrap ${
                filterType === tab.id
                  ? 'bg-emerald-600 text-white shadow-md'
                  : 'bg-slate-900 text-slate-400 hover:text-slate-200 border border-slate-800'
              }`}
            >
              {tab.label}
            </button>
          ))}
        </div>
      </div>

      {/* Mobile Card View (shown on small screens) */}
      <div className="block md:hidden space-y-3">
        {filtered.length === 0 ? (
          <div className="text-center py-8 text-slate-400 text-sm">لا توجد عمليات مسجلة تطابق البحث.</div>
        ) : (
          filtered.map((tx) => {
            const badge = getBadge(tx.type, tx.transferKind, tx.targetWalletName);
            return (
              <div
                key={tx.id}
                className="rounded-xl bg-slate-900/85 border border-slate-800/90 p-3.5 flex flex-col gap-2.5 hover:border-slate-700 transition"
              >
                <div className="flex items-center justify-between">
                  <div className="flex items-center gap-2 flex-wrap">
                    <span className={`inline-flex items-center gap-1.5 text-xs font-bold px-2.5 py-1 rounded-full border ${badge.color}`}>
                      {badge.icon}
                      {badge.label}
                    </span>
                    {tx.category && (
                      <span className="text-xs bg-slate-800 text-emerald-400 px-2 py-0.5 rounded-md border border-slate-700/80 font-medium">
                        {tx.category}
                      </span>
                    )}
                    <span className="text-xs text-slate-400 font-mono">{tx.referenceNumber}</span>
                  </div>
                  <div className="text-right">
                    <span className={`font-mono text-base ${badge.amountColor}`}>
                      {badge.sign} {tx.amount.toLocaleString()} ج.م
                    </span>
                  </div>
                </div>

                <div className="flex items-center justify-between text-xs sm:text-sm text-slate-200">
                  <span className="font-semibold">
                    {tx.walletName}
                    {tx.targetWalletName && ` ⇾ ${tx.targetWalletName}`}
                  </span>
                  <span className="text-xs text-slate-400">{formatDate(tx.date)}</span>
                </div>

                <div className="pt-2 border-t border-slate-800/80 text-xs text-slate-400 flex justify-between items-center">
                  <span className="line-clamp-1">
                    {tx.recipientName && `${tx.recipientName} `}
                    {tx.recipientPhone && `(${tx.recipientPhone})`}
                    {tx.notes && ` • ${tx.notes}`}
                    {tx.fee > 0 && ` • عمولة: ${tx.fee} ج.م`}
                  </span>

                  <div className="flex items-center gap-1 shrink-0">
                    {onEditTransaction && (
                      <button
                        onClick={() => onEditTransaction(tx)}
                        className="p-1.5 rounded-lg text-slate-400 hover:text-emerald-400 hover:bg-slate-800 transition"
                        title="تعديل المعاملة"
                      >
                        <Edit3 className="w-4 h-4" />
                      </button>
                    )}
                    <button
                      onClick={() => {
                        if (window.confirm(`هل أنت متأكد من حذف العملية رقم ${tx.referenceNumber}؟`)) {
                          deleteTransaction(tx.id);
                        }
                      }}
                      className="p-1.5 rounded-lg text-slate-400 hover:text-rose-400 hover:bg-slate-800 transition"
                      title="حذف المعاملة"
                    >
                      <Trash2 className="w-4 h-4" />
                    </button>
                  </div>
                </div>
              </div>
            );
          })
        )}
      </div>

      {/* Desktop Table View (md and up) */}
      <div className="hidden md:block overflow-x-auto">
        <table className="w-full text-right text-sm">
          <thead>
            <tr className="border-b border-slate-800 text-slate-400 text-xs">
              <th className="pb-3 pr-2 font-semibold">رقم المرجع</th>
              <th className="pb-3 font-semibold">النوع</th>
              <th className="pb-3 font-semibold">التصنيف</th>
              <th className="pb-3 font-semibold">المحفظة</th>
              <th className="pb-3 font-semibold">المستلم / الوصف</th>
              <th className="pb-3 font-semibold">المبلغ</th>
              <th className="pb-3 font-semibold">العمولة</th>
              <th className="pb-3 font-semibold">التاريخ</th>
              <th className="pb-3 pl-2 text-center font-semibold">إجراءات</th>
            </tr>
          </thead>
          <tbody className="divide-y divide-slate-800/60 text-slate-200">
            {filtered.length === 0 ? (
              <tr>
                <td colSpan={9} className="py-8 text-center text-slate-400">
                  لا توجد عمليات تطابق البحث.
                </td>
              </tr>
            ) : (
              filtered.map((tx) => {
                const badge = getBadge(tx.type, tx.transferKind, tx.targetWalletName);
                return (
                  <tr key={tx.id} className="hover:bg-slate-800/40 transition">
                    <td className="py-3.5 pr-2 font-mono text-slate-400 text-xs">{tx.referenceNumber}</td>
                    <td className="py-3.5">
                      <span className={`inline-flex items-center gap-1.5 text-xs font-bold px-2.5 py-1 rounded-full border ${badge.color}`}>
                        {badge.icon}
                        {badge.label}
                      </span>
                    </td>
                    <td className="py-3.5">
                      <span className="inline-block px-2.5 py-1 rounded-lg text-xs font-semibold bg-slate-800 text-emerald-300 border border-slate-700">
                        {tx.category || 'عام'}
                      </span>
                    </td>
                    <td className="py-3.5 font-bold text-white">
                      {tx.walletName}
                      {tx.targetWalletName && (
                        <span className="text-slate-400 block text-xs font-normal">⇾ {tx.targetWalletName}</span>
                      )}
                    </td>
                    <td className="py-3.5 text-slate-300 text-xs">
                      {tx.recipientName || tx.recipientPhone ? (
                        <span>
                          {tx.recipientName} {tx.recipientPhone && `(${tx.recipientPhone})`}
                        </span>
                      ) : (
                        <span className="text-slate-400">{tx.notes || '—'}</span>
                      )}
                    </td>
                    <td className="py-3.5 font-mono text-base">
                      <span className={badge.amountColor}>
                        {badge.sign} {tx.amount.toLocaleString()} ج.م
                      </span>
                    </td>
                    <td className="py-3.5 font-mono text-slate-400 text-xs">{tx.fee > 0 ? `${tx.fee} ج.م` : '0'}</td>
                    <td className="py-3.5 text-slate-400 text-xs whitespace-nowrap">{formatDate(tx.date)}</td>
                    <td className="py-3.5 pl-2 text-center">
                      <div className="flex items-center justify-center gap-1">
                        {onEditTransaction && (
                          <button
                            onClick={() => onEditTransaction(tx)}
                            className="p-1.5 rounded-lg text-slate-400 hover:text-emerald-400 hover:bg-slate-800 transition"
                            title="تعديل المعاملة"
                          >
                            <Edit3 className="w-4 h-4" />
                          </button>
                        )}
                        <button
                          onClick={() => {
                            if (window.confirm(`هل تريد حذف المعاملة ${tx.referenceNumber}؟`)) {
                              deleteTransaction(tx.id);
                            }
                          }}
                          className="p-1.5 rounded-lg text-slate-400 hover:text-rose-400 hover:bg-slate-800 transition"
                          title="حذف المعاملة"
                        >
                          <Trash2 className="w-4 h-4" />
                        </button>
                      </div>
                    </td>
                  </tr>
                );
              })
            )}
          </tbody>
        </table>
      </div>
    </div>
  );
};
