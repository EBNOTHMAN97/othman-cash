import React, { useState } from 'react';
import { X, Smartphone, Download, ExternalLink, Copy, Check, ShieldCheck, Terminal, Sparkles, CheckCircle2 } from 'lucide-react';

interface ApkExportModalProps {
  isOpen: boolean;
  onClose: () => void;
}

export const ApkExportModal: React.FC<ApkExportModalProps> = ({ isOpen, onClose }) => {
  const [copiedUrl, setCopiedUrl] = useState(false);
  const [activeTab, setActiveTab] = useState<'instant' | 'capacitor'>('instant');

  if (!isOpen) return null;

  const currentAppUrl = typeof window !== 'undefined' ? window.location.origin : 'https://ais-pre-x2cv3r3uo2danxarpxsll2-374886728732.europe-west2.run.app';
  const pwaBuilderUrl = `https://www.pwabuilder.com/?site=${encodeURIComponent(currentAppUrl)}`;

  const handleCopyUrl = () => {
    navigator.clipboard.writeText(currentAppUrl);
    setCopiedUrl(true);
    setTimeout(() => setCopiedUrl(false), 2000);
  };

  return (
    <div className="fixed inset-0 z-50 flex items-center justify-center p-3 sm:p-4 bg-black/80 backdrop-blur-sm animate-fade-in">
      <div className="relative w-full max-w-xl rounded-3xl bg-[#1e293b] border border-slate-700 p-5 sm:p-7 shadow-2xl text-white max-h-[92vh] overflow-y-auto">
        {/* Close Button */}
        <button
          onClick={onClose}
          className="absolute left-4 top-4 p-2 text-slate-400 hover:text-white rounded-full bg-slate-800 hover:bg-slate-700 transition"
          aria-label="إغلاق"
        >
          <X className="w-5 h-5" />
        </button>

        {/* Header */}
        <div className="flex items-center gap-3.5 mb-5 pb-4 border-b border-slate-800">
          <div className="w-12 h-12 rounded-2xl bg-gradient-to-tr from-emerald-500 to-teal-400 flex items-center justify-center shadow-lg shadow-emerald-950/60 shrink-0">
            <Smartphone className="w-6 h-6 text-slate-900" />
          </div>
          <div>
            <div className="flex items-center gap-2">
              <h2 className="text-lg sm:text-xl font-black text-white">تحويل التطبيق إلى ملف APK للأندرويد</h2>
              <span className="text-[10px] font-bold px-2 py-0.5 rounded-full bg-emerald-500/20 text-emerald-400 border border-emerald-500/30">
                Android APK
              </span>
            </div>
            <p className="text-xs text-slate-400 mt-0.5">
              تثبيت ملف .apk مباشرة على أي هاتف أندرويد بدون متجر Google Play
            </p>
          </div>
        </div>

        {/* Tab Switcher */}
        <div className="grid grid-cols-2 gap-1.5 p-1 bg-slate-900 rounded-xl mb-5 text-xs sm:text-sm font-bold">
          <button
            onClick={() => setActiveTab('instant')}
            className={`py-2.5 rounded-lg transition flex items-center justify-center gap-2 ${
              activeTab === 'instant'
                ? 'bg-emerald-600 text-white shadow'
                : 'text-slate-400 hover:text-white'
            }`}
          >
            <Sparkles className="w-4 h-4 text-emerald-300" />
            <span>الطريقة الفورية السريعة (PWABuilder)</span>
          </button>
          <button
            onClick={() => setActiveTab('capacitor')}
            className={`py-2.5 rounded-lg transition flex items-center justify-center gap-2 ${
              activeTab === 'capacitor'
                ? 'bg-indigo-600 text-white shadow'
                : 'text-slate-400 hover:text-white'
            }`}
          >
            <Terminal className="w-4 h-4 text-indigo-300" />
            <span>مشروع أندرويد ستوديو (Capacitor)</span>
          </button>
        </div>

        {/* Method 1: Instant PWABuilder Flow */}
        {activeTab === 'instant' && (
          <div className="space-y-4 text-xs sm:text-sm">
            <div className="bg-slate-900/90 rounded-2xl p-4 border border-slate-800 space-y-3">
              <h3 className="font-bold text-emerald-400 text-sm flex items-center gap-2">
                <CheckCircle2 className="w-4 h-4" />
                <span>خطوات استخراج ملف APK الجاهز بنقرة واحدة:</span>
              </h3>

              <ol className="text-slate-300 space-y-2.5 pr-2 list-decimal list-inside leading-relaxed text-xs sm:text-sm">
                <li>
                  تم تجهيز ملفات تطبيقك بالكامل (المانيفست + الأيقونات + Service Worker) لتتوافق 100% مع معايير أندرويد الرسمية.
                </li>
                <li>
                  اضغط على زر <strong className="text-emerald-300">"توليد وتحميل APK الآن"</strong> أدناه، وسيتم فتح أداة مايكروسوفت وجوجل الرسمية (PWABuilder) مع وضع رابط تطبيقك تلقائياً.
                </li>
                <li>
                  في الصفحة التي ستفتح، اضغط على زر <strong className="text-white">"Package for Android"</strong>.
                </li>
                <li>
                  اختر <strong className="text-emerald-400">"Download APK"</strong> لتنزيل الملف مباشرة بصيغة <code className="bg-slate-800 px-1.5 py-0.5 rounded font-mono text-white">.apk</code>.
                </li>
                <li>
                  أرسل الملف لهاتفك وثبّته مباشرة واستمتع بالتطبيق بكامل وظائفه!
                </li>
              </ol>
            </div>

            {/* App URL Container with Copy */}
            <div className="bg-slate-900/80 rounded-xl p-3 border border-slate-800 flex items-center justify-between gap-2">
              <div className="overflow-hidden">
                <span className="text-[11px] text-slate-400 block mb-0.5">رابط التطبيق المستخدم لتوليد الـ APK:</span>
                <span className="text-xs font-mono text-emerald-300 truncate block dir-ltr select-all">
                  {currentAppUrl}
                </span>
              </div>
              <button
                onClick={handleCopyUrl}
                className="p-2 rounded-lg bg-slate-800 hover:bg-slate-700 text-slate-300 transition shrink-0"
                title="نسخ الرابط"
              >
                {copiedUrl ? <Check className="w-4 h-4 text-emerald-400" /> : <Copy className="w-4 h-4" />}
              </button>
            </div>

            {/* Direct Open Button */}
            <a
              href={pwaBuilderUrl}
              target="_blank"
              rel="noopener noreferrer"
              className="w-full py-3.5 px-4 rounded-xl bg-gradient-to-r from-emerald-600 to-teal-500 hover:from-emerald-500 hover:to-teal-400 text-white font-black text-sm sm:text-base shadow-lg shadow-emerald-950/60 transition active:scale-[0.98] flex items-center justify-center gap-2 no-underline text-center"
            >
              <Download className="w-5 h-5" />
              <span>توليد وتحميل ملف الـ APK الآن (PWABuilder)</span>
              <ExternalLink className="w-4 h-4 mr-1" />
            </a>
          </div>
        )}

        {/* Method 2: Capacitor Project Flow */}
        {activeTab === 'capacitor' && (
          <div className="space-y-4 text-xs sm:text-sm">
            <div className="bg-slate-900/90 rounded-2xl p-4 border border-slate-800 space-y-3">
              <h3 className="font-bold text-indigo-400 text-sm flex items-center gap-2">
                <Terminal className="w-4 h-4" />
                <span>بناء APK محلياً باستخدام Android Studio & Capacitor:</span>
              </h3>
              <p className="text-slate-300 text-xs leading-relaxed">
                تم تثبيت وإعداد مكتبة <code className="text-emerald-400 font-mono">@capacitor/core</code> وملف <code className="text-emerald-400 font-mono">capacitor.config.ts</code> بالفعل داخل هذا المشروع.
              </p>

              <div className="bg-black/60 rounded-xl p-3 font-mono text-xs text-slate-200 space-y-2 border border-slate-800 dir-ltr text-left overflow-x-auto">
                <div className="text-slate-500"># 1. تثبيت حزمة أندرويد وتوليد المشروع</div>
                <div>npx cap add android</div>
                <div className="text-slate-500 mt-2"># 2. مزامنة كود التطبيق مع أندرويد</div>
                <div>npm run build && npx cap sync android</div>
                <div className="text-slate-500 mt-2"># 3. فتح المشروع وبناء APK</div>
                <div>npx cap open android</div>
              </div>

              <p className="text-xs text-slate-400">
                في برنامج أندرويد ستوديو، اضغط على <strong>Build &gt; Build Bundle(s) / APK(s) &gt; Build APK(s)</strong> وستحصل على ملف الـ APK النهائي.
              </p>
            </div>
          </div>
        )}

        {/* Footer info */}
        <div className="mt-5 pt-3.5 border-t border-slate-800 flex items-center justify-between text-xs text-slate-400">
          <div className="flex items-center gap-1.5 text-emerald-400 font-medium">
            <ShieldCheck className="w-4 h-4" />
            <span>تطبيق آمن ومرخص لنظام Android 8.0 وحتى Android 15</span>
          </div>
          <button
            onClick={onClose}
            className="px-4 py-1.5 rounded-lg bg-slate-800 hover:bg-slate-700 text-slate-200 font-semibold"
          >
            إغلاق
          </button>
        </div>
      </div>
    </div>
  );
};
