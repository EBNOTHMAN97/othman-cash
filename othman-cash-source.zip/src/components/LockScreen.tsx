import React, { useState, useRef, useEffect } from 'react';
import { ShieldCheck, Eye, EyeOff, LogIn, KeyRound, Delete, RotateCcw } from 'lucide-react';
import { useFinancial } from '../context/FinancialContext';

export const LockScreen: React.FC = () => {
  const { isLocked, unlockApp, pinCode } = useFinancial();
  const [pinInput, setPinInput] = useState<string>('');
  const [showPin, setShowPin] = useState<boolean>(false);
  const [hasError, setHasError] = useState<boolean>(false);
  const inputRef = useRef<HTMLInputElement>(null);

  useEffect(() => {
    if (isLocked) {
      setPinInput('');
      setHasError(false);
      const timer = setTimeout(() => {
        inputRef.current?.focus();
      }, 150);
      return () => clearTimeout(timer);
    }
  }, [isLocked]);

  if (!isLocked) return null;

  const tryUnlock = (candidate: string) => {
    if (!candidate) return;
    const ok = unlockApp(candidate);
    if (!ok) {
      setHasError(true);
      setTimeout(() => {
        setHasError(false);
      }, 2500);
    } else {
      setPinInput('');
      setHasError(false);
    }
  };

  const handleInputChange = (val: string) => {
    setPinInput(val);
    if (hasError) setHasError(false);
    // Instant unlock when typing matches pinCode
    if (val === pinCode) {
      tryUnlock(val);
    }
  };

  const handleKeypadPress = (digit: string) => {
    const nextVal = pinInput + digit;
    handleInputChange(nextVal);
  };

  const handleBackspace = () => {
    if (pinInput.length > 0) {
      const nextVal = pinInput.slice(0, -1);
      setPinInput(nextVal);
      if (hasError) setHasError(false);
    }
  };

  const handleClear = () => {
    setPinInput('');
    if (hasError) setHasError(false);
  };

  const handleSubmit = (e: React.FormEvent) => {
    e.preventDefault();
    tryUnlock(pinInput);
  };

  return (
    <div className="fixed inset-0 z-50 bg-[#0f172a] flex flex-col items-center justify-center p-4 sm:p-6 text-white select-none animate-fade-in overflow-y-auto">
      {/* Background glow accents */}
      <div className="absolute top-1/4 left-1/2 -translate-x-1/2 w-96 h-96 bg-emerald-500/10 rounded-full blur-3xl pointer-events-none" />

      <div className="relative w-full max-w-sm rounded-3xl bg-[#1e293b]/95 border border-slate-700/80 p-6 sm:p-7 shadow-2xl text-center flex flex-col items-center my-auto backdrop-blur-md">
        {/* App Logo */}
        <div className="relative mb-3.5">
          <img
            src="/pwa-192x192.png"
            alt="عثمان كاش"
            className="w-18 h-18 sm:w-20 sm:h-20 rounded-2xl shadow-xl border border-emerald-500/40 object-cover"
          />
          <span className="absolute -bottom-1 -left-1 p-1.5 rounded-full bg-emerald-500 text-slate-900 shadow">
            <KeyRound className="w-4 h-4" />
          </span>
        </div>

        <h1 className="text-xl sm:text-2xl font-black text-white mb-1">عثمان كاش</h1>
        <p className="text-xs text-slate-400 mb-4">
          أدخل الرقم السري (PIN) لفتح البرنامج
        </p>

        {/* Input Field with Eye Toggle */}
        <form onSubmit={handleSubmit} className="w-full space-y-3.5">
          <div className="relative">
            <input
              ref={inputRef}
              type={showPin ? 'text' : 'password'}
              inputMode="numeric"
              autoFocus
              placeholder="اكتب الرقم السري هنا..."
              value={pinInput}
              onChange={(e) => handleInputChange(e.target.value)}
              className={`w-full bg-slate-900/90 border rounded-2xl px-4 py-3 pl-12 text-center text-white font-mono text-xl font-bold tracking-wider focus:outline-none transition ${
                hasError
                  ? 'border-rose-500 ring-2 ring-rose-500/20 animate-shake'
                  : 'border-slate-700 focus:border-emerald-500 focus:ring-2 focus:ring-emerald-500/20'
              }`}
            />

            {/* Toggle show/hide PIN */}
            <button
              type="button"
              onClick={() => setShowPin(!showPin)}
              className="absolute left-3 top-1/2 -translate-y-1/2 p-2 text-slate-400 hover:text-emerald-400 hover:bg-slate-800 rounded-xl transition"
              title={showPin ? 'إخفاء الرمز السري' : 'إظهار الرمز السري'}
              aria-label={showPin ? 'إخفاء الرمز السري' : 'إظهار الرمز السري'}
            >
              {showPin ? <EyeOff className="w-4 h-4 text-emerald-400" /> : <Eye className="w-4 h-4" />}
            </button>
          </div>

          {hasError && (
            <p className="text-xs text-rose-400 font-semibold animate-fade-in">
              الرمز السري غير صحيح. يرجى التأكد وإعادة المحاولة.
            </p>
          )}

          {/* Touch Number Pad for Phone / Tablet / Desktop */}
          <div className="grid grid-cols-3 gap-2 pt-1" dir="ltr">
            {['1', '2', '3', '4', '5', '6', '7', '8', '9'].map((digit) => (
              <button
                key={digit}
                type="button"
                onClick={() => handleKeypadPress(digit)}
                className="py-3 rounded-xl bg-slate-900/80 hover:bg-slate-800 text-white font-bold text-lg font-mono border border-slate-800 hover:border-slate-700 active:scale-95 transition shadow-sm"
              >
                {digit}
              </button>
            ))}
            <button
              type="button"
              onClick={handleClear}
              className="py-3 rounded-xl bg-slate-900/40 hover:bg-slate-800 text-slate-400 hover:text-slate-200 text-xs font-bold border border-slate-800 active:scale-95 transition flex items-center justify-center gap-1"
              title="مسح الكل"
            >
              <RotateCcw className="w-4 h-4" />
            </button>
            <button
              type="button"
              onClick={() => handleKeypadPress('0')}
              className="py-3 rounded-xl bg-slate-900/80 hover:bg-slate-800 text-white font-bold text-lg font-mono border border-slate-800 hover:border-slate-700 active:scale-95 transition shadow-sm"
            >
              0
            </button>
            <button
              type="button"
              onClick={handleBackspace}
              className="py-3 rounded-xl bg-slate-900/40 hover:bg-slate-800 text-slate-400 hover:text-rose-400 text-xs font-bold border border-slate-800 active:scale-95 transition flex items-center justify-center gap-1"
              title="حذف رقم"
            >
              <Delete className="w-4 h-4" />
            </button>
          </div>

          <button
            type="submit"
            className="w-full py-3 px-4 rounded-xl bg-gradient-to-r from-emerald-600 to-teal-500 hover:from-emerald-500 hover:to-teal-400 text-white font-bold text-sm shadow-lg shadow-emerald-950/60 transition active:scale-[0.98] flex items-center justify-center gap-2"
          >
            <LogIn className="w-4 h-4" />
            <span>تأكيد وفتح التطبيق</span>
          </button>
        </form>

        {/* Default PIN reminder if still 1234 */}
        {pinCode === '1234' && (
          <div className="mt-3.5 px-3 py-1.5 rounded-xl bg-slate-900/70 border border-slate-800 text-[11px] text-slate-400">
            الرمز الافتراضي للتطبيق: <strong className="text-emerald-400 font-mono">1234</strong>
          </div>
        )}

        <p className="text-[11px] text-slate-400 flex items-center gap-1.5 mt-4">
          <ShieldCheck className="w-3.5 h-3.5 text-emerald-400" />
          <span>حماية مشفرة • يمكنك تغيير الرمز من صفحة الإعدادات</span>
        </p>
      </div>
    </div>
  );
};
