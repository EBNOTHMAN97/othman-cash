import React, { useState, useRef, useEffect } from 'react';
import { ShieldCheck, Eye, EyeOff, LogIn, KeyRound } from 'lucide-react';
import { useFinancial } from '../context/FinancialContext';

export const LockScreen: React.FC = () => {
  const { isLocked, unlockApp } = useFinancial();
  const [pinInput, setPinInput] = useState<string>('');
  const [showPin, setShowPin] = useState<boolean>(false);
  const [hasError, setHasError] = useState<boolean>(false);
  const inputRef = useRef<HTMLInputElement>(null);

  useEffect(() => {
    if (isLocked) {
      setPinInput('');
      setHasError(false);
      // Auto focus the device keyboard
      const timer = setTimeout(() => {
        inputRef.current?.focus();
      }, 150);
      return () => clearTimeout(timer);
    }
  }, [isLocked]);

  if (!isLocked) return null;

  const handleSubmit = (e: React.FormEvent) => {
    e.preventDefault();
    if (!pinInput) return;

    const ok = unlockApp(pinInput);
    if (!ok) {
      setHasError(true);
      setTimeout(() => {
        setHasError(false);
      }, 2500);
    } else {
      setPinInput('');
      setHasError(false);
    }
  };

  return (
    <div className="fixed inset-0 z-50 bg-[#101827] flex flex-col items-center justify-center p-4 sm:p-6 text-white select-none animate-fade-in">
      <div className="w-full max-w-sm rounded-3xl bg-[#1e293b]/90 border border-slate-700/80 p-6 sm:p-8 shadow-2xl text-center flex flex-col items-center">
        {/* App Logo */}
        <div className="relative mb-4">
          <img
            src="/pwa-192x192.png"
            alt="عثمان كاش"
            className="w-20 h-20 rounded-2xl shadow-xl border border-emerald-500/40 object-cover"
          />
          <span className="absolute -bottom-1 -left-1 p-1.5 rounded-full bg-emerald-500 text-slate-900 shadow">
            <KeyRound className="w-4 h-4" />
          </span>
        </div>

        <h1 className="text-xl sm:text-2xl font-black text-white mb-1">عثمان كاش</h1>
        <p className="text-xs sm:text-sm text-slate-400 mb-6">
          أدخل الرمز السري من كيبورد جهازك لفتح التطبيق
        </p>

        {/* Native Keyboard Form */}
        <form onSubmit={handleSubmit} className="w-full space-y-4">
          <div className="relative">
            <input
              ref={inputRef}
              type={showPin ? 'text' : 'password'}
              inputMode="numeric"
              autoFocus
              placeholder="اكتب الرقم السري هنا..."
              value={pinInput}
              onChange={(e) => {
                setPinInput(e.target.value);
                if (hasError) setHasError(false);
              }}
              className={`w-full bg-slate-900 border rounded-2xl px-4 py-3.5 pl-12 text-center text-white font-mono text-xl font-bold tracking-wider focus:outline-none transition ${
                hasError
                  ? 'border-rose-500 ring-2 ring-rose-500/20 animate-shake'
                  : 'border-slate-700 focus:border-emerald-500 focus:ring-2 focus:ring-emerald-500/20'
              }`}
            />

            {/* Toggle show/hide PIN */}
            <button
              type="button"
              onClick={() => setShowPin(!showPin)}
              className="absolute left-3.5 top-1/2 -translate-y-1/2 p-1.5 text-slate-400 hover:text-emerald-400 hover:bg-slate-800 rounded-lg transition"
              title={showPin ? 'إخفاء الرمز السري' : 'إظهار الرمز السري'}
              aria-label={showPin ? 'إخفاء الرمز السري' : 'إظهار الرمز السري'}
            >
              {showPin ? <EyeOff className="w-5 h-5 text-emerald-400" /> : <Eye className="w-5 h-5" />}
            </button>
          </div>

          {hasError && (
            <p className="text-xs text-rose-400 font-semibold animate-fade-in">
              الرمز السري غير صحيح. يرجى التأكد وإعادة المحاولة.
            </p>
          )}

          <button
            type="submit"
            className="w-full py-3.5 px-4 rounded-2xl bg-gradient-to-r from-emerald-600 to-teal-500 hover:from-emerald-500 hover:to-teal-400 text-white font-bold text-sm sm:text-base shadow-lg shadow-emerald-950/60 transition active:scale-[0.98] flex items-center justify-center gap-2"
          >
            <LogIn className="w-5 h-5" />
            <span>تأكيد وفتح التطبيق</span>
          </button>
        </form>

        <p className="text-[11px] text-slate-400 flex items-center gap-1.5 mt-6">
          <ShieldCheck className="w-3.5 h-3.5 text-emerald-400" />
          <span>تشفير آمن • يدعم أي عدد من الأرقام</span>
        </p>
      </div>
    </div>
  );
};
