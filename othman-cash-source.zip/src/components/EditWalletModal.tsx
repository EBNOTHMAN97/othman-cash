import React, { useState, useEffect } from 'react';
import { X, Save, Trash2, AlertTriangle, CheckCircle2 } from 'lucide-react';
import { Wallet, WalletProvider } from '../types';

interface EditWalletModalProps {
  isOpen: boolean;
  wallet: Wallet | null;
  onClose: () => void;
  onSave: (updatedWallet: Wallet) => void;
  onDelete: (walletId: string) => void;
}

export const EditWalletModal: React.FC<EditWalletModalProps> = ({
  isOpen,
  wallet,
  onClose,
  onSave,
  onDelete,
}) => {
  const [name, setName] = useState('');
  const [provider, setProvider] = useState<WalletProvider>('vodafone');
  const [accountNumber, setAccountNumber] = useState('');
  const [balance, setBalance] = useState('');
  const [dailyLimit, setDailyLimit] = useState('');
  const [monthlyLimit, setMonthlyLimit] = useState('');
  const [isActive, setIsActive] = useState(true);
  const [note, setNote] = useState('');
  const [confirmDelete, setConfirmDelete] = useState(false);

  useEffect(() => {
    if (wallet) {
      setName(wallet.name);
      setProvider(wallet.provider);
      setAccountNumber(wallet.accountNumber);
      setBalance(wallet.balance.toString());
      setDailyLimit(wallet.dailyLimit.toString());
      setMonthlyLimit(wallet.monthlyLimit.toString());
      setIsActive(wallet.isActive);
      setNote(wallet.note || '');
      setConfirmDelete(false);
    }
  }, [wallet]);

  if (!isOpen || !wallet) return null;

  const handleSubmit = (e: React.FormEvent) => {
    e.preventDefault();
    if (!name.trim() || !accountNumber.trim()) return;

    const getColorForProvider = (p: WalletProvider) => {
      switch (p) {
        case 'vodafone': return '#e60000';
        case 'orange': return '#ff7900';
        case 'etisalat': return '#009639';
        case 'instapay': return '#7c3aed';
        case 'accesspay': return '#0ea5e9';
        case 'cash_vault': return '#10b981';
        case 'nbe': return '#0284c7';
        case 'bank_misr': return '#f59e0b';
        default: return '#10b981';
      }
    };

    onSave({
      ...wallet,
      name,
      provider,
      accountNumber,
      balance: parseFloat(balance) || 0,
      dailyLimit: parseFloat(dailyLimit) || wallet.dailyLimit,
      monthlyLimit: parseFloat(monthlyLimit) || wallet.monthlyLimit,
      isActive,
      note,
      color: getColorForProvider(provider),
      lastUpdated: new Date().toISOString(),
    });
    onClose();
  };

  const handleDelete = () => {
    if (confirmDelete) {
      onDelete(wallet.id);
      onClose();
    } else {
      setConfirmDelete(true);
    }
  };

  return (
    <div className="fixed inset-0 z-50 flex items-center justify-center p-3 sm:p-4 bg-black/80 backdrop-blur-sm animate-fade-in">
      <div className="relative w-full max-w-lg rounded-2xl bg-[#1e293b] border border-slate-700 p-5 sm:p-6 shadow-2xl text-white max-h-[90vh] overflow-y-auto">
        <button
          onClick={onClose}
          className="absolute left-4 top-4 p-2 text-slate-400 hover:text-white rounded-full bg-slate-800 hover:bg-slate-700 transition"
        >
          <X className="w-5 h-5" />
        </button>

        <h2 className="text-lg sm:text-xl font-bold mb-4 flex items-center gap-2">
          <span>تعديل بيانات المحفظة</span>
        </h2>

        <form onSubmit={handleSubmit} className="space-y-4 text-xs sm:text-sm">
          <div>
            <label className="block text-slate-300 font-semibold mb-1">اسم المحفظة *</label>
            <input
              type="text"
              required
              value={name}
              onChange={(e) => setName(e.target.value)}
              className="w-full bg-slate-900 border border-slate-700 rounded-xl px-3 py-2.5 text-white focus:outline-none focus:border-emerald-500 text-sm font-semibold"
            />
          </div>

          <div className="grid grid-cols-1 sm:grid-cols-2 gap-3">
            <div>
              <label className="block text-slate-300 font-semibold mb-1">مقدم الخدمة *</label>
              <select
                value={provider}
                onChange={(e) => setProvider(e.target.value as WalletProvider)}
                className="w-full bg-slate-900 border border-slate-700 rounded-xl px-3 py-2.5 text-white focus:outline-none focus:border-emerald-500 text-sm"
              >
                <option value="accesspay">أكسس باي (Access Pay)</option>
                <option value="vodafone">فودافون كاش</option>
                <option value="orange">أورنج كاش</option>
                <option value="etisalat">اتصالات كاش</option>
                <option value="instapay">إنستاباي (InstaPay)</option>
                <option value="cash_vault">خزينة نقدية (كاش يدوي)</option>
                <option value="bank_misr">بنك مصر</option>
                <option value="nbe">البنك الأهلي المصري</option>
              </select>
            </div>

            <div>
              <label className="block text-slate-300 font-semibold mb-1">رقم الهاتف أو الحساب *</label>
              <input
                type="text"
                required
                value={accountNumber}
                onChange={(e) => setAccountNumber(e.target.value)}
                className="w-full bg-slate-900 border border-slate-700 rounded-xl px-3 py-2.5 text-white focus:outline-none focus:border-emerald-500 text-sm font-mono"
              />
            </div>
          </div>

          <div className="grid grid-cols-1 sm:grid-cols-3 gap-3">
            <div>
              <label className="block text-slate-300 font-semibold mb-1">الرصيد الحالي (ج.م)</label>
              <input
                type="number"
                step="any"
                value={balance}
                onChange={(e) => setBalance(e.target.value)}
                className="w-full bg-slate-900 border border-slate-700 rounded-xl px-3 py-2.5 text-emerald-300 font-bold font-mono focus:outline-none focus:border-emerald-500 text-sm"
              />
            </div>

            <div>
              <label className="block text-slate-300 font-semibold mb-1">الليمات اليومي (ج.م)</label>
              <input
                type="number"
                value={dailyLimit}
                onChange={(e) => setDailyLimit(e.target.value)}
                className="w-full bg-slate-900 border border-slate-700 rounded-xl px-3 py-2.5 text-amber-300 font-bold font-mono focus:outline-none focus:border-amber-500 text-sm"
              />
            </div>

            <div>
              <label className="block text-slate-300 font-semibold mb-1">الليمات الشهري (ج.م)</label>
              <input
                type="number"
                value={monthlyLimit}
                onChange={(e) => setMonthlyLimit(e.target.value)}
                className="w-full bg-slate-900 border border-slate-700 rounded-xl px-3 py-2.5 text-indigo-300 font-bold font-mono focus:outline-none focus:border-indigo-500 text-sm"
              />
            </div>
          </div>

          <div>
            <label className="block text-slate-300 font-semibold mb-1">ملاحظات المحفظة</label>
            <input
              type="text"
              value={note}
              onChange={(e) => setNote(e.target.value)}
              placeholder="وصف أو ملاحظة داخلية..."
              className="w-full bg-slate-900 border border-slate-700 rounded-xl px-3 py-2 text-white focus:outline-none focus:border-emerald-500 text-xs sm:text-sm"
            />
          </div>

          <div className="flex items-center gap-2 pt-1">
            <input
              type="checkbox"
              id="isActiveWallet"
              checked={isActive}
              onChange={(e) => setIsActive(e.target.checked)}
              className="w-4 h-4 rounded text-emerald-600 bg-slate-900 border-slate-700"
            />
            <label htmlFor="isActiveWallet" className="text-xs sm:text-sm text-slate-200 cursor-pointer">
              المحفظة نشطة وتستقبل عمليات
            </label>
          </div>

          <div className="pt-4 border-t border-slate-800 flex flex-col sm:flex-row items-center justify-between gap-3">
            <button
              type="button"
              onClick={handleDelete}
              className={`w-full sm:w-auto px-4 py-2.5 rounded-xl font-bold text-xs flex items-center justify-center gap-1.5 transition ${
                confirmDelete
                  ? 'bg-rose-700 text-white animate-pulse'
                  : 'bg-rose-950/60 text-rose-300 border border-rose-600/40 hover:bg-rose-900/60'
              }`}
            >
              <Trash2 className="w-4 h-4" />
              <span>{confirmDelete ? 'تأكيد مسح المحفظة الآن!' : 'مسح المحفظة'}</span>
            </button>

            <div className="flex items-center gap-2 w-full sm:w-auto">
              <button
                type="button"
                onClick={onClose}
                className="flex-1 sm:flex-none px-4 py-2.5 rounded-xl bg-slate-800 hover:bg-slate-700 text-slate-300 font-semibold text-xs sm:text-sm transition"
              >
                إلغاء
              </button>
              <button
                type="submit"
                className="flex-1 sm:flex-none px-5 py-2.5 rounded-xl bg-emerald-600 hover:bg-emerald-500 text-white font-bold text-xs sm:text-sm shadow-md transition flex items-center justify-center gap-1.5"
              >
                <Save className="w-4 h-4" />
                <span>حفظ التعديلات</span>
              </button>
            </div>
          </div>
        </form>
      </div>
    </div>
  );
};
