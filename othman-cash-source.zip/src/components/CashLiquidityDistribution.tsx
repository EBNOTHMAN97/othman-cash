import React from 'react';
import { PieChart, Wallet as WalletIcon, Layers } from 'lucide-react';
import { useFinancial } from '../context/FinancialContext';

export const CashLiquidityDistribution: React.FC = () => {
  const { wallets, totalBalance } = useFinancial();

  return (
    <div className="rounded-2xl bg-[#1e293b]/95 border border-slate-700/80 p-4 sm:p-6 shadow-xl">
      {/* Header and Total Cash Display */}
      <div className="flex flex-col sm:flex-row sm:items-center justify-between gap-3 mb-5 pb-4 border-b border-slate-800">
        <div>
          <h2 className="text-lg sm:text-xl font-bold text-white flex items-center gap-2">
            <PieChart className="w-5 h-5 text-emerald-400" />
            <span>توزيع السيولة النقدية بين المحافظ</span>
          </h2>
          <p className="text-xs sm:text-sm text-slate-400 mt-0.5">
            حجم ونسبة الأرصدة المتوفرة في كل محفظة من إجمالي السيولة
          </p>
        </div>

        {/* Total Liquidity Highlight */}
        <div className="bg-gradient-to-r from-emerald-950/70 to-slate-900 border border-emerald-500/40 px-4 py-2.5 rounded-2xl flex items-center gap-3">
          <div className="p-2 rounded-xl bg-emerald-500/20 text-emerald-400">
            <WalletIcon className="w-5 h-5" />
          </div>
          <div>
            <span className="text-[11px] sm:text-xs text-slate-300 block font-medium">إجمالي السيولة النقدية</span>
            <div className="flex items-baseline gap-1">
              <span className="text-xl sm:text-2xl font-black text-white font-mono tracking-tight">
                {totalBalance.toLocaleString()}
              </span>
              <span className="text-xs sm:text-sm font-bold text-emerald-400">ج.م</span>
            </div>
          </div>
        </div>
      </div>

      {/* Stacked Multi-Color Master Bar */}
      {totalBalance > 0 && (
        <div className="mb-5">
          <div className="w-full h-4 rounded-xl overflow-hidden flex shadow-inner bg-slate-900 border border-slate-800">
            {wallets.map((w) => {
              const share = (w.balance / totalBalance) * 100;
              if (share <= 0) return null;
              return (
                <div
                  key={w.id}
                  className="h-full transition-all duration-500 hover:opacity-90"
                  style={{
                    width: `${share}%`,
                    backgroundColor: w.color || '#10b981',
                  }}
                  title={`${w.name}: ${w.balance.toLocaleString()} ج.م (${share.toFixed(1)}%)`}
                />
              );
            })}
          </div>
        </div>
      )}

      {/* Grid of Individual Wallet Distribution Items */}
      <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-3 gap-3.5">
        {wallets.map((wallet) => {
          const share = totalBalance > 0 ? ((wallet.balance / totalBalance) * 100).toFixed(1) : '0';

          return (
            <div
              key={wallet.id}
              className="rounded-xl bg-slate-900/80 border border-slate-800/90 p-3.5 sm:p-4 hover:border-slate-700 transition"
            >
              <div className="flex items-center justify-between gap-2 mb-2">
                <div className="flex items-center gap-2">
                  <span
                    className="w-3.5 h-3.5 rounded-full shrink-0 shadow-sm"
                    style={{ backgroundColor: wallet.color || '#10b981' }}
                  />
                  <span className="font-bold text-sm sm:text-base text-white line-clamp-1">
                    {wallet.name}
                  </span>
                </div>
                <span className="font-mono text-xs sm:text-sm font-extrabold px-2 py-0.5 rounded-lg bg-slate-800 text-slate-200 border border-slate-700">
                  {share}%
                </span>
              </div>

              {/* Progress Line */}
              <div className="w-full bg-slate-800 h-2 rounded-full overflow-hidden mb-2">
                <div
                  className="h-full rounded-full transition-all duration-500"
                  style={{
                    width: `${share}%`,
                    backgroundColor: wallet.color || '#10b981',
                  }}
                />
              </div>

              <div className="flex justify-between items-center text-xs sm:text-sm text-slate-400">
                <span>الرصيد المتوفر:</span>
                <span className="font-mono font-black text-white text-sm sm:text-base">
                  {wallet.balance.toLocaleString()} <span className="text-xs text-emerald-400 font-bold">ج.م</span>
                </span>
              </div>
            </div>
          );
        })}
      </div>
    </div>
  );
};
