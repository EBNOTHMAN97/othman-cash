import React from 'react';
import { Bell, Lock, Wifi, WifiOff } from 'lucide-react';
import { useOnlineStatus } from '../hooks/useOnlineStatus';
import { useFinancial } from '../context/FinancialContext';

interface HeaderProps {
  onOpenNotifications: () => void;
}

export const Header: React.FC<HeaderProps> = ({
  onOpenNotifications,
}) => {
  const isOnline = useOnlineStatus();
  const { unreadNotificationsCount, lockApp } = useFinancial();

  return (
    <header className="sticky top-0 z-30 bg-[#101827]/95 backdrop-blur-md border-b border-slate-800/90 pt-[env(safe-area-inset-top,0px)] transition-all">
      <div className="max-w-7xl mx-auto px-4 sm:px-6 h-16 sm:h-[4.25rem] flex items-center justify-between gap-3 sm:gap-4">
        {/* Brand Logo & Name */}
        <div className="flex items-center gap-3 min-w-0">
          <div className="relative shrink-0 flex items-center justify-center">
            <img
              src="/pwa-192x192.png"
              alt="عثمان كاش"
              className="w-10 h-10 sm:w-11 sm:h-11 rounded-xl shadow-md border border-emerald-500/30 object-cover"
            />
            {/* Live connectivity dot */}
            <span
              className={`absolute -bottom-0.5 -left-0.5 w-3 h-3 rounded-full border-2 border-[#101827] ${
                isOnline ? 'bg-emerald-500 animate-pulse' : 'bg-red-500'
              }`}
              title={isOnline ? 'متصل بالإنترنت' : 'غير متصل'}
            />
          </div>

          <div className="flex flex-col justify-center min-w-0">
            {/* Othman Wallet في سطر واحد */}
            <h1 className="text-lg sm:text-xl font-bold text-white tracking-wide leading-tight whitespace-nowrap">
              Othman Wallet
            </h1>
            {/* إدارة المحافظ تحتها بتناسق */}
            <span className="text-xs sm:text-[13px] text-emerald-400 font-medium whitespace-nowrap leading-tight mt-0.5 block">
              إدارة المحافظ
            </span>
          </div>
        </div>

        {/* Action Controls: متناسقة الحجم والأبعاد بالكامل */}
        <div className="flex items-center gap-2 sm:gap-2.5 shrink-0">
          {/* Online/Offline status badge (Desktop) */}
          <div
            className={`hidden md:flex items-center gap-1.5 px-3 h-9 rounded-full text-xs font-semibold border ${
              isOnline
                ? 'bg-emerald-950/40 text-emerald-300 border-emerald-500/30'
                : 'bg-red-950/50 text-red-300 border-red-500/40 animate-pulse'
            }`}
          >
            {isOnline ? (
              <>
                <Wifi className="w-3.5 h-3.5 text-emerald-400" />
                <span>متصل بالخادم</span>
              </>
            ) : (
              <>
                <WifiOff className="w-3.5 h-3.5 text-red-400" />
                <span>غير متصل</span>
              </>
            )}
          </div>

          {/* Notifications Bell */}
          <button
            onClick={onOpenNotifications}
            className="relative w-10 h-10 sm:w-10.5 sm:h-10.5 flex items-center justify-center rounded-xl bg-slate-800/90 hover:bg-slate-700/90 border border-slate-700/80 text-slate-200 hover:text-white transition active:scale-95 shadow-sm"
            aria-label="الإشعارات"
            title="الإشعارات والتنبيهات"
          >
            <Bell className="w-5 h-5" />
            {unreadNotificationsCount > 0 && (
              <span className="absolute -top-1 -right-1 flex h-4 min-w-4 px-1 items-center justify-center rounded-full bg-rose-500 text-[10px] font-bold text-white shadow-sm animate-pulse">
                {unreadNotificationsCount}
              </span>
            )}
          </button>

          {/* Lock App */}
          <button
            onClick={lockApp}
            className="w-10 h-10 sm:w-10.5 sm:h-10.5 flex items-center justify-center rounded-xl bg-slate-800/90 hover:bg-slate-700/90 border border-slate-700/80 text-amber-400 hover:text-amber-300 transition active:scale-95 shadow-sm"
            title="قفل التطبيق برقم سري"
            aria-label="قفل"
          >
            <Lock className="w-5 h-5 text-amber-400" />
          </button>
        </div>
      </div>
    </header>
  );
};

