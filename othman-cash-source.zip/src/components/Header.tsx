import React from 'react';
import { Download, Bell, Lock, Wifi, WifiOff, Smartphone, Check } from 'lucide-react';
import { useOnlineStatus } from '../hooks/useOnlineStatus';
import { useFinancial } from '../context/FinancialContext';

interface HeaderProps {
  onOpenInstall: () => void;
  onOpenNotifications: () => void;
  onOpenApkModal?: () => void;
  isInstallable: boolean;
  isStandalone: boolean;
  isIOS: boolean;
}

export const Header: React.FC<HeaderProps> = ({
  onOpenInstall,
  onOpenNotifications,
  onOpenApkModal,
  isInstallable,
  isStandalone,
  isIOS,
}) => {
  const isOnline = useOnlineStatus();
  const { unreadNotificationsCount, lockApp } = useFinancial();

  return (
    <header className="sticky top-0 z-30 bg-[#101827]/95 backdrop-blur-md border-b border-slate-800 pt-[max(0.625rem,env(safe-area-inset-top))] sm:pt-2 transition-all">
      <div className="max-w-7xl mx-auto px-4 pt-2.5 pb-3 sm:pt-3 sm:pb-3.5 flex items-center justify-between gap-3">
        {/* Brand Logo & Name */}
        <div className="flex items-center gap-3">
          <div className="relative">
            <img
              src="/pwa-192x192.png"
              alt="عثمان كاش"
              className="w-10 h-10 sm:w-11 sm:h-11 rounded-xl shadow-md border border-emerald-500/30 object-cover"
            />
            {/* Live connectivity dot */}
            <span
              className={`absolute -bottom-1 -left-1 w-3.5 h-3.5 rounded-full border-2 border-[#101827] ${
                isOnline ? 'bg-emerald-500 animate-pulse' : 'bg-red-500'
              }`}
              title={isOnline ? 'متصل بالإنترنت' : 'غير متصل'}
            />
          </div>

          <div>
            <div className="flex items-center gap-2">
              <h1 className="text-base sm:text-lg font-black text-white tracking-tight">عثمان كاش</h1>
              <span className="hidden xs:inline-block text-[10px] font-bold px-1.5 py-0.5 rounded bg-emerald-500/10 text-emerald-400 border border-emerald-500/20">
                PWA
              </span>
            </div>
            <p className="text-[11px] text-slate-400 leading-none">إدارة المحافظ والسيولة النقدية</p>
          </div>
        </div>

        {/* Action Controls */}
        <div className="flex items-center gap-2 sm:gap-3">
          {/* Online/Offline status badge */}
          <div
            className={`hidden md:flex items-center gap-1.5 px-2.5 py-1 rounded-full text-xs font-medium border ${
              isOnline
                ? 'bg-emerald-950/40 text-emerald-300 border-emerald-500/30'
                : 'bg-red-950/50 text-red-300 border-red-500/40 animate-pulse'
            }`}
          >
            {isOnline ? (
              <>
                <Wifi className="w-3.5 h-3.5 text-emerald-400" />
                <span>متصل بالخادم</span>
              </>
            ) : (
              <>
                <WifiOff className="w-3.5 h-3.5 text-red-400" />
                <span>غير متصل</span>
              </>
            )}
          </div>

          {/* DEDICATED INSTALL APP BUTTON (Requirement 6) */}
          {!isStandalone ? (
            <button
              onClick={onOpenInstall}
              className="flex items-center gap-1.5 sm:gap-2 px-3 py-1.5 sm:px-3.5 sm:py-2 rounded-xl bg-gradient-to-r from-emerald-600 to-teal-600 hover:from-emerald-500 hover:to-teal-500 text-white text-xs sm:text-sm font-bold shadow-md shadow-emerald-900/30 transition active:scale-95"
              title="تثبيت التطبيق على الموبايل"
            >
              <Download className="w-4 h-4 animate-bounce" />
              <span className="hidden xxs:inline">تثبيت التطبيق</span>
              <span className="xxs:hidden">تثبيت</span>
            </button>
          ) : (
            <div className="hidden sm:flex items-center gap-1 px-2.5 py-1 rounded-lg bg-slate-800 text-emerald-400 text-xs font-semibold border border-slate-700">
              <Check className="w-3.5 h-3.5" />
              <span>مثبت كـ PWA</span>
            </div>
          )}

          {/* APK Export Button */}
          {onOpenApkModal && (
            <button
              onClick={onOpenApkModal}
              className="flex items-center gap-1.5 px-2.5 py-1.5 sm:px-3 sm:py-2 rounded-xl bg-slate-800 hover:bg-slate-705 border border-slate-700 text-emerald-400 hover:text-emerald-300 text-xs sm:text-sm font-bold transition shadow-sm"
              title="تحويل وتنزيل بصيغة APK للأندرويد"
            >
              <Smartphone className="w-4 h-4 text-emerald-400" />
              <span className="hidden xs:inline">ملف APK</span>
            </button>
          )}

          {/* Notifications Bell */}
          <button
            onClick={onOpenNotifications}
            className="relative p-2 rounded-xl bg-slate-800 hover:bg-slate-700 border border-slate-700/80 text-slate-300 hover:text-white transition"
            aria-label="الإشعارات"
          >
            <Bell className="w-4 h-4 sm:w-5 sm:h-5" />
            {unreadNotificationsCount > 0 && (
              <span className="absolute -top-1 -right-1 flex h-4 min-w-4 px-1 items-center justify-center rounded-full bg-rose-500 text-[10px] font-bold text-white shadow-sm animate-pulse">
                {unreadNotificationsCount}
              </span>
            )}
          </button>

          {/* Lock App */}
          <button
            onClick={lockApp}
            className="p-2 rounded-xl bg-slate-800 hover:bg-slate-700 border border-slate-700/80 text-slate-300 hover:text-white transition"
            title="قفل التطبيق برقم سري"
            aria-label="قفل"
          >
            <Lock className="w-4 h-4 sm:w-5 sm:h-5 text-amber-400" />
          </button>
        </div>
      </div>
    </header>
  );
};
