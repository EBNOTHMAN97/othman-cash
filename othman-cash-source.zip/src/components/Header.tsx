import React from 'react';
import { Bell, Lock, Wifi, WifiOff } from 'lucide-react';
import { useOnlineStatus } from '../hooks/useOnlineStatus';
import { useFinancial } from '../context/FinancialContext';

interface HeaderProps {
  onOpenNotifications: () => void;
}

export const Header: React.FC<HeaderProps> = ({
  onOpenNotifications,
}) => {
  const isOnline = useOnlineStatus();
  const { unreadNotificationsCount, lockApp } = useFinancial();

  return (
    <header className="sticky top-0 z-30 bg-[#101827]/95 backdrop-blur-md border-b border-slate-800/90 pt-[max(0.75rem,env(safe-area-inset-top))] sm:pt-3 transition-all">
      <div className="max-w-7xl mx-auto px-4 pt-2 pb-3 sm:pt-2.5 sm:pb-3.5 flex items-center justify-between gap-3">
        {/* Brand Logo & Name: عثمان كاش في سطر واحد وادارة المحافظ تحتها فقط */}
        <div className="flex items-center gap-3 min-w-0">
          <div className="relative shrink-0">
            <img
              src="/pwa-192x192.png"
              alt="عثمان كاش"
              className="w-11 h-11 sm:w-12 sm:h-12 rounded-xl shadow-md border border-emerald-500/40 object-cover"
            />
            {/* Live connectivity dot */}
            <span
              className={`absolute -bottom-1 -left-1 w-3.5 h-3.5 rounded-full border-2 border-[#101827] ${
                isOnline ? 'bg-emerald-500 animate-pulse' : 'bg-red-500'
              }`}
              title={isOnline ? 'متصل بالإنترنت' : 'غير متصل'}
            />
          </div>

          <div className="flex flex-col justify-center min-w-0">
            {/* Othman Wallet في سطر واحد */}
            <h1 className="text-xl sm:text-2xl font-black text-white tracking-wide leading-none whitespace-nowrap">
              Othman Wallet
            </h1>
            {/* إدارة المحافظ تحتها فقط */}
            <span className="text-xs sm:text-sm text-emerald-400 font-bold whitespace-nowrap leading-none mt-1.5 block">
              إدارة المحافظ
            </span>
          </div>
        </div>

        {/* Action Controls: مبسطة ونظيفة تماماً وبدون علامة الموبايل وبدون كلمة تثبيت */}
        <div className="flex items-center gap-2 sm:gap-2.5 shrink-0">
          {/* Online/Offline status badge (Desktop) */}
          <div
            className={`hidden md:flex items-center gap-1.5 px-3 py-1.5 rounded-full text-xs font-bold border ${
              isOnline
                ? 'bg-emerald-950/40 text-emerald-300 border-emerald-500/30'
                : 'bg-red-950/50 text-red-300 border-red-500/40 animate-pulse'
            }`}
          >
            {isOnline ? (
              <>
                <Wifi className="w-3.5 h-3.5 text-emerald-400" />
                <span>متصل بالخادم</span>
              </>
            ) : (
              <>
                <WifiOff className="w-3.5 h-3.5 text-red-400" />
                <span>غير متصل</span>
              </>
            )}
          </div>

          {/* Notifications Bell */}
          <button
            onClick={onOpenNotifications}
            className="relative p-2.5 rounded-xl bg-slate-800/90 hover:bg-slate-700 border border-slate-700/80 text-slate-200 hover:text-white transition active:scale-95 shadow-sm"
            aria-label="الإشعارات"
            title="الإشعارات والتنبيهات"
          >
            <Bell className="w-5 h-5" />
            {unreadNotificationsCount > 0 && (
              <span className="absolute -top-1 -right-1 flex h-4 min-w-4 px-1 items-center justify-center rounded-full bg-rose-500 text-[10px] font-bold text-white shadow-sm animate-pulse">
                {unreadNotificationsCount}
              </span>
            )}
          </button>

          {/* Lock App */}
          <button
            onClick={lockApp}
            className="p-2.5 rounded-xl bg-slate-800/90 hover:bg-slate-700 border border-slate-700/80 text-amber-400 hover:text-amber-300 transition active:scale-95 shadow-sm"
            title="قفل التطبيق برقم سري"
            aria-label="قفل"
          >
            <Lock className="w-5 h-5 text-amber-400" />
          </button>
        </div>
      </div>
    </header>
  );
};

