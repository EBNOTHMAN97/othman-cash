import React from 'react';
import { WifiOff, AlertTriangle, ShieldAlert } from 'lucide-react';
import { useOnlineStatus } from '../hooks/useOnlineStatus';

export const OfflineBanner: React.FC = () => {
  const isOnline = useOnlineStatus();

  if (isOnline) {
    return null;
  }

  return (
    <div className="sticky top-0 z-40 bg-gradient-to-r from-rose-950 via-red-900 to-rose-950 border-b border-red-500/40 text-red-100 px-4 py-2.5 shadow-lg">
      <div className="max-w-7xl mx-auto flex flex-col sm:flex-row items-center justify-between gap-2 text-xs">
        <div className="flex items-center gap-2.5">
          <div className="p-1.5 rounded-full bg-red-500/20 text-red-400 animate-pulse">
            <WifiOff className="w-4 h-4" />
          </div>
          <p className="font-medium text-slate-100">
            <strong className="text-red-300 ml-1">أنت الآن غير متصل بالإنترنت:</strong>
            لتأمين معاملاتك المالية، لا يمكن إجراء أي عمليات إيداع أو سحب أو تحويل أثناء انقطاع الاتصال.
          </p>
        </div>

        <div className="flex items-center gap-2 text-[11px] text-amber-300 bg-black/40 px-2.5 py-1 rounded-full border border-amber-500/30">
          <ShieldAlert className="w-3.5 h-3.5" />
          <span>الأرصدة المعروضة هي للقراءة فقط</span>
        </div>
      </div>
    </div>
  );
};
