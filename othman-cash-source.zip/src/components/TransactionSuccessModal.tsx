import React from 'react';
import {
  CheckCircle2,
  X,
  PlusCircle,
  ArrowDownRight,
  ArrowUpRight,
  ArrowLeftRight,
  Send,
  Calendar,
  Wallet as WalletIcon,
  Clock,
  Phone,
  User,
  Hash,
} from 'lucide-react';
import { Transaction } from '../types';

interface TransactionSuccessModalProps {
  isOpen: boolean;
  transaction: Transaction | null;
  onClose: () => void;
  onAnotherTransaction: () => void;
}

export const TransactionSuccessModal: React.FC<TransactionSuccessModalProps> = ({
  isOpen,
  transaction,
  onClose,
  onAnotherTransaction,
}) => {
  if (!isOpen || !transaction) return null;

  const formatArabicDateTime = (dateStr: string) => {
    try {
      const d = new Date(dateStr);
      if (isNaN(d.getTime())) return dateStr;
      return d.toLocaleDateString('ar-EG', {
        weekday: 'short',
        year: 'numeric',
        month: 'short',
        day: 'numeric',
        hour: '2-digit',
        minute: '2-digit',
      });
    } catch {
      return dateStr;
    }
  };

  const getTypeConfig = () => {
    switch (transaction.type) {
      case 'deposit':
        return {
          label: 'إيداع نقدي',
          color: 'text-emerald-400 bg-emerald-500/10 border-emerald-500/30',
          icon: <ArrowDownRight className="w-5 h-5 text-emerald-400" />,
        };
      case 'withdraw':
        return {
          label: 'سحب كاش للعميل',
          color: 'text-rose-400 bg-rose-500/10 border-rose-500/30',
          icon: <ArrowUpRight className="w-5 h-5 text-rose-400" />,
        };
      case 'transfer':
        if (transaction.transferKind === 'general') {
          return {
            label: 'تحويل عام للخارج',
            color: 'text-blue-400 bg-blue-500/10 border-blue-500/30',
            icon: <Send className="w-5 h-5 text-blue-400" />,
          };
        }
        return {
          label: 'تحويل بين المحافظ',
          color: 'text-indigo-400 bg-indigo-500/10 border-indigo-500/30',
          icon: <ArrowLeftRight className="w-5 h-5 text-indigo-400" />,
        };
      default:
        return {
          label: 'معاملة مالية',
          color: 'text-slate-400 bg-slate-500/10 border-slate-500/30',
          icon: <CheckCircle2 className="w-5 h-5 text-emerald-400" />,
        };
    }
  };

  const typeConfig = getTypeConfig();

  return (
    <div className="fixed inset-0 z-50 flex items-center justify-center p-4 sm:p-6 bg-black/80 backdrop-blur-md animate-fade-in">
      {/* Small Compact Window with Safe Area Padding */}
      <div className="relative w-full max-w-sm sm:max-w-md rounded-3xl bg-[#1e293b] border border-slate-700/80 p-6 sm:p-7 pt-7 sm:pt-8 shadow-2xl text-white text-center overflow-hidden">
        {/* Glow accent */}
        <div className="absolute -top-16 left-1/2 -translate-x-1/2 w-48 h-48 bg-emerald-500/20 rounded-full blur-3xl pointer-events-none" />

        {/* Top Close icon: placed inwards and slightly downwards */}
        <button
          onClick={onClose}
          className="absolute left-5 top-5 sm:left-6 sm:top-6 p-2 text-slate-400 hover:text-white rounded-full bg-slate-800/90 hover:bg-slate-700 transition z-10 active:scale-95 shadow-sm"
          aria-label="إغلاق"
        >
          <X className="w-4 h-4" />
        </button>

        {/* Animated Success Badge */}
        <div className="relative mx-auto mb-3.5 w-16 h-16 rounded-full bg-emerald-500/15 border-2 border-emerald-500/40 flex items-center justify-center shadow-lg shadow-emerald-950/40">
          <CheckCircle2 className="w-9 h-9 text-emerald-400 animate-scale-in" />
        </div>

        {/* Title */}
        <h2 className="text-xl sm:text-2xl font-black text-white mb-1">
          تمت العملية بنجاح
        </h2>
        <p className="text-xs text-slate-400 mb-4 flex items-center justify-center gap-1.5">
          <Hash className="w-3.5 h-3.5 text-slate-500" />
          <span className="font-mono dir-ltr">{transaction.referenceNumber}</span>
          <span className="text-emerald-400 font-medium mr-1">• مكتملة ومسجلة</span>
        </p>

        {/* Summary Card */}
        <div className="p-3.5 bg-slate-900/80 rounded-2xl border border-slate-800 mb-5 text-right space-y-2.5">
          {/* Operation & Amount */}
          <div className="flex items-center justify-between pb-2.5 border-b border-slate-800/80">
            <div className={`flex items-center gap-1.5 px-2.5 py-1 rounded-xl text-xs font-bold border ${typeConfig.color}`}>
              {typeConfig.icon}
              <span>{typeConfig.label}</span>
            </div>
            <div className="text-left">
              <span className="text-lg sm:text-xl font-black font-mono text-emerald-400">
                {transaction.amount.toLocaleString()} <span className="text-xs font-normal">ج.م</span>
              </span>
              {transaction.fee > 0 && (
                <span className="block text-[10px] text-slate-400 font-mono">
                  + عمولة {transaction.fee.toLocaleString()} ج.م
                </span>
              )}
            </div>
          </div>

          {/* Wallet Info */}
          <div className="flex items-center justify-between text-xs">
            <span className="text-slate-400 flex items-center gap-1.5">
              <WalletIcon className="w-3.5 h-3.5 text-slate-500" />
              <span>المحفظة:</span>
            </span>
            <span className="font-semibold text-slate-200">
              {transaction.walletName}
              {transaction.targetWalletName && (
                <span className="text-indigo-300"> ⬅ {transaction.targetWalletName}</span>
              )}
            </span>
          </div>

          {/* Date of Transaction */}
          <div className="flex items-center justify-between text-xs">
            <span className="text-slate-400 flex items-center gap-1.5">
              <Calendar className="w-3.5 h-3.5 text-slate-500" />
              <span>تاريخ العملية:</span>
            </span>
            <span className="font-medium text-slate-300 font-mono text-[11px]">
              {formatArabicDateTime(transaction.date)}
            </span>
          </div>

          {/* Recipient info if present */}
          {(transaction.recipientPhone || transaction.recipientName) && (
            <div className="flex items-center justify-between text-xs pt-1 border-t border-slate-800/60">
              <span className="text-slate-400 flex items-center gap-1.5">
                <User className="w-3.5 h-3.5 text-slate-500" />
                <span>العميل / المستلم:</span>
              </span>
              <span className="font-semibold text-slate-200">
                {transaction.recipientName || transaction.recipientPhone}
                {transaction.recipientPhone && transaction.recipientName && (
                  <span className="text-slate-400 font-mono text-[11px] mr-1">
                    ({transaction.recipientPhone})
                  </span>
                )}
              </span>
            </div>
          )}

          {/* Dynamic Limit notice */}
          <div className="pt-2 border-t border-slate-800/60 text-center">
            <span className="text-[11px] text-emerald-400/90 font-medium">
              ✓ تم تسجيل العملية واحتساب الليمت بتاريخ العملية تلقائياً
            </span>
          </div>
        </div>

        {/* In the Center Action Buttons: "إغلاق" and "عملية أخرى" as requested */}
        <div className="flex flex-col sm:flex-row items-center justify-center gap-2.5">
          {/* عملية أخرى */}
          <button
            type="button"
            onClick={onAnotherTransaction}
            className="w-full sm:flex-1 py-3 px-4 rounded-xl bg-gradient-to-r from-emerald-600 to-teal-600 hover:from-emerald-500 hover:to-teal-500 text-white font-bold text-xs sm:text-sm shadow-lg shadow-emerald-950/50 flex items-center justify-center gap-2 transition active:scale-[0.98]"
          >
            <PlusCircle className="w-4 h-4" />
            <span>عملية أخرى</span>
          </button>

          {/* إغلاق */}
          <button
            type="button"
            onClick={onClose}
            className="w-full sm:flex-1 py-3 px-4 rounded-xl bg-slate-800 hover:bg-slate-700 text-slate-200 font-bold text-xs sm:text-sm border border-slate-700 transition active:scale-[0.98]"
          >
            <span>إغلاق</span>
          </button>
        </div>
      </div>
    </div>
  );
};
