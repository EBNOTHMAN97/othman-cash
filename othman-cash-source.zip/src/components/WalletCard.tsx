import React, { useState } from 'react';
import { Eye, EyeOff, Copy, Check, ArrowDownRight, ArrowUpRight, ArrowLeftRight, AlertTriangle, Edit3 } from 'lucide-react';
import { Wallet } from '../types';

interface WalletCardProps {
  wallet: Wallet;
  onDeposit: (walletId: string) => void;
  onWithdraw: (walletId: string) => void;
  onTransfer: (walletId: string) => void;
  onEdit?: (wallet: Wallet) => void;
}

export const WalletCard: React.FC<WalletCardProps> = ({
  wallet,
  onDeposit,
  onWithdraw,
  onTransfer,
  onEdit,
}) => {
  const [showBalance, setShowBalance] = useState(true);
  const [copied, setCopied] = useState(false);

  const dailyUsagePercent = Math.min(100, Math.round((wallet.dailySpent / wallet.dailyLimit) * 100));
  const monthlyUsagePercent = Math.min(100, Math.round((wallet.monthlySpent / wallet.monthlyLimit) * 100));
  const isDailyWarning = dailyUsagePercent >= 80;
  const isMonthlyWarning = monthlyUsagePercent >= 85;

  const handleCopy = () => {
    navigator.clipboard.writeText(wallet.accountNumber);
    setCopied(true);
    setTimeout(() => setCopied(false), 2000);
  };

  const getProviderBadge = (provider: Wallet['provider']) => {
    switch (provider) {
      case 'accesspay':
        return { label: 'أكسس باي', color: 'bg-cyan-500/20 text-cyan-300 border-cyan-500/40' };
      case 'vodafone':
        return { label: 'فودافون كاش', color: 'bg-red-500/20 text-red-400 border-red-500/30' };
      case 'orange':
        return { label: 'أورنج كاش', color: 'bg-orange-500/20 text-orange-400 border-orange-500/30' };
      case 'etisalat':
        return { label: 'اتصالات كاش', color: 'bg-emerald-500/20 text-emerald-400 border-emerald-500/30' };
      case 'instapay':
        return { label: 'إنستاباي IPN', color: 'bg-purple-500/20 text-purple-400 border-purple-500/30' };
      case 'cash_vault':
        return { label: 'خزينة نقدية', color: 'bg-teal-500/20 text-teal-400 border-teal-500/30' };
      case 'nbe':
        return { label: 'البنك الأهلي', color: 'bg-sky-500/20 text-sky-400 border-sky-500/30' };
      case 'bank_misr':
        return { label: 'بنك مصر', color: 'bg-amber-500/20 text-amber-400 border-amber-500/30' };
      default:
        return { label: 'محفظة مالية', color: 'bg-slate-500/20 text-slate-400 border-slate-500/30' };
    }
  };

  const badge = getProviderBadge(wallet.provider);

  return (
    <div className="relative rounded-2xl bg-gradient-to-br from-[#1e293b] to-[#0f172a] border border-slate-700/80 p-4 sm:p-5 shadow-lg hover:border-slate-600 transition flex flex-col justify-between overflow-hidden">
      {/* Decorative top accent line */}
      <div
        className="absolute top-0 right-0 left-0 h-1.5"
        style={{ backgroundColor: wallet.color || '#10b981' }}
      />

      <div>
        {/* Header: Provider badge & Account / Phone number & Edit Button */}
        <div className="flex items-center justify-between gap-2 mb-3">
          <div className="flex items-center gap-2">
            <span className={`text-xs font-bold px-2.5 py-0.5 rounded-full border ${badge.color}`}>
              {badge.label}
            </span>
            {!wallet.isActive && (
              <span className="text-[10px] bg-rose-500/20 text-rose-300 px-1.5 py-0.5 rounded">
                متوقفة
              </span>
            )}
          </div>

          <div className="flex items-center gap-1.5 text-xs text-slate-400 font-mono">
            <span className="dir-ltr text-slate-300 font-semibold">{wallet.accountNumber}</span>
            <button
              onClick={handleCopy}
              className="p-1 text-slate-400 hover:text-white transition rounded"
              title="نسخ رقم المحفظة"
            >
              {copied ? <Check className="w-3.5 h-3.5 text-emerald-400" /> : <Copy className="w-3.5 h-3.5" />}
            </button>
            {onEdit && (
              <button
                onClick={() => onEdit(wallet)}
                className="p-1 text-slate-400 hover:text-emerald-400 transition rounded hover:bg-slate-800"
                title="تعديل بيانات المحفظة"
              >
                <Edit3 className="w-3.5 h-3.5" />
              </button>
            )}
          </div>
        </div>

        {/* Wallet Name */}
        <h3 className="text-base sm:text-lg font-bold text-white mb-2 line-clamp-1">{wallet.name}</h3>

        {/* Balance Display with Privacy Eye */}
        <div className="flex items-baseline justify-between mb-4 bg-slate-900/80 p-3.5 rounded-xl border border-slate-800">
          <div>
            <span className="text-xs text-slate-400 block mb-0.5">الرصيد المتاح</span>
            <div className="flex items-baseline gap-1.5">
              <span className="text-2xl sm:text-3xl font-black text-white font-mono tracking-tight">
                {showBalance ? wallet.balance.toLocaleString('en-US') : '••••••••'}
              </span>
              <span className="text-xs sm:text-sm font-bold text-emerald-400">ج.م</span>
            </div>
          </div>
          <button
            onClick={() => setShowBalance(!showBalance)}
            className="p-1.5 text-slate-400 hover:text-slate-200 transition rounded-lg hover:bg-slate-800"
            title={showBalance ? 'إخفاء الرصيد' : 'إظهار الرصيد'}
          >
            {showBalance ? <EyeOff className="w-4 h-4" /> : <Eye className="w-4 h-4" />}
          </button>
        </div>

        {/* Limits Tracking Section */}
        <div className="space-y-2.5 text-xs mb-4">
          {/* Daily Limit Bar */}
          <div>
            <div className="flex justify-between items-center text-xs mb-1">
              <span className="text-slate-300 flex items-center gap-1 font-medium">
                الليمت اليومي
                {isDailyWarning && <AlertTriangle className="w-3 h-3 text-amber-400" />}
              </span>
              <span className={`font-mono font-semibold ${isDailyWarning ? 'text-amber-400 font-bold' : 'text-slate-300'}`}>
                {wallet.dailySpent.toLocaleString()} / {wallet.dailyLimit.toLocaleString()} ({dailyUsagePercent}%)
              </span>
            </div>
            <div className="w-full bg-slate-800 h-2 rounded-full overflow-hidden">
              <div
                className={`h-full transition-all duration-500 rounded-full ${
                  dailyUsagePercent >= 90
                    ? 'bg-rose-500'
                    : dailyUsagePercent >= 75
                    ? 'bg-amber-400'
                    : 'bg-emerald-500'
                }`}
                style={{ width: `${dailyUsagePercent}%` }}
              />
            </div>
          </div>

          {/* Monthly Limit Bar */}
          <div>
            <div className="flex justify-between items-center text-xs mb-1">
              <span className="text-slate-300 font-medium">الليمت الشهري</span>
              <span className="font-mono text-slate-300 font-semibold">
                {wallet.monthlySpent.toLocaleString()} / {wallet.monthlyLimit.toLocaleString()} ({monthlyUsagePercent}%)
              </span>
            </div>
            <div className="w-full bg-slate-800 h-2 rounded-full overflow-hidden">
              <div
                className={`h-full transition-all duration-500 rounded-full ${
                  monthlyUsagePercent >= 90 ? 'bg-rose-500' : 'bg-indigo-500'
                }`}
                style={{ width: `${monthlyUsagePercent}%` }}
              />
            </div>
          </div>
        </div>
      </div>

      {/* Quick Action Buttons for this wallet */}
      <div className="grid grid-cols-3 gap-2 pt-2.5 border-t border-slate-800">
        <button
          onClick={() => onDeposit(wallet.id)}
          className="flex items-center justify-center gap-1 py-2 px-2 rounded-xl bg-emerald-600/20 hover:bg-emerald-600/30 text-emerald-300 border border-emerald-500/30 text-xs sm:text-sm font-bold transition active:scale-95"
        >
          <ArrowDownRight className="w-4 h-4 text-emerald-400" />
          <span>إيداع</span>
        </button>

        <button
          onClick={() => onWithdraw(wallet.id)}
          className="flex items-center justify-center gap-1 py-2 px-2 rounded-xl bg-rose-600/20 hover:bg-rose-600/30 text-rose-300 border border-rose-500/30 text-xs sm:text-sm font-bold transition active:scale-95"
        >
          <ArrowUpRight className="w-4 h-4 text-rose-400" />
          <span>سحب</span>
        </button>

        <button
          onClick={() => onTransfer(wallet.id)}
          className="flex items-center justify-center gap-1 py-2 px-2 rounded-xl bg-indigo-600/20 hover:bg-indigo-600/30 text-indigo-300 border border-indigo-500/30 text-xs sm:text-sm font-bold transition active:scale-95"
        >
          <ArrowLeftRight className="w-4 h-4 text-indigo-400" />
          <span>تحويل</span>
        </button>
      </div>
    </div>
  );
};
