import { Wallet, Transaction, ExpenseCategory } from '../types';

export interface DatabaseStatus {
  connected: boolean;
  neonConfigured: boolean;
  message: string;
  database?: string;
  serverTime?: string;
  counts?: {
    wallets: number;
    transactions: number;
  };
}

export interface SyncData {
  wallets: Wallet[];
  transactions: Transaction[];
  categories: ExpenseCategory[];
  defaultTransferWalletId?: string | null;
}

// 1. Check Neon Database Status
export async function checkNeonStatus(): Promise<DatabaseStatus> {
  try {
    const res = await fetch('/api/health', {
      headers: { Accept: 'application/json' },
    });
    if (!res.ok) {
      return {
        connected: false,
        neonConfigured: false,
        message: `HTTP ${res.status}: لم يتم العثور على مسار API أو لم يتم تفعيل السيرفر بعد.`,
      };
    }
    const data = await res.json();
    return {
      connected: data.status === 'connected',
      neonConfigured: Boolean(data.neonConfigured),
      message: data.message || (data.status === 'connected' ? 'متصل بقاعدة نيون بنجاح' : 'غير متصل'),
      database: data.database,
      serverTime: data.serverTime,
      counts: data.counts,
    };
  } catch (err: any) {
    return {
      connected: false,
      neonConfigured: false,
      message: 'تعذر الاتصال بواجهة API (وضع محلي / Offline).',
    };
  }
}

// 2. Fetch all data from Neon (Hydration)
export async function fetchNeonData(): Promise<{ success: boolean; data?: SyncData; error?: string }> {
  try {
    const res = await fetch('/api/sync');
    if (!res.ok) {
      return { success: false, error: `HTTP ${res.status}` };
    }
    const json = await res.json();
    if (!json.success || !json.neonConfigured) {
      return { success: false, error: json.message || 'Neon غير مهيأ' };
    }
    return {
      success: true,
      data: {
        wallets: json.wallets || [],
        transactions: json.transactions || [],
        categories: json.categories || [],
        defaultTransferWalletId: json.defaultTransferWalletId,
      },
    };
  } catch (err: any) {
    return { success: false, error: err.message };
  }
}

// 3. Push local data to Neon (Sync)
export async function pushLocalDataToNeon(data: SyncData): Promise<{ success: boolean; message: string; counts?: any }> {
  try {
    const res = await fetch('/api/sync', {
      method: 'POST',
      headers: { 'Content-Type': 'application/json' },
      body: JSON.stringify(data),
    });
    const json = await res.json();
    if (!res.ok || !json.success) {
      return { success: false, message: json.error || json.message || 'فشلت المزامنة مع Neon' };
    }
    return {
      success: true,
      message: 'تمت مزامنة جميع البيانات إلى قاعدة بيانات نيون بنجاح!',
      counts: json.counts,
    };
  } catch (err: any) {
    return { success: false, message: `تعذر الاتصال بـ Neon: ${err.message}` };
  }
}

// 4. Save or update a wallet
export async function saveWalletToNeon(wallet: Wallet): Promise<boolean> {
  try {
    const res = await fetch('/api/wallets', {
      method: 'POST',
      headers: { 'Content-Type': 'application/json' },
      body: JSON.stringify(wallet),
    });
    return res.ok;
  } catch {
    return false;
  }
}

// 5. Delete a wallet
export async function deleteWalletFromNeon(walletId: string): Promise<boolean> {
  try {
    const res = await fetch('/api/wallets', {
      method: 'DELETE',
      headers: { 'Content-Type': 'application/json' },
      body: JSON.stringify({ id: walletId }),
    });
    return res.ok;
  } catch {
    return false;
  }
}

// 6. Log or update transaction in Neon
export async function logTransactionToNeon(tx: Transaction): Promise<boolean> {
  try {
    const res = await fetch('/api/transactions', {
      method: 'POST',
      headers: { 'Content-Type': 'application/json' },
      body: JSON.stringify({
        ...tx,
        timestamp: tx.date,
        relatedWalletId: tx.targetWalletId,
      }),
    });
    return res.ok;
  } catch {
    return false;
  }
}

// 7. Delete transaction from Neon
export async function deleteTransactionFromNeon(transactionId: string): Promise<boolean> {
  try {
    const res = await fetch('/api/transactions', {
      method: 'DELETE',
      headers: { 'Content-Type': 'application/json' },
      body: JSON.stringify({ id: transactionId }),
    });
    return res.ok;
  } catch {
    return false;
  }
}

