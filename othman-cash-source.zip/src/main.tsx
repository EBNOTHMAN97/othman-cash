import {createRoot} from 'react-dom/client';
import App from './App.tsx';
import './index.css';
import { setupPWARegistration } from './pwa';

// Register service worker for installable PWA support
setupPWARegistration();

createRoot(document.getElementById('root')!).render(<App />);
