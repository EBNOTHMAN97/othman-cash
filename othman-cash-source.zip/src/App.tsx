import React, { useState, useEffect } from 'react';
import {
  FinancialProvider,
  useFinancial,
} from './context/FinancialContext';
import { usePWAInstall } from './hooks/usePWAInstall';
import { Header } from './components/Header';
import { BottomNav, ActiveTab } from './components/BottomNav';
import { OfflineBanner } from './components/OfflineBanner';
import { WalletCard } from './components/WalletCard';
import { CashLiquidityDistribution } from './components/CashLiquidityDistribution';
import { MonthlyLimitsTracker } from './components/MonthlyLimitsTracker';
import { TransactionsTable } from './components/TransactionsTable';
import { QuickActionModal } from './components/QuickActionModal';
import { NotificationCenter } from './components/NotificationCenter';
import { SettingsView } from './components/SettingsView';
import { LockScreen } from './components/LockScreen';
import { EditWalletModal } from './components/EditWalletModal';
import { EditTransactionModal } from './components/EditTransactionModal';
import { MonthlyExpensesPieChart } from './components/MonthlyExpensesPieChart';
import { HistoryTabContent } from './components/HistoryTabContent';
import { CreateWalletModal } from './components/CreateWalletModal';
import { ManageCategoriesModal } from './components/ManageCategoriesModal';
import {
  ArrowDownRight,
  ArrowUpRight,
  ArrowLeftRight,
  Send,
  Sparkles,
  PlusCircle,
} from 'lucide-react';
import { Wallet, Transaction } from './types';

// The Main Homepage (الصفحة الرئيسية) containing ONLY the requested sections
function DashboardView({
  onOpenQuickAction,
  onEditTransaction,
  onOpenManageCategories,
}: {
  onOpenQuickAction: (type: 'deposit' | 'withdraw' | 'transfer' | 'transfer_internal' | 'transfer_general', walletId?: string) => void;
  onEditTransaction: (tx: Transaction) => void;
  onOpenManageCategories?: () => void;
}) {
  return (
    <div className="space-y-6 sm:space-y-8 animate-fade-in">
      {/* 1. العمليات السريعة فقط (Quick Actions Banner with Separated Transfers: عام vs بين المحافظ) */}
      <div className="bg-gradient-to-r from-[#1e293b] via-[#162032] to-[#1e293b] border border-slate-700/80 rounded-2xl p-4 sm:p-5 shadow-xl">
        <div className="flex items-center justify-between mb-3.5">
          <div className="flex items-center gap-2">
            <span className="p-1.5 rounded-lg bg-emerald-500/20 text-emerald-400">
              <Sparkles className="w-4 h-4" />
            </span>
            <h2 className="text-base sm:text-lg font-black text-white tracking-wide">العمليات السريعة</h2>
          </div>
          <span className="text-xs text-slate-400 font-medium">تنفيذ فوري للأموال</span>
        </div>

        <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-4 gap-3">
          {/* إضافة أموال */}
          <button
            onClick={() => onOpenQuickAction('deposit')}
            className="flex items-center justify-center gap-2 py-3 px-3 rounded-xl bg-gradient-to-r from-emerald-600 to-teal-600 hover:from-emerald-500 hover:to-teal-500 text-white font-bold text-xs sm:text-sm shadow-md shadow-emerald-950/60 transition active:scale-[0.98]"
          >
            <div className="p-1 rounded-lg bg-white/20">
              <ArrowDownRight className="w-4 h-4 text-white" />
            </div>
            <span>إضافة أموال (إيداع)</span>
          </button>

          {/* سحب أموال */}
          <button
            onClick={() => onOpenQuickAction('withdraw')}
            className="flex items-center justify-center gap-2 py-3 px-3 rounded-xl bg-gradient-to-r from-rose-600 to-red-600 hover:from-rose-500 hover:to-red-500 text-white font-bold text-xs sm:text-sm shadow-md shadow-rose-950/60 transition active:scale-[0.98]"
          >
            <div className="p-1 rounded-lg bg-white/20">
              <ArrowUpRight className="w-4 h-4 text-white" />
            </div>
            <span>سحب أموال (كاش)</span>
          </button>

          {/* التحويل بشكل عام (خارجي) */}
          <button
            onClick={() => onOpenQuickAction('transfer_general')}
            className="flex items-center justify-center gap-2 py-3 px-3 rounded-xl bg-gradient-to-r from-blue-600 to-indigo-600 hover:from-blue-500 hover:to-indigo-500 text-white font-bold text-xs sm:text-sm shadow-md shadow-blue-950/60 transition active:scale-[0.98]"
          >
            <div className="p-1 rounded-lg bg-white/20">
              <Send className="w-4 h-4 text-white" />
            </div>
            <span>التحويل بشكل عام</span>
          </button>

          {/* التحويل بين المحافظ (داخلي) */}
          <button
            onClick={() => onOpenQuickAction('transfer_internal')}
            className="flex items-center justify-center gap-2 py-3 px-3 rounded-xl bg-gradient-to-r from-indigo-600 to-purple-600 hover:from-indigo-500 hover:to-purple-500 text-white font-bold text-xs sm:text-sm shadow-md shadow-purple-950/60 transition active:scale-[0.98]"
          >
            <div className="p-1 rounded-lg bg-white/20">
              <ArrowLeftRight className="w-4 h-4 text-white" />
            </div>
            <span>التحويل بين المحافظ</span>
          </button>
        </div>
      </div>

      {/* 2. توزيع السيولة النقدية بين المحافظ */}
      <CashLiquidityDistribution />

      {/* 3. متابعه الليمت الشهري */}
      <MonthlyLimitsTracker />

      {/* 4. الرسم البياني الدائري لتوزيع المصروفات حسب التصنيفات خلال الشهر الحالي (Recharts Pie Chart) */}
      <MonthlyExpensesPieChart
        onOpenWithdraw={() => onOpenQuickAction('withdraw')}
        onOpenManageCategories={onOpenManageCategories}
      />

      {/* 5. سجل العمليات والتحويلات */}
      <TransactionsTable onEditTransaction={onEditTransaction} />
    </div>
  );
}

function MainApp() {
  const [activeTab, setActiveTab] = useState<ActiveTab>('dashboard');
  const [quickActionModalOpen, setQuickActionModalOpen] = useState(false);
  const [quickActionType, setQuickActionType] = useState<
    'deposit' | 'withdraw' | 'transfer' | 'transfer_internal' | 'transfer_general'
  >('deposit');
  const [preselectedWalletId, setPreselectedWalletId] = useState<string | undefined>(undefined);
  const [notificationCenterOpen, setNotificationCenterOpen] = useState(false);
  const [createWalletModalOpen, setCreateWalletModalOpen] = useState(false);
  const [manageCategoriesModalOpen, setManageCategoriesModalOpen] = useState(false);

  // Edit Wallet & Transaction Modal States
  const [editWalletModalOpen, setEditWalletModalOpen] = useState(false);
  const [selectedWalletToEdit, setSelectedWalletToEdit] = useState<Wallet | null>(null);

  const [editTxModalOpen, setEditTxModalOpen] = useState(false);
  const [selectedTxToEdit, setSelectedTxToEdit] = useState<Transaction | null>(null);

  const { addWallet, updateWallet, deleteWallet, updateTransaction, deleteTransaction } = useFinancial();

  const [pushPermissionStatus, setPushPermissionStatus] = useState<NotificationPermission>(() => {
    return typeof window !== 'undefined' && 'Notification' in window ? Notification.permission : 'default';
  });

  // Listen to PWA shortcuts from URL
  useEffect(() => {
    const params = new URLSearchParams(window.location.search);
    const action = params.get('action');
    if (action === 'deposit' || action === 'withdraw' || action === 'transfer') {
      setQuickActionType(action);
      setQuickActionModalOpen(true);
      window.history.replaceState({}, document.title, window.location.pathname);
    }
  }, []);

  const handleOpenQuickAction = (
    type: 'deposit' | 'withdraw' | 'transfer' | 'transfer_internal' | 'transfer_general' = 'deposit',
    walletId?: string
  ) => {
    setQuickActionType(type);
    setPreselectedWalletId(walletId);
    setQuickActionModalOpen(true);
  };

  const handleEditWallet = (wallet: Wallet) => {
    setSelectedWalletToEdit(wallet);
    setEditWalletModalOpen(true);
  };

  const handleEditTransaction = (tx: Transaction) => {
    setSelectedTxToEdit(tx);
    setEditTxModalOpen(true);
  };

  const handleRequestPushPermission = async () => {
    if (typeof window !== 'undefined' && 'Notification' in window) {
      try {
        const perm = await Notification.requestPermission();
        setPushPermissionStatus(perm);
        if (perm === 'granted') {
          if ('serviceWorker' in navigator && navigator.serviceWorker.controller) {
            navigator.serviceWorker.ready.then((reg) => {
              reg.showNotification('عثمان كاش', {
                body: 'تم تفعيل التنبيهات بنجاح! ستصلك إشعارات الليمات والعمليات فوراً.',
                icon: '/pwa-192x192.png',
                dir: 'rtl',
                lang: 'ar',
              });
            });
          }
        }
      } catch (err) {
        console.error('Error requesting notification permission:', err);
      }
    }
  };

  return (
    <div className="min-h-screen bg-[#101827] text-slate-100 flex flex-col antialiased selection:bg-emerald-500/30 selection:text-emerald-300">
      {/* Offline Alert Bar */}
      <OfflineBanner />

      {/* Main App Header: نظيف وبدون أي روابط تثبيت أو علامة موبايل */}
      <Header
        onOpenNotifications={() => setNotificationCenterOpen(true)}
      />


      {/* Desktop Navigation Tabs (Offset adjusted for lowered header) */}
      <div className="hidden sm:block border-b border-slate-800 bg-[#101827]/85 sticky top-[68px] sm:top-[70px] z-20 backdrop-blur-md transition-all">
        <div className="max-w-7xl mx-auto px-4 flex gap-6 text-sm font-bold">
          <button
            onClick={() => setActiveTab('dashboard')}
            className={`py-3.5 border-b-2 transition ${
              activeTab === 'dashboard'
                ? 'border-emerald-500 text-emerald-400'
                : 'border-transparent text-slate-400 hover:text-slate-200'
            }`}
          >
            لوحة التحكم الرئيسية
          </button>
          <button
            onClick={() => setActiveTab('wallets')}
            className={`py-3.5 border-b-2 transition ${
              activeTab === 'wallets'
                ? 'border-emerald-500 text-emerald-400'
                : 'border-transparent text-slate-400 hover:text-slate-200'
            }`}
          >
            المحافظ والحسابات
          </button>
          <button
            onClick={() => setActiveTab('history')}
            className={`py-3.5 border-b-2 transition ${
              activeTab === 'history'
                ? 'border-emerald-500 text-emerald-400'
                : 'border-transparent text-slate-400 hover:text-slate-200'
            }`}
          >
            سجل العمليات والتحويلات
          </button>
          <button
            onClick={() => setActiveTab('settings')}
            className={`py-3.5 border-b-2 transition ${
              activeTab === 'settings'
                ? 'border-emerald-500 text-emerald-400'
                : 'border-transparent text-slate-400 hover:text-slate-200'
            }`}
          >
            الإعدادات ومسح البيانات
          </button>
        </div>
      </div>

      {/* Page Content Container */}
      <main className="flex-1 max-w-7xl w-full mx-auto p-3.5 sm:p-6 pb-24 sm:pb-10">
        {activeTab === 'dashboard' && (
          <DashboardView
            onOpenQuickAction={handleOpenQuickAction}
            onEditTransaction={handleEditTransaction}
            onOpenManageCategories={() => setManageCategoriesModalOpen(true)}
          />
        )}

        {activeTab === 'wallets' && (
          <WalletsTabContent
            onOpenQuickAction={handleOpenQuickAction}
            onEditWallet={handleEditWallet}
            onCreateWallet={() => setCreateWalletModalOpen(true)}
          />
        )}

        {activeTab === 'history' && (
          <HistoryTabContent
            onEditTransaction={handleEditTransaction}
            onOpenManageCategories={() => setManageCategoriesModalOpen(true)}
          />
        )}

        {activeTab === 'settings' && (
          <SettingsView
            onRequestPushPermission={handleRequestPushPermission}
            pushPermissionStatus={pushPermissionStatus}
            onEditWallet={handleEditWallet}
            onOpenManageCategories={() => setManageCategoriesModalOpen(true)}
          />
        )}
      </main>

      {/* Mobile Bottom Navigation Bar */}
      <BottomNav
        activeTab={activeTab}
        setActiveTab={setActiveTab}
        onOpenQuickAction={() => handleOpenQuickAction('deposit')}
      />

      {/* Quick Action Modal (Deposit / Withdraw / Transfer) */}
      <QuickActionModal
        isOpen={quickActionModalOpen}
        onClose={() => setQuickActionModalOpen(false)}
        initialType={quickActionType}
        preselectedWalletId={preselectedWalletId}
        onOpenManageCategories={() => setManageCategoriesModalOpen(true)}
      />

      {/* Manage Custom Expense Categories Modal */}
      <ManageCategoriesModal
        isOpen={manageCategoriesModalOpen}
        onClose={() => setManageCategoriesModalOpen(false)}
      />

      {/* Create Wallet Modal */}
      <CreateWalletModal
        isOpen={createWalletModalOpen}
        onClose={() => setCreateWalletModalOpen(false)}
        onSave={(newWallet) => addWallet(newWallet)}
      />

      {/* Edit Wallet Modal */}
      <EditWalletModal
        isOpen={editWalletModalOpen}
        wallet={selectedWalletToEdit}
        onClose={() => {
          setEditWalletModalOpen(false);
          setSelectedWalletToEdit(null);
        }}
        onSave={(updated) => updateWallet(updated)}
        onDelete={(id) => deleteWallet(id)}
      />

      {/* Edit Transaction Modal */}
      <EditTransactionModal
        isOpen={editTxModalOpen}
        transaction={selectedTxToEdit}
        onClose={() => {
          setEditTxModalOpen(false);
          setSelectedTxToEdit(null);
        }}
        onSave={(updated) => updateTransaction(updated)}
        onDelete={(id) => deleteTransaction(id)}
      />

      {/* Notification Center Drawer */}
      <NotificationCenter
        isOpen={notificationCenterOpen}
        onClose={() => setNotificationCenterOpen(false)}
        onRequestPushPermission={handleRequestPushPermission}
        pushPermissionStatus={pushPermissionStatus}
      />

      {/* App PIN Lock Screen */}
      <LockScreen />
    </div>
  );
}

function WalletsTabContent({
  onOpenQuickAction,
  onEditWallet,
  onCreateWallet,
}: {
  onOpenQuickAction: (type: 'deposit' | 'withdraw' | 'transfer', walletId?: string) => void;
  onEditWallet: (wallet: Wallet) => void;
  onCreateWallet: () => void;
}) {

  const { wallets } = useFinancial();

  return (
    <div className="space-y-6">
      <div className="flex flex-col sm:flex-row sm:items-center justify-between gap-3">
        <div>
          <h2 className="text-xl font-bold text-white">إدارة المحافظ والحسابات</h2>
          <p className="text-xs sm:text-sm text-slate-400 mt-0.5">
            تعديل بيانات المحافظ، مراقبة الأرصدة، وحدود الصرف
          </p>
        </div>

        <div className="flex items-center gap-2 self-start sm:self-auto flex-wrap">
          <button
            onClick={onCreateWallet}
            className="flex items-center gap-2 px-4 py-2.5 rounded-xl bg-gradient-to-r from-emerald-600 to-teal-600 hover:from-emerald-500 hover:to-teal-500 text-white text-xs sm:text-sm font-bold transition shadow-lg shadow-emerald-950/40"
          >
            <PlusCircle className="w-4 h-4" />
            <span>إنشاء محفظة جديدة</span>
          </button>

          <button
            onClick={() => onOpenQuickAction('deposit')}
            className="flex items-center gap-2 px-3.5 py-2.5 rounded-xl bg-slate-800 hover:bg-slate-700 text-slate-200 text-xs sm:text-sm font-bold transition border border-slate-700"
          >
            <ArrowDownRight className="w-4 h-4" />
            <span>إجراء عملية سريعة</span>
          </button>
        </div>
      </div>

      <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-4">
        {wallets.map((wallet) => (
          <WalletCard
            key={wallet.id}
            wallet={wallet}
            onDeposit={(id) => onOpenQuickAction('deposit', id)}
            onWithdraw={(id) => onOpenQuickAction('withdraw', id)}
            onTransfer={(id) => onOpenQuickAction('transfer', id)}
            onEdit={onEditWallet}
          />
        ))}

        {/* Create New Wallet Card */}
        <button
          type="button"
          onClick={onCreateWallet}
          className="group rounded-2xl border-2 border-dashed border-slate-700 hover:border-emerald-500/80 p-6 flex flex-col items-center justify-center gap-3 text-center transition bg-slate-900/30 hover:bg-slate-800/40 min-h-[220px]"
        >
          <div className="w-12 h-12 rounded-2xl bg-emerald-500/10 group-hover:bg-emerald-500/20 text-emerald-400 flex items-center justify-center transition border border-emerald-500/20 group-hover:scale-105">
            <PlusCircle className="w-6 h-6" />
          </div>
          <div>
            <span className="font-bold text-sm text-white group-hover:text-emerald-300 transition block">
              إنشاء محفظة جديدة
            </span>
            <span className="text-xs text-slate-400 mt-1 block">
              إضافة فودافون كاش، إنستاباي، حساب بنكي أو خزينة
            </span>
          </div>
        </button>
      </div>
    </div>
  );
}

export default function App() {
  return (
    <FinancialProvider>
      <MainApp />
    </FinancialProvider>
  );
}
