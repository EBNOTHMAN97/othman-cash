import express from 'express';
import dotenv from 'dotenv';
import path from 'path';
import fs from 'fs';
import { fileURLToPath } from 'url';
import healthHandler from './api/health.js';
import walletsHandler from './api/wallets.js';
import transactionsHandler from './api/transactions.js';
import categoriesHandler from './api/categories.js';
import syncHandler from './api/sync.js';

dotenv.config();

const __filename = fileURLToPath(import.meta.url);
const __dirname = path.dirname(__filename);

async function startServer() {
  const app = express();
  const PORT = process.env.PORT || 3000;
  const isProd = process.env.NODE_ENV === 'production';

  app.use(express.json({ limit: '10mb' }));
  app.use(express.urlencoded({ extended: true }));

  // API Route Adapters for Express
  app.all('/api/health', (req, res) => healthHandler(req as any, res as any));
  app.all('/api/wallets', (req, res) => walletsHandler(req as any, res as any));
  app.all('/api/transactions', (req, res) => transactionsHandler(req as any, res as any));
  app.all('/api/categories', (req, res) => categoriesHandler(req as any, res as any));
  app.all('/api/sync', (req, res) => syncHandler(req as any, res as any));

  if (!isProd) {
    // In dev mode, ensure Vite client does not throw unhandled WebSocket rejection in cloud container
    try {
      const clientPath = path.resolve(__dirname, 'node_modules/vite/dist/client/client.mjs');
      if (fs.existsSync(clientPath)) {
        let content = fs.readFileSync(clientPath, 'utf-8');
        let modified = false;
        if (content.includes('reject(/* @__PURE__ */ new Error("WebSocket closed without opened."))')) {
          content = content.replace('reject(/* @__PURE__ */ new Error("WebSocket closed without opened."))', 'resolve()');
          modified = true;
        }
        if (content.includes('console.error(`[vite] failed to connect to websocket (${e}). `);\n\t\t\t\tthrow e;')) {
          content = content.replace('console.error(`[vite] failed to connect to websocket (${e}). `);\n\t\t\t\tthrow e;', 'return;');
          modified = true;
        }
        if (modified) {
          fs.writeFileSync(clientPath, content, 'utf-8');
        }
      }
    } catch (_) {}

    // Development mode: mount Vite dev middleware (HMR disabled in AI Studio environment)
    const { createServer: createViteServer } = await import('vite');
    const vite = await createViteServer({
      server: {
        middlewareMode: true,
        host: '0.0.0.0',
        port: Number(PORT),
        hmr: false,
      },
      appType: 'spa',
    });
    app.use(vite.middlewares);
  } else {
    // Production mode: serve built static files from dist
    const distPath = path.resolve(__dirname, 'dist');
    app.use(express.static(distPath));
    app.get('*', (_req, res) => {
      res.sendFile(path.resolve(distPath, 'index.html'));
    });
  }

  app.listen(Number(PORT), '0.0.0.0', () => {
    console.log(`Server running at http://0.0.0.0:${PORT} (env: ${isProd ? 'production' : 'development'})`);
  });
}

startServer().catch((err) => {
  console.error('Failed to start server:', err);
  process.exit(1);
});
