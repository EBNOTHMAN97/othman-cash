# دليل النشر على Vercel وربط قاعدة بيانات نيون (Neon PostgreSQL)

تم تجهيز هذا المشروع وتعديله بالكامل ليكون جاهزاً بنسبة 100% للنشر الفوري على منصة **Vercel** والاتصال التلقائي بقاعدة بيانات **Neon PostgreSQL**.

---

## 1. الملفات المهيأة تلقائياً في المشروع:

1. **`vercel.json`**:
   - إعدادات البناء والتوجيه التلقائي (Routing & SPA Rewrites).
   - توجيه مسارات الـ Serverless API إلى `/api/*`.

2. **دليل دوال السيرفرليس (`/api/`)**:
   - `api/db.ts`: الاتصال عبر حزمة `@neondatabase/serverless` السريعة مع الإنشاء التلقائي للجداول (Auto Schema Initialization).
   - `api/health.ts`: فحص حالة الاتصال بقاعدة نيون واختبار التجاوب.
   - `api/wallets.ts`: جلب وإضافة وتعديل وحذف المحافظ المالية.
   - `api/transactions.ts`: تسجيل واستعلام المعاملات المالية وتحديث الأرصدة.
   - `api/categories.ts`: إدارة تصنيفات المصروفات.
   - `api/sync.ts`: مزامنة كاملة للبيانات الحالية بضغطة زر واحدة.

3. **`schema.sql`**:
   - كود SQL صريح لجميع الجداول والفهارس (`wallets`, `transactions`, `expense_categories`, `app_settings`) في حال أردت تنفيذه يدوياً داخل Neon SQL Editor.

---

## 2. خطوات النشر والربط خطوة بخطوة:

### الخطوة الأولى: إنشاء قاعدة بيانات Neon المجانية
1. ادخل على موقع [neon.tech](https://neon.tech) وسجّل حساباً مجانياً.
2. أنشئ مشروعاً جديداً باسم `othman-wallet` أو أي اسم تفضله.
3. من لوحة تحكم نيون (Dashboard)، انسخ رابط الاتصال **Connection string**، وسيبدو هكذا:
   ```env
   postgresql://username:password@ep-something.us-east-2.aws.neon.tech/neondb?sslmode=require
   ```

### الخطوة الثانية: رفع الكود على GitHub
1. قم بإنشاء مستودع جديد على حسابك في GitHub (مثلاً: `othman-wallet`).
2. ارفع كود المشروع إليه:
   ```bash
   git init
   git add .
   git commit -m "feat: setup vercel deployment and neon postgresql database"
   git branch -M main
   git remote add origin https://github.com/<your-username>/othman-wallet.git
   git push -u origin main
   ```

### الخطوة الثالثة: النشر على Vercel
1. توجّه إلى موقع [vercel.com](https://vercel.com) وسجّل دخول بحساب GitHub.
2. اضغط على **"Add New..."** ثم اختر **"Project"**.
3. اختر مستودع المشروع `othman-wallet` واضغط **Import**.
4. في شاشة الإعداد قبل الضغط على Deploy، افتح قسم **"Environment Variables"** وأضف:
   - **Key**: `DATABASE_URL`
   - **Value**: الصق رابط اتصال نيون الذي نسخته في الخطوة الأولى.
5. اضغط على زر **"Deploy"**.

---

## 3. بعد النشر (التهيئة التلقائية):
- بمجرد اكتمال البناء على Vercel، ستعمل دوال `/api/*` تلقائياً عبر Vercel Serverless Functions.
- عند أول زيارة للموقع، ستقوم دالة `ensureSchemaInitialized` بإنشاء جميع الجداول تلقائياً في نيون.
- يمكنك أيضاً الدخول على **الإعدادات > قاعدة بيانات نيون (Neon PostgreSQL) & استضافة Vercel** والضغط على **"مزامنة ورفع البيانات الحالية إلى Neon"** لرفع بياناتك فوراً!
