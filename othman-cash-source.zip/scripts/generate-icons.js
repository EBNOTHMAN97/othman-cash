import sharp from 'sharp';
import fs from 'fs';
import path from 'path';

const publicDir = path.resolve('public');
if (!fs.existsSync(publicDir)) {
  fs.mkdirSync(publicDir, { recursive: true });
}

// SVG with Arabic "ع" emblem and sleek financial styling
// Standard icon (with rounded corners for preview / direct viewing, though sharp can export whatever)
const baseSvg = `
<svg width="512" height="512" viewBox="0 0 512 512" fill="none" xmlns="http://www.w3.org/2000/svg">
  <defs>
    <linearGradient id="bgGrad" x1="0" y1="0" x2="512" y2="512" gradientUnits="userSpaceOnUse">
      <stop offset="0%" stop-color="#1e293b" />
      <stop offset="60%" stop-color="#101827" />
      <stop offset="100%" stop-color="#090d16" />
    </linearGradient>
    <linearGradient id="emeraldGrad" x1="120" y1="100" x2="400" y2="420" gradientUnits="userSpaceOnUse">
      <stop offset="0%" stop-color="#34d399" />
      <stop offset="50%" stop-color="#10b981" />
      <stop offset="100%" stop-color="#059669" />
    </linearGradient>
    <linearGradient id="goldGrad" x1="160" y1="120" x2="360" y2="380" gradientUnits="userSpaceOnUse">
      <stop offset="0%" stop-color="#fbbf24" />
      <stop offset="100%" stop-color="#d97706" />
    </linearGradient>
    <filter id="glow" x="-20%" y="-20%" width="140%" height="140%">
      <feGaussianBlur stdDeviation="16" result="blur" />
      <feComposite in="SourceGraphic" in2="blur" operator="over" />
    </filter>
  </defs>

  <!-- Background -->
  <rect width="512" height="512" rx="100" fill="url(#bgGrad)" />

  <!-- Subtle grid lines & security badge rim -->
  <circle cx="256" cy="240" r="190" stroke="#10b981" stroke-opacity="0.18" stroke-width="2" stroke-dasharray="6 6" />
  <circle cx="256" cy="240" r="160" stroke="#10b981" stroke-opacity="0.25" stroke-width="3" />

  <!-- Outer Glowing Crescent / Dynamic Orbit (Money flow) -->
  <path d="M 380,240 C 380,312 322,370 250,370 C 185,370 131,322 122,260" 
        stroke="url(#emeraldGrad)" stroke-width="14" stroke-linecap="round" filter="url(#glow)" fill="none" opacity="0.6"/>
  
  <path d="M 380,240 C 380,312 322,370 250,370 C 185,370 131,322 122,260" 
        stroke="url(#emeraldGrad)" stroke-width="12" stroke-linecap="round" fill="none" />

  <!-- Dynamic Arabic letter "ع" (Ain) modern typographic calligraphy stylized as financial node -->
  <!-- Upper hook / head of the Ain -->
  <path d="M 200,165 C 215,142 245,130 280,135 C 315,140 335,160 330,190 C 326,215 300,230 268,235 C 235,240 220,250 215,268 C 210,290 222,310 255,315 C 290,320 320,305 342,282" 
        stroke="url(#emeraldGrad)" stroke-width="26" stroke-linecap="round" stroke-linejoin="round" fill="none" />

  <!-- Central Coin / Cash Core Accent -->
  <circle cx="256" cy="225" r="28" fill="url(#emeraldGrad)" />
  <circle cx="256" cy="225" r="16" fill="#101827" />
  <circle cx="256" cy="225" r="8" fill="#34d399" />

  <!-- Gold financial Sparkle node on upper branch -->
  <circle cx="330" cy="180" r="10" fill="url(#goldGrad)" />
  <!-- Small spark -->
  <path d="M 330,162 L 330,198 M 312,180 L 348,180" stroke="#fef08a" stroke-width="3" stroke-linecap="round" />

  <!-- Typography "عثمان كاش" banner inside icon -->
  <text x="256" y="435" text-anchor="middle" font-family="'Cairo', 'Segoe UI', Tahoma, Arial, sans-serif" font-size="44" font-weight="900" fill="#ffffff" letter-spacing="1">عثمان كاش</text>
  <text x="256" y="470" text-anchor="middle" font-family="system-ui, -apple-system, sans-serif" font-size="20" font-weight="700" fill="#34d399" letter-spacing="3">OTHMAN CASH</text>
</svg>
`;

// Maskable version: full bleed background, no rounded corners, elements in safe zone (within central 80%)
const maskableSvg = `
<svg width="512" height="512" viewBox="0 0 512 512" fill="none" xmlns="http://www.w3.org/2000/svg">
  <defs>
    <linearGradient id="bgGrad" x1="0" y1="0" x2="512" y2="512" gradientUnits="userSpaceOnUse">
      <stop offset="0%" stop-color="#1e293b" />
      <stop offset="60%" stop-color="#101827" />
      <stop offset="100%" stop-color="#090d16" />
    </linearGradient>
    <linearGradient id="emeraldGrad" x1="120" y1="100" x2="400" y2="420" gradientUnits="userSpaceOnUse">
      <stop offset="0%" stop-color="#34d399" />
      <stop offset="50%" stop-color="#10b981" />
      <stop offset="100%" stop-color="#059669" />
    </linearGradient>
    <linearGradient id="goldGrad" x1="160" y1="120" x2="360" y2="380" gradientUnits="userSpaceOnUse">
      <stop offset="0%" stop-color="#fbbf24" />
      <stop offset="100%" stop-color="#d97706" />
    </linearGradient>
    <filter id="glow" x="-20%" y="-20%" width="140%" height="140%">
      <feGaussianBlur stdDeviation="14" result="blur" />
      <feComposite in="SourceGraphic" in2="blur" operator="over" />
    </filter>
  </defs>

  <!-- Full-bleed background -->
  <rect width="512" height="512" fill="url(#bgGrad)" />

  <!-- Safe area container (scaled to ~76% so everything stays inside safe circle) -->
  <g transform="translate(62, 55) scale(0.76)">
    <!-- Security badge rim -->
    <circle cx="256" cy="230" r="190" stroke="#10b981" stroke-opacity="0.2" stroke-width="2" stroke-dasharray="6 6" />
    <circle cx="256" cy="230" r="160" stroke="#10b981" stroke-opacity="0.25" stroke-width="3" />

    <!-- Outer Glowing Crescent -->
    <path d="M 380,230 C 380,302 322,360 250,360 C 185,360 131,312 122,250" 
          stroke="url(#emeraldGrad)" stroke-width="14" stroke-linecap="round" filter="url(#glow)" fill="none" opacity="0.6"/>
    <path d="M 380,230 C 380,302 322,360 250,360 C 185,360 131,312 122,250" 
          stroke="url(#emeraldGrad)" stroke-width="12" stroke-linecap="round" fill="none" />

    <!-- Dynamic Arabic letter "ع" -->
    <path d="M 200,155 C 215,132 245,120 280,125 C 315,130 335,150 330,180 C 326,205 300,220 268,225 C 235,230 220,240 215,258 C 210,280 222,300 255,305 C 290,310 320,295 342,272" 
          stroke="url(#emeraldGrad)" stroke-width="26" stroke-linecap="round" stroke-linejoin="round" fill="none" />

    <!-- Central Coin Core Accent -->
    <circle cx="256" cy="215" r="28" fill="url(#emeraldGrad)" />
    <circle cx="256" cy="215" r="16" fill="#101827" />
    <circle cx="256" cy="215" r="8" fill="#34d399" />

    <!-- Sparkle node -->
    <circle cx="330" cy="170" r="10" fill="url(#goldGrad)" />
    <path d="M 330,152 L 330,188 M 312,170 L 348,170" stroke="#fef08a" stroke-width="3" stroke-linecap="round" />

    <!-- Typography -->
    <text x="256" y="420" text-anchor="middle" font-family="'Cairo', 'Segoe UI', Tahoma, Arial, sans-serif" font-size="44" font-weight="900" fill="#ffffff" letter-spacing="1">عثمان كاش</text>
    <text x="256" y="455" text-anchor="middle" font-family="system-ui, -apple-system, sans-serif" font-size="20" font-weight="700" fill="#34d399" letter-spacing="3">OTHMAN CASH</text>
  </g>
</svg>
`;

async function run() {
  fs.writeFileSync(path.join(publicDir, 'icon.svg'), baseSvg.trim());

  // Generate 512x512 standard icon PNG
  await sharp(Buffer.from(baseSvg))
    .resize(512, 512)
    .png()
    .toFile(path.join(publicDir, 'pwa-512x512.png'));

  // Generate 192x192 standard icon PNG
  await sharp(Buffer.from(baseSvg))
    .resize(192, 192)
    .png()
    .toFile(path.join(publicDir, 'pwa-192x192.png'));

  // Generate 180x180 Apple touch icon PNG (square full bleed for iOS, iOS automatically applies smooth squircle mask)
  await sharp(Buffer.from(maskableSvg))
    .resize(180, 180)
    .png()
    .toFile(path.join(publicDir, 'apple-touch-icon.png'));

  // Generate 512x512 Maskable icon PNG (for Android adaptive icons)
  await sharp(Buffer.from(maskableSvg))
    .resize(512, 512)
    .png()
    .toFile(path.join(publicDir, 'pwa-maskable-512x512.png'));

  // Favicon PNG (48x48)
  await sharp(Buffer.from(baseSvg))
    .resize(48, 48)
    .png()
    .toFile(path.join(publicDir, 'favicon.png'));

  console.log('All PWA icon assets generated successfully in public/ !');
}

run().catch((err) => {
  console.error(err);
  process.exit(1);
});
